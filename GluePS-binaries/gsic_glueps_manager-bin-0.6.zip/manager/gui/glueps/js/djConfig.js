
var djConfig = {
    isDebug : false,
    parseOnLoad : true,
    locale:'es',
    extraLocale:['en']	
};
