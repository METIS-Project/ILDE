
var Icons = {
    getSrc: function(name) {
        return "images/icons/" + name + ".png";
    }
};

