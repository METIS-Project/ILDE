#!/bin/bash
. /usr/local/lib/reauthoring/bin/activate
cd "$(dirname $0)" 
make html
