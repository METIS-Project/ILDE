<?php

/**
  This file is part of MoodleVLEAdapter.
  
  MoodleVLEAdapter is a property of the Intelligent & Cooperative Systems 
  Research Group (GSIC) from the University of Valladolid (UVA). 
  
  Copyright 2011 GSIC (UVA).

  MoodleVLEAdapter is licensed under the GNU General Public License (GPL) 
  EXCLUSIVELY FOR NON-COMMERCIAL USES. Please, note this is an additional 
  restriction to the terms of GPL that must be kept in any redistribution of
  the original code or any derivative work by third parties.

  If you intend to use MoodleVLEAdapter for any commercial purpose you can 
  contact to GSIC to obtain a commercial license at <glue@gsic.tel.uva.es>.

  If you have licensed this product under a commercial license from GSIC,
  please see the file LICENSE.txt included.

  The next copying permission statement (between square brackets []) is 
  applicable only when GPL is suitable, this is, when MoodleVLEAdapter is 
  used and/or distributed FOR NON COMMERCIAL USES.
  
  [ You can redistribute MoodleVLEAdapter and/or modify it under the 
    terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
  ]
*/


/**
 * This page manages the configuration form for the GLUElet instance(s)
 *
 * @author  David A. Velasco
 * @version 2010040900
 * @package mod/gluelet
 */


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////
    //                                    PRELIMINARS                                                        //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////

    require_once(dirname(dirname(dirname(__FILE__))).'/config.php');
    require_once(dirname(__FILE__).'/lib.php');


    // page parameters processing //
    ////////////////////////////////

    /// one of 'cmid' or 'a' must exist
    $cmid           = optional_param('cmid', 0, PARAM_INT);             // course_module ID
    $a              = optional_param('a', 0, PARAM_INT);                // gluelet acivity ID

    /// parameter sent from edit.php to edit.php for keep in sight the configuration file, avoiding new requests to GLUEletManager when the form is filled or cancelled
    $cfg = stripslashes(optional_param('cfg', null, PARAM_RAW));    // TODO search for a better way; a lot of unnecesary info is sent from browser to Moodle again and again

    /// recover data about current gluelet activity instance from Moodle database
    if ($cmid) {
        if (! $cm = get_coursemodule_from_id(GLUELET_MOD, $cmid)) {
            error(get_string('wrong_cmid_em', GLUELET_MOD));
        }
        if (! $course = get_record('course', 'id', $cm->course)) {
            error(get_string('misconfigured_course_em', GLUELET_MOD));
        }
        if (! $gluelet_activity = get_record(GLUELET_MOD, 'id', $cm->instance)) {
            error(get_string('wrong_cm_em', GLUELET_MOD));
        }

    } else if ($a) {
        if (! $gluelet_activity = get_record(GLUELET_MOD, 'id', $a)) {
            error(get_string('wrong_cm_em', GLUELET_MOD));
        }
        if (! $course = get_record('course', 'id', $gluelet_activity->course)) {
            error(get_string('misconfigured_course_em', GLUELET_MOD));
        }
        if (! $cm = get_coursemodule_from_instance(GLUELET_MOD, $gluelet_activity->id, $course->id)) {
            error(get_string('wrong_cmid_em', GLUELET_MOD));
        }

    } else {
        // al menos debe proporcionarse uno
        error(get_string('cmid_or_instanceid_em', GLUELET_MOD));
    }


    // security checks and logging //
    /////////////////////////////////

    // user login check
    require_login($course, true, $cm);

    // log message
    if ($cmid)
        add_to_log($course->id, GLUELET_MOD, "configure", "view.php?cmid=$cmid", "$gluelet_activity->id");
    else
        add_to_log($course->id, GLUELET_MOD, "configure", "view.php?a=$a", "$gluelet_activity->id");


    // TODO - IMPORTANT!!!! CHECK CAPABILITIES!!!


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////
    //                                 WORK: CONFIGURATION FORM MANAGEMENT                                   //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////


    /// request for the XML configuration definition; performs ::25*:: call to GLUEletManager
    $conf_is_needed = true;
    if (!$cfg) {
        $get_configuration_result = gluelet_get_configuration($gluelet_activity->toolid);
        if (!$get_configuration_result[0])
            error($get_configuration_result[1]);
        else {
            $cfg = $get_configuration_result[1];
            if (strlen($cfg) == 0)
                $conf_is_needed = false;
        }
    }


    /// groups management
    $group_mode = groups_get_activity_groupmode($cm);
    $using_groups = ($group_mode == SEPARATEGROUPS || $group_mode == VISIBLEGROUPS);
    $groups =  groups_get_all_groups($course->id, 0, $cm->groupingid);
    if ($using_groups && count($groups) <= 0)
        ;   // TODO SHOW ERROR MESSAGE AND FINISH [d000016]
    $groups_to_configure = array();
    $groups_already_configured = array();
    if ($using_groups) {
        $groups_to_configure = $groups;
        $instances = get_records(GLUELET_INS, 'glueletactivity', $gluelet_activity->id);
        if (is_array($instances)) {
            foreach ($instances as $instance) {
                $groupid = $instance->groupid;
                if ($groupid >= 0) {
                    $groups_already_configured[$groupid] = $groups_to_configure[$groupid];
                    unset($groups_to_configure[$groupid]);
                }
            }
        }
    }


    /// new configuration/reuse form object
    $cform = null;
    $reusable_gluelet_instances = gluelet_get_reusable_activities($gluelet_activity->id, $gluelet_activity->course, $gluelet_activity->toolid);
    if ($conf_is_needed /*|| (is_array($reusable_gluelet_instances) && count($reusable_gluelet_instances)>0)*/) {
        require_once(dirname(__FILE__).'/configuration_form.php');
        $form_params = array();
        $form_params['cfg'] = $cfg; // $cfg must be passed to form object constructor for parsing form elements (only could be avoided in case of cancellation)
        $form_params['groups_to_configure'] = $groups_to_configure;
        $form_params['groups_already_configured'] = $groups_already_configured;
        $form_params['reusable_gluelet_instances'] = $reusable_gluelet_instances;
        $cform = new gluelet_configuration_form(null, $form_params);
    }


    // *** case 1: cancelled form
    if ($cform && $cform->is_cancelled()) {
        // go away
        if (empty($course)) {   // legacy code; it won't ever happen
            redirect($CFG->wwwroot);
        } else {
            redirect($CFG->wwwroot.'/course/view.php?id='.$course->id);
        }



    // *** case 2: full and right form
    } else if (!$cform || $fromform=$cform->get_data()) {

        if ($cform && isset($fromform->create_or_reuse) && $fromform->create_or_reuse == REUSE_RADIO_OPTION) {

            // GLUElet instance(s) reuse //
            ///////////////////////////////

            if ($using_groups) {
                // when groups are used, a new reuse must be saved for each existing group (in the activity grouping, if existing)
                //if ($cform && isset($fromform->submit_reuse_group)) { // TODO ERASE
                if ($cform && isset($fromform->submit_configure_group)) {
                    // reuse for the selected group was submitted
                    $groupid = $fromform->groups_to_configure_select;
                    $users = gluelet_get_users($cm->id, $groupid, $group_mode);

                    $reused_gluelet = get_record(GLUELET_INS, 'id', $fromform->reusable_activities_select);
                    $gluelet_uri = $reused_gluelet->url;
                    $post_users_list_result = gluelet_post_users_list($gluelet_uri, $USER->username, $users);

                    if ($post_users_list_result[0]) {
                        // save instance data in Moodle database
                        $dataobject = new StdClass;
                        $dataobject->url = $gluelet_uri;
                        $dataobject->glueletactivity = $gluelet_activity->id;
                        $dataobject->groupid = $groupid;
                        insert_record(GLUELET_INS, $dataobject);

                    } else {
                        error($post_users_list_result[1]);
                    }
                } else {
                    // reuse for all the (remaining) groups was submitted
                    $to_create_count = count($groups_to_configure);
                    $failed_count = 0;
                    $reused_gluelet = get_record(GLUELET_INS, 'id', $fromform->reusable_activities_select);
                    $gluelet_uri = $reused_gluelet->url;
                    $users = array();
                    foreach ($groups_to_configure as $groupid => $group) {
                        $users = array_merge( array_diff(gluelet_get_users($cm->id, $groupid, $group_mode), $users), $users);
                    }
                    $post_users_list_result = gluelet_post_users_list($gluelet_uri, $USER->username, $users);
                    if ($post_users_list_result[0]) {
                        foreach ($groups_to_configure as $groupid => $group) {
                            // save instance data in Moodle database
                            $dataobject = new StdClass;
                            $dataobject->url = $gluelet_uri;
                            $dataobject->glueletactivity = $gluelet_activity->id;
                            $dataobject->groupid = $groupid;
                            insert_record(GLUELET_INS, $dataobject);
                        }
                    } else {
                        error(get_string('gluelet_creation_all_failed_em', GLUELET_MOD));
                    }
                }

            }  else /* if ($group_mode == NOGROUPS) */ {
                // without groups, just a reuse
                $users = gluelet_get_users($cm->id);

                $reused_gluelet = get_record(GLUELET_INS, 'id', $fromform->reusable_activities_select);
                $gluelet_uri = $reused_gluelet->url;
                $post_users_list_result = gluelet_post_users_list($gluelet_uri, $USER->username, $users);

                // save instance data in Moodle database
                if ($post_users_list_result[0]) {
                    $dataobject = new StdClass;
                    $dataobject->url = $gluelet_uri;
                    $dataobject->glueletactivity = $gluelet_activity->id;
                    // groupid will be assigned the default value (-1)
                    insert_record(GLUELET_INS, $dataobject);

                } else {
                    error($post_users_list_result[1]);
                }
            }


        } else {    // (!cform || $fromform->create_or_reuse == CREATE_RADIO_OPTION)

            // GLUElet instance(s) creation //
            //////////////////////////////////

            $xmlConf = null;
            if ($cform && $conf_is_needed) {    // $conf_is_needed is necessary since GLUElets from non-configurable tools can be reused
                // complete file upload process
                $cform->save_files(GLUELET_TMPDIR);
                $xmlConf = $cform->buildXFormsInstance();
            }

            if ($using_groups) {
                // when groups are used, a different instance must be created for each existing group (in the activity grouping, if existing)
                if ($cform && isset($fromform->submit_configure_group)) {
                    // configuration for a group was submitted
                    $groupid = $fromform->groups_to_configure_select;
                    $users = gluelet_get_users($cm->id, $groupid, $group_mode);
                    // POST <GLUEletManager>/instance ::25::
                    $post_instance_result = gluelet_post_new_instance($gluelet_activity->toolid, $xmlConf, $users);

                    if ($post_instance_result[0]) {
                        // save instance data in Moodle database
                        $gluelet_uri = $post_instance_result[1];
                        $dataobject = new StdClass;
                        $dataobject->url = $gluelet_uri;
                        $dataobject->glueletactivity = $gluelet_activity->id;
                        $dataobject->groupid = $groupid;
                        insert_record(GLUELET_INS, $dataobject);

                    } else {
                        //error(get_string('gluelet_creation_failed_em', GLUELET_MOD));
                        error($post_instance_result[1]);
                    }

                } else {
                    // configuration for all the (remaining) groups was submitted
                    $to_create_count = count($groups_to_configure);
                    $failed_count = 0;
                    foreach ($groups_to_configure as $groupid => $group) {
                        $users = gluelet_get_users($cm->id, $groupid, $group_mode);
                        // POST <GLUEletManager>/instance ::25::
                        $post_instance_result = gluelet_post_new_instance($gluelet_activity->toolid, $xmlConf, $users);

                        if ($post_instance_result[0]) {
                            // save instance data in Moodle database
                            $gluelet_uri = $post_instance_result[1];
                            $dataobject = new StdClass;
                            $dataobject->url = $gluelet_uri;
                            $dataobject->glueletactivity = $gluelet_activity->id;
                            $dataobject->groupid = $groupid;
                            insert_record(GLUELET_INS, $dataobject);

                        } else {
                            $failed_count++;
                        }
                    }
                    if ($failed_count > 0) {
                        if ($failed_count < $to_create_count) {
                            error(get_string('gluelet_creation_some_failed_em', GLUELET_MOD));   //  TODO better error management?
                        } else {
                            error(get_string('gluelet_creation_all_failed_em', GLUELET_MOD));   //  TODO better error management?
                        }
                    }
                }

            } else /* if ($group_mode == NOGROUPS) */ {
                // without groups, just an instace

                $users = gluelet_get_users($cm->id);

                // POST <GLUEletManager>/instance ::25::
                $post_instance_result = gluelet_post_new_instance($gluelet_activity->toolid, $xmlConf, $users);
                // save instance data in Moodle database
                if ($post_instance_result[0]) {
                    $gluelet_uri = $post_instance_result[1];
                    $dataobject = new StdClass;
                    $dataobject->url = $gluelet_uri;
                    $dataobject->glueletactivity = $gluelet_activity->id;
                    // groupid will be assigned the default value (-1)
                    insert_record(GLUELET_INS, $dataobject);

                } else {
                    //error(get_string('gluelet_creation_failed_em', GLUELET_MOD));
                    error($post_instance_result[1]);
                }
            }


            /// delete file uploads after creation
            if ($cform) {
                foreach ($cform->_upload_manager->files as $element => $file_info) {
                    if ($file_info['originalname'] && $file_info['saved']) {
                        unlink($file_info['fullpath']);
                    }
                }
            }
        }

        /// last step: redirect to THE RIGHT PAGE
        if ($using_groups && $cform && (isset($fromform->submit_configure_group) /*|| isset($fromform->submit_reuse_group)*/) && count($groups_to_configure) > 1) {
            redirect($CFG->wwwroot.'/mod/gluelet/edit.php?cmid=' . $cm->id);    // there are more groups to configure
            //echo '<a href="' . $CFG->wwwroot. '/mod/gluelet/edit.php?cmid=' . $cm->id . '"> Pinchar para configurar mas grupos </a>';    // leave this here for dirty debugging
        } else {
            redirect($CFG->wwwroot.'/mod/gluelet/view.php?id=' . $cm->id);      // we're done
            //echo '<a href="' . $CFG->wwwroot. '/mod/gluelet/view.php?id=' . $cm->id . '"> Pinchar para ver </a>';    // leave this here for dirty debugging
        }


    // *** case 3: blank or wrong form
    } else {
        /// print page header
        $strgluelets = get_string('modulenameplural', GLUELET_MOD);
        $strgluelet  = get_string('modulename', GLUELET_MOD);

        $navlinks = array();
        $navlinks[] = array('name' => $strgluelets, 'link' => "index.php?id=$course->id", 'type' => 'activity');
        $navlinks[] = array('name' => format_string($gluelet_activity->name), 'link' => '', 'type' => 'activityinstance');

        $navigation = build_navigation($navlinks);

        // note $cform->focus() in order to put cursor over the first field in form
        print_header_simple(format_string($gluelet_activity->name), '', $navigation, $cform->focus(), '', true, update_module_button($cm->id, $course->id, $strgluelet), navmenu($course, $cm));


        /// print configuration form
        print_heading(get_string('configuration_form_heading', GLUELET_MOD));

        // URL params to be passed through
        $toform['cmid'] = $cmid;
        $toform['a'] = $a;
        $cform->set_data($toform);

        // render the form
        $cform->display();

        /// print page footer
        print_footer($course);

    }

?>
