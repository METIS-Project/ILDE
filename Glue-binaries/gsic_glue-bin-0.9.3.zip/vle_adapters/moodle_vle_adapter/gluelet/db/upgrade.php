<?php

/**
  This file is part of MoodleVLEAdapter.
  
  MoodleVLEAdapter is a property of the Intelligent & Cooperative Systems 
  Research Group (GSIC) from the University of Valladolid (UVA). 
  
  Copyright 2011 GSIC (UVA).

  MoodleVLEAdapter is licensed under the GNU General Public License (GPL) 
  EXCLUSIVELY FOR NON-COMMERCIAL USES. Please, note this is an additional 
  restriction to the terms of GPL that must be kept in any redistribution of
  the original code or any derivative work by third parties.

  If you intend to use MoodleVLEAdapter for any commercial purpose you can 
  contact to GSIC to obtain a commercial license at <glue@gsic.tel.uva.es>.

  If you have licensed this product under a commercial license from GSIC,
  please see the file LICENSE.txt included.

  The next copying permission statement (between square brackets []) is 
  applicable only when GPL is suitable, this is, when MoodleVLEAdapter is 
  used and/or distributed FOR NON COMMERCIAL USES.
  
  [ You can redistribute MoodleVLEAdapter and/or modify it under the 
    terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
  ]
*/


/**
 * This file keeps track of upgrades to the gluelet module
 *
 * @author  David A. Velasco 
 * @version 2010021000
 * @package mod/gluelet
 * @todo    Real code (if needed)
 */


// Sometimes, changes between versions involve
// alterations to database structures and other
// major things that may break installations.
//
// The upgrade function in this file will attempt
// to perform all the necessary actions to upgrade
// your older installtion to the current version.
//
// If there's something it cannot do itself, it
// will tell you what you need to do.
//
// The commands in here will all be database-neutral,
// using the functions defined in lib/ddllib.php

function xmldb_gluelet_upgrade($oldversion=0) {

    global $CFG, $THEME, $db;

    $result = true;

    if ($result && $oldversion < 2010021000) { //New version in version.php

        $table = new XMLDBTable('gluelet');

        // add field toolname
        $field = new XMLDBField('toolname');
        $field->setAttributes(XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, null, null, null, 'timemodified');
        $result = $result && add_field($table, $field);

        // add field toolid
        $field = new XMLDBField('toolid');
        $field->setAttributes(XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, null, null, null, 'toolname');
        $result = $result && add_field($table, $field);
    }

    if ($result && $oldversion < 2010022300) {

        $table = new XMLDBTable('gluelet');

        // add field url
        $field = new XMLDBField('url');
        $field->setAttributes(XMLDB_TYPE_CHAR, '255', null, null, null, null, null, 'null', 'toolid');
        $result = $result && add_field($table, $field);
    }

    if ($result && $oldversion < 2010022301) {

        $table = new XMLDBTable('gluelet');

        // field url with the new default value
        $field = new XMLDBField('url');
        $field->setAttributes(XMLDB_TYPE_CHAR, '255', null, null, null, null, null, null, 'toolid');

        // change of default for field url
        $result = $result && change_field_default($table, $field);
    }

    if ($result && $oldversion < 2010032201) {

        // define table gluelet_instances to be created
        $table = new XMLDBTable('gluelet_instances');

        // adding fields to table gluelet_instances
        $table->addFieldInfo('url', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, null, null, null);
        $table->addFieldInfo('glueletactivity', XMLDB_TYPE_INTEGER, '10', XMLDB_UNSIGNED, XMLDB_NOTNULL, null, null, null, '0');
        $table->addFieldInfo('groupid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null, null, '-1');

        // adding keys to table gluelet_instances
        $table->addKeyInfo('primary', XMLDB_KEY_PRIMARY, array('url'));
        $table->addKeyInfo('glueletactivity', XMLDB_KEY_FOREIGN, array('glueletactivity'), 'gluelet', array('id'));

        // launch create table for gluelet_instances
        $result = $result && create_table($table);


        // define field url to be dropped from gluelet
        $table = new XMLDBTable('gluelet');
        $field = new XMLDBField('url');

        // launch drop field url - previous GLUElet instances are lost this way; but keep them in the system is too hard given their interest (they are just test GLUElets)
        $result = $result && drop_field($table, $field);


    }

    if ($result && $oldversion < 2010032300) {   // Moodle dmlib.php code expects that primary keys in Moodle tables are sequenced int fields; 'url' will remain only to be used, but it won't be primary key.

        /// Primary key can't be dropped, table would be inconsistent; all the table must be dropped and created againg

        // launch drop table for gluelet_instances
        $table = new XMLDBTable('gluelet_instances');
        $result = $result && drop_table($table);


        // define table gluelet_instances to be created again
        $table = new XMLDBTable('gluelet_instances');

        // adding fields to table gluelet_instances
        $table->addFieldInfo('id', XMLDB_TYPE_INTEGER, '10', XMLDB_UNSIGNED, XMLDB_NOTNULL, XMLDB_SEQUENCE, null, null, null);
        $table->addFieldInfo('url', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, null, null, null);
        $table->addFieldInfo('glueletactivity', XMLDB_TYPE_INTEGER, '10', XMLDB_UNSIGNED, XMLDB_NOTNULL, null, null, null, '0');
        $table->addFieldInfo('groupid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null, null, '-1');

        // adding keys to table gluelet_instances
        $table->addKeyInfo('primary', XMLDB_KEY_PRIMARY, array('id'));
        $table->addKeyInfo('glueletactivity', XMLDB_KEY_FOREIGN, array('glueletactivity'), 'gluelet', array('id'));

        // launch create table for gluelet_instances
        $result = $result && create_table($table);
    }

    if ($result && $oldversion < 2011030400) {

        /// Primary key can't be dropped, table would be inconsistent; all the table must be dropped and created againg

        // define table gluelet_users_list_changes
        $table = new XMLDBTable('gluelet_users_list_changes');

        // adding fields to table gluelet_instances
        $table->addFieldInfo('id', XMLDB_TYPE_INTEGER, '10', XMLDB_UNSIGNED, XMLDB_NOTNULL, XMLDB_SEQUENCE, null, null, null);  // WARNING - Moodle dmlib.php code expects that primary keys in Moodle tables are sequenced int fields
        //$table->addFieldInfo('groupid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null, null, '-1');
        $table->addFieldInfo('glueletinstance', XMLDB_TYPE_INTEGER, '10', XMLDB_UNSIGNED, XMLDB_NOTNULL, null, null, null, '0');
        $table->addFieldInfo('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null, null, null);
        $table->addFieldInfo('action', XMLDB_TYPE_CHAR, '1', null, XMLDB_NOTNULL, null, null, null, '0');

        // adding keys to table gluelet_instances
        $table->addKeyInfo('primary', XMLDB_KEY_PRIMARY, array('id'));
        $table->addKeyInfo('glueletinstance', XMLDB_KEY_FOREIGN, array('glueletinstance'), 'gluelet_instances', array('id'));

        // launch create table for gluelet_instances
        $result = $result && create_table($table);

    }

    /// Final return of upgrade result (true/false) to Moodle. Must be always the last line in the script
    return $result;
}

?>
