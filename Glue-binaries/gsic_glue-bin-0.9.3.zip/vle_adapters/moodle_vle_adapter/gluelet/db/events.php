<?php

/**
  This file is part of MoodleVLEAdapter.
  
  MoodleVLEAdapter is a property of the Intelligent & Cooperative Systems 
  Research Group (GSIC) from the University of Valladolid (UVA). 
  
  Copyright 2011 GSIC (UVA).

  MoodleVLEAdapter is licensed under the GNU General Public License (GPL) 
  EXCLUSIVELY FOR NON-COMMERCIAL USES. Please, note this is an additional 
  restriction to the terms of GPL that must be kept in any redistribution of
  the original code or any derivative work by third parties.

  If you intend to use MoodleVLEAdapter for any commercial purpose you can 
  contact to GSIC to obtain a commercial license at <glue@gsic.tel.uva.es>.

  If you have licensed this product under a commercial license from GSIC,
  please see the file LICENSE.txt included.

  The next copying permission statement (between square brackets []) is 
  applicable only when GPL is suitable, this is, when MoodleVLEAdapter is 
  used and/or distributed FOR NON COMMERCIAL USES.
  
  [ You can redistribute MoodleVLEAdapter and/or modify it under the 
    terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
  ]
*/


$handlers = array (

    ////////////////////
    /// USERS EVENTS ///
    ////////////////////

    'user_created' => array (
        'handlerfile'       => '/mod/gluelet/event_handlers_lib.php',
         'handlerfunction'  => 'user_created_handler',
         'schedule'         => 'instant'
     ),

    'user_deleted' => array (
        'handlerfile'       => '/mod/gluelet/event_handlers_lib.php',
         'handlerfunction'  => 'user_deleted_handler',
         'schedule'         => 'instant'
     ),

    'user_updated' => array (
        'handlerfile'       => '/mod/gluelet/event_handlers_lib.php',
         'handlerfunction'  => 'user_updated_handler',
         'schedule'         => 'instant'
     ),


    ////////////////////
    /// ROLES EVENTS ///
    ////////////////////

    'role_assigned' => array (
        'handlerfile'       => '/mod/gluelet/event_handlers_lib.php',
         'handlerfunction'  => 'role_assigned_handler',
         'schedule'         => 'instant'
     ),

    'role_unassigned' => array (
        'handlerfile'       => '/mod/gluelet/event_handlers_lib.php',
         'handlerfunction'  => 'role_unassigned_handler',
         'schedule'         => 'instant'
     ),


    //////////////////////
    /// COURSES EVENTS ///
    //////////////////////

    'course_created' => array (
        'handlerfile'       => '/mod/gluelet/event_handlers_lib.php',
         'handlerfunction'  => 'course_created_handler',
         'schedule'         => 'instant'
     ),

    'course_updated' => array (
        'handlerfile'       => '/mod/gluelet/event_handlers_lib.php',
         'handlerfunction'  => 'course_updated_handler',
         'schedule'         => 'instant'
     ),

    'course_deleted' => array (
        'handlerfile'       => '/mod/gluelet/event_handlers_lib.php',
         'handlerfunction'  => 'course_deleted_handler',
         'schedule'         => 'instant'
     ),

    'course_category_deleted' => array (
        'handlerfile'       => '/mod/gluelet/event_handlers_lib.php',
         'handlerfunction'  => 'course_category_deleted_handler',
         'schedule'         => 'instant'
     ),


    /////////////////////
    /// GROUPS EVENTS ///
    /////////////////////

    'groups_member_added' => array (
         'handlerfile'      => '/mod/gluelet/event_handlers_lib.php',
         'handlerfunction'  => 'groups_member_added_handler',
         'schedule'         => 'instant'
     ),

    'groups_member_removed' => array (
         'handlerfile'      => '/mod/gluelet/event_handlers_lib.php',
         'handlerfunction'  => 'groups_member_removed_handler',
         'schedule'         => 'instant'
     ),

    'groups_group_created' => array (
        'handlerfile'       => '/mod/gluelet/event_handlers_lib.php',
         'handlerfunction'  => 'groups_group_created_handler',
         'schedule'         => 'instant'
     ),

    'groups_group_updated' => array (
        'handlerfile'       => '/mod/gluelet/event_handlers_lib.php',
         'handlerfunction'  => 'groups_group_updated_handler',
         'schedule'         => 'instant'
     ),

    'groups_group_deleted' => array (
        'handlerfile'       => '/mod/gluelet/event_handlers_lib.php',
         'handlerfunction'  => 'groups_group_deleted_handler',
         'schedule'         => 'instant'
     ),

    'groups_grouping_created' => array (
        'handlerfile'       => '/mod/gluelet/event_handlers_lib.php',
         'handlerfunction'  => 'groups_grouping_created_handler',
         'schedule'         => 'instant'
     ),

    'groups_grouping_updated' => array (
        'handlerfile'       => '/mod/gluelet/event_handlers_lib.php',
         'handlerfunction'  => 'groups_grouping_updated_handler',
         'schedule'         => 'instant'
     ),

    'groups_grouping_deleted' => array (
        'handlerfile'       => '/mod/gluelet/event_handlers_lib.php',
         'handlerfunction'  => 'groups_grouping_deleted_handler',
         'schedule'         => 'instant'
     ),

    'groups_members_removed' => array (
        'handlerfile'       => '/mod/gluelet/event_handlers_lib.php',
         'handlerfunction'  => 'groups_members_removed_handler',
         'schedule'         => 'instant'
     ),

    'groups_groupings_groups_removed' => array (
        'handlerfile'       => '/mod/gluelet/event_handlers_lib.php',
         'handlerfunction'  => 'groups_groupings_groups_removed_handler',
         'schedule'         => 'instant'
     ),

    'groups_groups_deleted' => array (
        'handlerfile'       => '/mod/gluelet/event_handlers_lib.php',
         'handlerfunction'  => 'groups_groups_deleted_handler',
         'schedule'         => 'instant'
     ),

    'groups_groupings_deleted' => array (
         'handlerfile'      => '/mod/gluelet/event_handlers_lib.php',
         'handlerfunction'  => 'groups_groupings_deleted_handler',
         'schedule'         => 'instant'
     )
);

?>