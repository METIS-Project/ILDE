<?php

/**
  This file is part of MoodleVLEAdapter.
  
  MoodleVLEAdapter is a property of the Intelligent & Cooperative Systems 
  Research Group (GSIC) from the University of Valladolid (UVA). 
  
  Copyright 2011 GSIC (UVA).

  MoodleVLEAdapter is licensed under the GNU General Public License (GPL) 
  EXCLUSIVELY FOR NON-COMMERCIAL USES. Please, note this is an additional 
  restriction to the terms of GPL that must be kept in any redistribution of
  the original code or any derivative work by third parties.

  If you intend to use MoodleVLEAdapter for any commercial purpose you can 
  contact to GSIC to obtain a commercial license at <glue@gsic.tel.uva.es>.

  If you have licensed this product under a commercial license from GSIC,
  please see the file LICENSE.txt included.

  The next copying permission statement (between square brackets []) is 
  applicable only when GPL is suitable, this is, when MoodleVLEAdapter is 
  used and/or distributed FOR NON COMMERCIAL USES.
  
  [ You can redistribute MoodleVLEAdapter and/or modify it under the 
    terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
  ]
*/



require_once(dirname(__FILE__).'/lib.php');

$settings->add(new admin_setting_heading(   GLUELET_MOD . '_server_heading',                    // parameter name; NOT saved
                                            get_string('settings_server_heading', GLUELET_MOD),
                                            null ) );

$settings->add(new admin_setting_configtext(GLUELET_MOD . '_base_url',                          // paramater name; saved in Moodle database, table 'mdl_config', column 'name'
                                            get_string('settings_base_url', GLUELET_MOD),
                                            get_string('settings_base_url_description', GLUELET_MOD),
                                            'www.gsic.tel.uva.es:8185/any/prefix' ) );

$settings->add(new admin_setting_configtext(GLUELET_MOD . '_timeout',                           // paramater name; saved in Moodle database, table 'mdl_config', column 'name'
                                            get_string('settings_timeout', GLUELET_MOD),
                                            get_string('settings_timeout_description', GLUELET_MOD),
                                            30 ));

/*$settings->add(new admin_setting_configtext(GLUELET_MOD . '_server_name',                        // paramater name; saved in Moodle database, table 'mdl_config', column 'name'
                                            get_string('settings_server_name', GLUELET_MOD),
                                            get_string('settings_server_name_description', GLUELET_MOD),
                                            $_SERVER['SERVER_NAME'] ) ); */

/*$settings->add(new admin_setting_configtext(GLUELET_MOD . '_server_ip',                          // paramater name; saved in Moodle database, table 'mdl_config', column 'name'
                                            get_string('settings_server_ip', GLUELET_MOD),
                                            get_string('settings_server_ip_description', GLUELET_MOD),
                                            $_SERVER['SERVER_ADDR']));*/

/*$settings->add(new admin_setting_configtext(GLUELET_MOD . '_server_port',                        // paramater name; saved in Moodle database, table 'mdl_config', column 'name'
                                            get_string('settings_server_port', GLUELET_MOD),
                                            get_string('settings_server_port_description', GLUELET_MOD),
                                            $_SERVER['SERVER_PORT'],
                                            PARAM_INT )); */


?>
