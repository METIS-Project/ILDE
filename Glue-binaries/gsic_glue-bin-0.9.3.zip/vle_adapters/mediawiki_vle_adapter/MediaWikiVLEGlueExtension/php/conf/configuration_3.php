﻿<?php

/**
  This file is part of MediaWikiVLEAdapter.
  
  MediaWikiVLEAdapter is a property of the Intelligent & Cooperative Systems 
  Research Group (GSIC) from the University of Valladolid (UVA). 
  
  Copyright 2011 GSIC (UVA).

  MediaWikiVLEAdapter is licensed under the GNU General Public License (GPL) 
  EXCLUSIVELY FOR NON-COMMERCIAL USES. Please, note this is an additional 
  restriction to the terms of GPL that must be kept in any redistribution of
  the original code or any derivative work by third parties.

  If you intend to use MediaWikiVLEAdapter for any commercial purpose you can 
  contact to GSIC to obtain a commercial license at <glue@gsic.tel.uva.es>.

  If you have licensed this product under a commercial license from GSIC,
  please see the file LICENSE.txt included.

  The next copying permission statement (between square brackets []) is 
  applicable only when GPL is suitable, this is, when MediaWikiVLEAdapter is 
  used and/or distributed FOR NON COMMERCIAL USES.
  
  [ You can redistribute MediaWikiVLEAdapter and/or modify it under the 
    terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
  ]
*/

 
/*
 * This page is used to configure a new instance. It is the third and last configuration step: show post new instance restulr.
 *
 * This page make a post request to gluelet manager to create a new instance. The page show the request result.
 *
 *
 * @access public 
 * @author Javier Aragon
 * @version 2011/05/31-0.1
 * @package php/conf
 */
print("<html>");

// print head tags.
print("<head>");
	print("<title></title>");
print("</head>");

// print body tag.
print("<body onload='bodyload()' onunload='bodyunload()'>");

	// GlueletManagerClient library required.
	require_once('../classes/rest/GlueletManagerRestClient.php');
	// xforms_to_form library required.
	require_once('../classes/xforms/xforms_to_form.php');
	// Internazionalitacion library required.
	require_once('../classes/i18n/I18NGlueLibMessages.php');
	// get the language user preference from $_GET parameteres.
	$lang = $_POST['lang'];
	if (!$lang || $lang==null || $lang=="")
		// if there is no language parameter then create an internationalization object and set defatul language to English.
		$I18N = new I18NGlueLibMessages('en');
	else
		// create the internationalization object.
		$I18N = new I18NGlueLibMessages($lang);
	
	// Get params:
	// The instance configuration form.
	if ($_POST["conf_xform"]){
		$confXform = stripslashes(stripslashes($_POST["conf_xform"]));
	}
	// the url where is the glueletmanager.
	$hostGlueletManager = $_POST["glueletmanager"];
	// the selected tool.
	$selectedtool = $_POST["selectedtool"];
	// the selected tool.
	//$selectedtoolname = $_POST["selectedtoolname"];
	$selectedtoolname = $_POST["toolname"];
	// the caller user parameter.
	$user = $_POST["user"];
	// the mediawiki registerd users list.
	$userlist = $_POST["userlist"];
	
	// if any error at parameters die and show error message.
	if (!$confXform || !$user || !$userlist || !$selectedtool ||!$hostGlueletManager || $confXform=="" || $user=="" || $userlist=="" || $selectedtool=="" || $hostGlueletManager=="")
		die($I18N->getI18NMessage('errorinparams'));
	
	// Try to obtain uploaded files.
	if (isset($_FILES['upload___ins:data_ins:file']))
	{
		$filename = $_FILES['upload___ins:data_ins:file']['name'];
	}
	
	if ($confXform){
		// if get configuration form parameter is successful try to load it into a DOM Object.
		$doc = new DOMDocument();
        $doc->loadXML($confXform);
		$domconf = $doc;
		//$domconf = DOMDocument::loadXML($confXform);
		if ($domconf){
			// if configuration form is loaded into a DOM Object successful create a xfoms_to_from object
			$converter = new xforms_to_form($domconf);
			// Extract xforms_data into a DOM object.
			$domdata = $converter->buildXFormsInstance();

			// Process userlist as an array comma-splited
			//$userlist_as_array = split(",",$userlist);
			$userlist_as_array = explode(",",$userlist);

			// Create a GlueletManger client object.
			$rest_client = new GlueletManagerRestClient($user, $userlist_as_array, $hostGlueletManager);
			// post new instace request.
			$postreturn = $rest_client->gluelet_post_new_instance($selectedtool, $domdata);
			
			
			if ($postreturn[0]){
				// if new instance request successful show a message with new instance id.
				$instanceid = $postreturn[1];
				print( "<input id='instance' type='hidden' value='".$instanceid."'>");
				print('<p:0>');
					print($I18N->getI18NMessage('instancecreatedmessage')."<font color=blue>".$instanceid .'</font>');
				print("</p>");
				print("<p>");
				
				$instancetitledefaultvalue = $I18N->getI18NMessage('instancetitledefaultvalue');
				print($I18N->getI18NMessage('instancetitleinputlabel')." <input width='100%' style='font-style:italic;color:grey'type='text' name='instance_title_field' id='instance_title_field' size=50  maxlength=80 onBlur=no_foco(this) onFocus=foco(this) onclick=\"isFirstEdit(this,'".$instancetitledefaultvalue."')\"  value='".$instancetitledefaultvalue."' />");
				print('</p>');
				
			} else{
				$postreturn[1]->print_post_new_instance_error_with_deatils($hostGlueletManager, $user, $selectedtool, $selectedtoolname, $lang);
			}
		}
	}



//print end body tag.
print("</body>");
//print end html tag.
print("</html>");
?>

<script type="text/javascript" charset="utf-8">
	/*
	* When the body is loaded/unloaded hide/how the 'loading image' and show the delete instance request.
	*
	*/
	var ErrorInstance = false;
	function bodyload(){
		if (ErrorInstance== null || !ErrorInstance){
			window.top.document.getElementById('NewGlueletConfigurationform').style.display='';
			window.top.document.getElementById('NewGlueletConfigurationform').style.height='86%';
			window.top.document.getElementById('winCloseButtonGlue').style.display='';
			window.top.document.getElementById('gluewindowinstance').style.display='none';
		}
	}
	
	function bodyunload(){
		
		if (document.getElementById('instance_title_field'))
			if (window.top.document.getElementById('instancetitlecontrol'))
					if (!firstEdit)
						window.top.document.getElementById('instancetitlecontrol').value = document.getElementById('instance_title_field').value
						
		
		if (document.getElementById('instance'))
		 if (window.top.document.getElementById('instancecontrol'))
				window.top.document.getElementById('instancecontrol').value = document.getElementById('instance').value;
	}
	
	
	function foco(elemento) {
		elemento.style.border = "1px solid #000000";
	}	
	function no_foco(elemento) {
		elemento.style.border = "1px solid #CCCCCC";
	} 
	
	var firstEdit = true;
	function isFirstEdit(elemento, defvalue) {
		if (firstEdit){
			if(elemento.value==defvalue)
				elemento.value='';
			else
				elemento.select();
			elemento.style.color = "black";
			elemento.style.fontStyle = "normal";
			firstEdit = false;
		}
	}

</script>


