<?php	

/**
  This file is part of MediaWikiVLEAdapter.
  
  MediaWikiVLEAdapter is a property of the Intelligent & Cooperative Systems 
  Research Group (GSIC) from the University of Valladolid (UVA). 
  
  Copyright 2011 GSIC (UVA).

  MediaWikiVLEAdapter is licensed under the GNU General Public License (GPL) 
  EXCLUSIVELY FOR NON-COMMERCIAL USES. Please, note this is an additional 
  restriction to the terms of GPL that must be kept in any redistribution of
  the original code or any derivative work by third parties.

  If you intend to use MediaWikiVLEAdapter for any commercial purpose you can 
  contact to GSIC to obtain a commercial license at <glue@gsic.tel.uva.es>.

  If you have licensed this product under a commercial license from GSIC,
  please see the file LICENSE.txt included.

  The next copying permission statement (between square brackets []) is 
  applicable only when GPL is suitable, this is, when MediaWikiVLEAdapter is 
  used and/or distributed FOR NON COMMERCIAL USES.
  
  [ You can redistribute MediaWikiVLEAdapter and/or modify it under the 
    terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
  ]
*/


/*
 * This page is used to configure a new instance. It is the first configuration step: show the GLUE tools list.
 *
 * This page shows the GLUE tools list registered in gluelet manager. The list is rendered in a dropdown field with a button to
 * go to secon configuration page.
 *
 *
 * @access public 
 * @author Javier Aragon
 * @version 2011/05/31-0.1
 * @package php/conf
 */
 ?>
<script type="text/javascript" charset="utf-8">
	/*
	* When the body is loaded/unloaded hide/how the 'loading image' and show the delete instance request.
	*
	*/
	var ErrorTool = false;
	
	function bodyload(){		
		if (ErrorTool== null || !ErrorTool){
			window.top.document.getElementById('NewGlueletConfigurationform').style.display='';
			window.top.document.getElementById('winCloseButtonGlue').style.display='none';
			window.top.document.getElementById('gluewindowinstance').style.display='none';
		}
	}

	function bodyunload(){
		if (ErrorTool== null || !ErrorTool){
			if (window.top.document.getElementById('NewGlueletConfigurationform'))
				window.top.document.getElementById('NewGlueletConfigurationform').style.display='none';
			if (window.top.document.getElementById('gluewindowinstance'))
				window.top.document.getElementById('gluewindowinstance').style.display='';	
		}
	}
	
	function onSendButton(){
		window.top.document.getElementById('NewGlueletConfigurationform').style.display='none';
		window.top.document.getElementById('gluewindowinstance').style.display='';	
		
		return true;
	}
	
	function comprobar(){
		if (document){
			if (document.selecttoolform){
				if (document.selecttoolform.selectedtool){
					if (document.selecttoolform.selectedtool.options[this.document.selecttoolform.selectedtool.selectedIndex].value){
						this.document.selecttoolform.toolname.value=this.document.selecttoolform.selectedtool.options[this.document.selecttoolform.selectedtool.selectedIndex].text;
						return true;
					}
				}
			}
		}
		return false;
	}
	
</script>

<?php	
// print html tag.
print("<html>");

// print head tags.
print("<head>");
	print("<link rel='stylesheet' type='text/css' href='css/body_conf.css' >");
	print("<title></title>");
print("</head>");

// print body tag.
print("<body onunload='bodyunload()' onload='bodyload()'>");

	// GlueletManagerClient library required.
	require_once('../classes/rest/GlueletManagerRestClient.php');
	// Internazionalitacion library required.
	require_once('../classes/i18n/I18NGlueLibMessages.php');
	// get the language user preference from $_GET parameteres
	$lang = $_GET['lang'];
	if (!$lang || $lang==null || $lang=="")
		// if there is no language parameter then create an internationalization object and set defatul language to English.
		$I18N = new I18NGlueLibMessages('en');
	else
		// create the internationalization object.
		$I18N = new I18NGlueLibMessages($lang);
	
	// Get params:
	// the caller user parameter.
	$user = $_GET['user'];
	// the mediawiki registerd users list.
	$userlist = $_GET['userlist'];
	// the url where is the glueletmanager.
	$glueletmanager = $_GET['glueletmanager'];
 
	// if any error at parameters die and show error message.
	if (!$glueletmanager || !$user || !$userlist || $glueletmanager=="" || $user=="" || $userlist=="") {
		die($I18N->getI18NMessage('errorinparams'));
	}
 
	// Create a GlueletManger client object.
	$rest_client = new GlueletManagerRestClient($user, $userlist, $glueletmanager);
	// get tool list request.
	$result = $rest_client->gluelet_get_tools_list(); 
	
	
	if($result[0]){
		// if get tool list request successful.	
		// get select tool combobox label.
		$labelselect1 = $I18N->getI18NMessage('selecttoollabel');
		// refactor tools list as Array['toolid','toolname'].
		foreach ( $result[1] as $toolid=> $toolname) {
			$tools[$toolid] = $toolname;
		}
						
		
		print("<br>");
		print ("<p><center>");		
			//print the form.
			print ("<form name='selecttoolform' onSubmit='comprobar()' id='selecttoolform' method='get' action='configuration_2.php'>");
				// print select tool label.
				print("<p><font color=#0000FF><b>". $labelselect1 ."</b></font></p>");
				// print the como box.
				print ("<select name=selectedtool >");
					foreach ($tools as $i => $value) {
						// print/add each tool to comobobox.
						print( "<option value=\"".$i."\">".$value."</option>"); 
					}
				print ("</select>");
				
				// print send button.
				print ("<p>");
				print ("<input name='sendtoolbutton' type='submit' value='".$I18N->getI18NMessage('sendbuttonlabel')."' onclick='onSendButton()' />");
				print ("</p>");

				// print hidden fields for: user, users list, gluelet manager host and user language.
				print ("<input name='user' type='hidden' value='".$user."'  />");
				print ("<input name='userlist' type='hidden' value='".$userlist."'  />");
				print ("<input name='glueletmanager' type='hidden' value='".$glueletmanager."'  />");
				print ("<input name='lang' type='hidden' value='".$lang."'  />");
				print ("<input name='toolname' type='hidden' value=''  />");
			print ("</form>");
		print ("</center></p>");
		

		

		
	}else{
		if ($result[1]){
			// if no tools are registered at gluelet manager or there is an error at get tool list request show an error message.
			$result[1]->print_get_tool_list_error_with_deatils($glueletmanager, $user, $lang);
		}
	}
	
//print end body tag.
print("</body>");
// print end hrml tag.
print("</html>");
?>