<?php

/**
  This file is part of MediaWikiVLEAdapter.
  
  MediaWikiVLEAdapter is a property of the Intelligent & Cooperative Systems 
  Research Group (GSIC) from the University of Valladolid (UVA). 
  
  Copyright 2011 GSIC (UVA).

  MediaWikiVLEAdapter is licensed under the GNU General Public License (GPL) 
  EXCLUSIVELY FOR NON-COMMERCIAL USES. Please, note this is an additional 
  restriction to the terms of GPL that must be kept in any redistribution of
  the original code or any derivative work by third parties.

  If you intend to use MediaWikiVLEAdapter for any commercial purpose you can 
  contact to GSIC to obtain a commercial license at <glue@gsic.tel.uva.es>.

  If you have licensed this product under a commercial license from GSIC,
  please see the file LICENSE.txt included.

  The next copying permission statement (between square brackets []) is 
  applicable only when GPL is suitable, this is, when MediaWikiVLEAdapter is 
  used and/or distributed FOR NON COMMERCIAL USES.
  
  [ You can redistribute MediaWikiVLEAdapter and/or modify it under the 
    terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
  ]
*/

/*
 * This page is used to show delete dialog.
 *
 * This page shows the result of delete_instnace page.
 *
 *
 * @access public 
 * @author Javier Aragon
 * @version 2011/05/31-0.1
 * @package php/delete
 */
print("<html>");
	
	// GlueletManagerClient library required.
	require_once('../classes/rest/GlueletManagerRestClient.php');
	// Internazionalitacion library required.
	require_once('../classes/i18n/I18NGlueLibMessages.php');
	// Needs to import deafutl functions Library.
	require_once('../lib.php');
	// get the language user preference from $_GET parameteres.
	$lang = $_GET['lang'];
	if (!$lang || $lang==null || $lang=="")
		// if there is no language parameter then create an internationalization object and set defatul language to English.
		$I18N = new I18NGlueLibMessages('en');
	else
		// create the internationalization object.
		$I18N = new I18NGlueLibMessages($lang);

	// print head tags.
	print("<head>");
		print("<title>");
		print("</title>");
	print("<head>");
	
	
	//print body tag.
	print("<body>");
	
	
		// Get params:
		// the instance id parameter.
		$instances = $_GET['instance'];
		// the caller user parameter.
		$user = $_GET['userid'];
		// the userlist to get instance.
		$userlist = $_GET['userlist'];
		// the url where is the glueletmanager.
		$glueletmanager = $_GET['glueletmanager'];
		
		// if any error at parameters die and show error message.
		if (!$glueletmanager || !$user || !$instances || !$userlist || $glueletmanager=="" || $user=="" || $instances=="" || $userlist=="") {
			die($I18N->getI18NMessage('errorinparams'));
		}
		
		//get the instance list into an array.
		$instancesarray = Array();
		$instancesarray[1] = $instances;
		if ($instancesarray && $instancesarray!=null){
			foreach ($instancesarray as $i => $value) {
				// For each instance to delete print a iframe that it's goning to delete the respective instance.
				// Create a REST client instance.
				$rest_client = new GlueletManagerRestClient($user, $userlist, $glueletmanager);
				// Call to get_instance. Needs to give MediaWiki registered users list as a parameter cause If there's any failure trying to view an instance 
				// this function try to post the user's list to solve the porblem that a user is not allowed to see this instance.
				$result = $rest_client->gluelet_get_instance_onedit($value);
				// If get_instance request is successfully the return 'parsetext'.
				if ($result[0]){
					//print( "<iframe align=center id='view_instance_".$value."'  width='100%' height='50%'  style='display:none' onload=iframeload('".$value."') src='".$result[1]."'> <p>".$I18N->getI18NMessage('iframerrormsg')."</p> </iframe>");
					print( "<iframe width='100%' height='100%' onload=iframeload('".$value."') FRAMEBORDER=NO align=center src='".$result[1]."'  name='view_instance2_".$value."' id='view_instance2_".$value."' > <p>".$I18N->getI18NMessage('iframerrormsg')."</p> </iframe>");
					//$instance_url = glue_get_instnace_url($result[1]);
					//print("<div>".$instance_url."</div>");
				} else{
					$result[1]->print_get_instance_on_article_error($value, $user, $glueletmanager, $lang);
				}
		}
		} else{
			// print an error if there isn't any instance.
			print($I18N->getI18NMessage('noinstancestodeleteerror'));
		}
		
	//print end body tag.
	print("</body>");
	
//print end haml tag.
print("</html>");
?>
<script type="text/javascript">
	/*
	* When the iframe is loaded hide the 'loading image' and show the delete instance request.
	*
	*/
	function iframeload(instance){
		if (window.top.document.getElementById('glueloadingwindowinstance_2'+instance))
			window.top.document.getElementById('glueloadingwindowinstance_2'+instance).style.display='none';
		else if (window.top.document.getElementById('glueloadingwindowinstance_'+instance))
			window.top.document.getElementById('glueloadingwindowinstance_'+instance).style.display='none';

		if (window.top.document.getElementById('ViewGlueletIframe'+instance)){
			window.top.document.getElementById('ViewGlueletIframe'+instance).height='100%';
			window.top.document.getElementById('ViewGlueletIframe'+instance).style.visibility='visible';
		} else if (window.top.document.getElementById('glue_instance_'+instance)){
			window.top.document.getElementById('glue_instance_'+instance).height='600';
			window.top.document.getElementById('glue_instance_'+instance).style.visibility='visible';
		}
	}
	
</script>