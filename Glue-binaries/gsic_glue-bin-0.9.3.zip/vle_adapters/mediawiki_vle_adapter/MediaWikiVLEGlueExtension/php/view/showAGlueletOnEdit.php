<!--
  This file is part of MediaWikiVLEAdapter.
  
  MediaWikiVLEAdapter is a property of the Intelligent & Cooperative Systems 
  Research Group (GSIC) from the University of Valladolid (UVA). 
  
  Copyright 2011 GSIC (UVA).

  MediaWikiVLEAdapter is licensed under the GNU General Public License (GPL) 
  EXCLUSIVELY FOR NON-COMMERCIAL USES. Please, note this is an additional 
  restriction to the terms of GPL that must be kept in any redistribution of
  the original code or any derivative work by third parties.

  If you intend to use MediaWikiVLEAdapter for any commercial purpose you can 
  contact to GSIC to obtain a commercial license at <glue@gsic.tel.uva.es>.

  If you have licensed this product under a commercial license from GSIC,
  please see the file LICENSE.txt included.

  The next copying permission statement (between square brackets []) is 
  applicable only when GPL is suitable, this is, when MediaWikiVLEAdapter is 
  used and/or distributed FOR NON COMMERCIAL USES.
  
  [ You can redistribute MediaWikiVLEAdapter and/or modify it under the 
    terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
  ]
-->

<!--
 @author Javier Aragon
-->  
 

<script type='text/javascript' language='javascript'>
	/*
	* When the body is loaded/unloaded hide/how the 'loading image' and show the delete instance request.
	*/
	function cargargluelet(){
		window.top.document.getElementById('loadingdiv').style.display='none';
		window.top.document.getElementById('ViewGlueletIframe').style.visibility='visible';
	}
</script>
<?php
print("<html>");



//print styles for gluelet info.
print ("<style>");
	print(".sangrar {padding-left: 50px;}");
	print(".sangrar2{ padding-left: 15px; }</style>");
print ("</style>");


// GlueletManagerClient library required.
require_once('../classes/rest/GlueletManagerRestClient.php');
// Internazionalitacion library required.
require_once('../classes/i18n/I18NGlueLibMessages.php');
// ponemos idioma por defecto 'español'
$lang = $_GET['lang'];
if (!$lang || $lang==null || $lang=="")
	// if there is no language parameter then create an internationalization object and set defatul language to English.
	$I18N = new I18NGlueLibMessages('en');
else
	// create the internationalization object.
	$I18N = new I18NGlueLibMessages($lang);


//print head tags.
print("<head>");
print("<title>".$I18N->getI18NMessage('showglueletpagetitle')."</title>");
print("</head>");

// print body tag.
print("<body onload='cargargluelet()'>");

	// Get params:
	// the instance id.
	$toolid = $_GET['toolid'];
	// the caller user parameter.
	$user = $_GET['userid'];
	// the mediawiki registerd users list.
	$userlist = $_GET['userlist'];
	// the url where is the glueletmanager.
	$glueletmanager = $_GET['glueletmanager'];
	
	// if any error at parameters die and show error message.
	if (!$toolid || !$glueletmanager || !$user || !$userlist || $toolid=="" || $glueletmanager=="" || $user=="" || $userlist=="") {
		die($I18N->getI18NMessage('errorinparams'));
	}
	
	// Create a REST client instance.
	$rest_client = new GlueletManagerRestClient($user, $userlist, $glueletmanager);
	// Call to get_instance. Needs to give MediaWiki registered users list as a parameter cause If there's any failure trying to view an instance 
	// this function try to post the user's list to solve the porblem that a user is not allowed to see this instance.
	$result = $rest_client->gluelet_get_instance_onedit($toolid);
	// If get_instance request is successfully the return 'parsetext'.
	if ($result[0]){
		if ($result && $result[1] && $result[1] !=""){
			// print javascripts to show/hide gluelet info
			print("<script type='text/javascript' language='javascript'>");
			/*
			* JavaScript to show an hide get_instance call info.
			*/
			print("	function showit(){");
			print("		if (document.getElementById('instanceinfo').style.display==''){");
			print("			document.getElementById('instanceinfo').style.display='none';");
			print("			document.getElementById('inflabel').src='./images/plus_add.png';");
			print("		}else if (document.getElementById('instanceinfo').style.display=='none'){");
			print("			document.getElementById('instanceinfo').style.display='';");
			print("			document.getElementById('inflabel').src='./images/minus_remove.png';");
			print("		}");
			print("}");
			print("</script>");
			
			// use call information as a DOM Element to print it into a hidden div. It can be shown when click on instance title.
			$doc = new DOMDocument();
        	$doc->loadXML($result[2]);
			$asDom = $doc;
			//$asDom = DOMDocument::loadXML( $result[2] );
			
			echo "<div id=imageshowinfo style='float:left;width:100%'><b style=cursor:pointer onclick='showit()'> <img id='inflabel' height='10px' width='10px' src='./images/plus_add.png' /><u>".$I18N->getI18NMessage('infglueletlabel')."</u></b></div>";
			echo "<div id='instanceinfo' style='display:none;float:left' class='sangrar'><table>";
			echo "<tr><td><b>".$I18N->getI18NMessage('authorlabel')."</b></td><td><span class=sangrar2>" 	. $asDom->getElementsByTagName('author')->item(0)->textContent 			. '</span><br></td></tr>';
			echo "<tr><td><b>".$I18N->getI18NMessage('instanceidlabel')."</b></td><td><span class=sangrar2>" 		. $asDom->getElementsByTagName('id')->item(0)->textContent 				. '</span><br></td></tr>';
			echo "<tr><td><b>".$I18N->getI18NMessage('linklabel')."</b></td><td><span class=sangrar2>" 	. $asDom->getElementsByTagName('link')->item(0)->getAttribute('href') 	. '</span><br></td></tr>';
			echo "<tr><td><b>".$I18N->getI18NMessage('updateddatelabel')."</b></td><td><span class=sangrar2>" . $asDom->getElementsByTagName('updated')->item(0)->textContent 		. '</span><br></td></tr>';
			echo "</table></div>";
			// the instance url iframe.
			echo "<p/><center><iframe style='float:left' src='". $result[1]."' align='center' FRAMEBORDER=1 width='100%' height='90%' id=tool> <p>".$I18N->getI18NMessage('iframerrormsg')."</p> </iframe></center>";
		
		} else {
			// If there is no get_instance result, the call failed, show a error message at article page.
			echo "<p>- ".$I18N->getI18NMessage('nodisplayerrormsg')." --> ". $input ."</p>";
		}
	} else{
		// If there is an error at get_instance request;
		$result[1]->print_get_instance_error($toolid, $user, $glueletmanager, $lang);
	}
	



//print end body tag.
print("</body>");
//print end html tag.
print("</html>");

?>