<?php

/**
  This file is part of MediaWikiVLEAdapter.
  
  MediaWikiVLEAdapter is a property of the Intelligent & Cooperative Systems 
  Research Group (GSIC) from the University of Valladolid (UVA). 
  
  Copyright 2011 GSIC (UVA).

  MediaWikiVLEAdapter is licensed under the GNU General Public License (GPL) 
  EXCLUSIVELY FOR NON-COMMERCIAL USES. Please, note this is an additional 
  restriction to the terms of GPL that must be kept in any redistribution of
  the original code or any derivative work by third parties.

  If you intend to use MediaWikiVLEAdapter for any commercial purpose you can 
  contact to GSIC to obtain a commercial license at <glue@gsic.tel.uva.es>.

  If you have licensed this product under a commercial license from GSIC,
  please see the file LICENSE.txt included.

  The next copying permission statement (between square brackets []) is 
  applicable only when GPL is suitable, this is, when MediaWikiVLEAdapter is 
  used and/or distributed FOR NON COMMERCIAL USES.
  
  [ You can redistribute MediaWikiVLEAdapter and/or modify it under the 
    terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
  ]
*/

/*
 * This page is used to delete an instance from GLUE server.
 *
 * This page try to delete a gluelet instance from glueletmanager.
 * IF the request successful this page shows a OK message and in any other case show a error message with detailed information.
 *
 * @access public 
 * @author Javier Aragon
 * @version 2011/05/31-0.1
 * @package php/delete
 */
print("<html>");

	// GlueletManagerClient library required.
	require_once('../classes/rest/GlueletManagerRestClient.php');
	// Internazionalitacion library required.
	require_once('../classes/i18n/I18NGlueLibMessages.php');
	// get the language user preference from $_GET parameteres.
	$lang = $_GET['lang'];
	// if there is no language parameter then set English.
	if (!$lang || $lang==null || $lang=="")
		// if there is no language parameter then create an internationalization object and set defatul language to English.
		$lang = "en";
		
	// create the internationalization object.
	$I18N = new I18NGlueLibMessages($lang);
		
		
	// print head tags.
	print("<head>");
		print("<title>");
		print("</title>");
	print("<head>");

	// print body tag.
	print("<body>");
	
		// Get params:
		// the instance id parameter.
		$instance = $_GET['instance'];
		// the caller user parameter.
		$user = $_GET['user'];
		// the url where is the glueletmanager.
		$glueletmanager = $_GET['glueletmanager'];
		
		// if any error at parameters die and show error message.
		if (!$glueletmanager || !$user || !$instance || $glueletmanager=="" || $user=="" || $instance=="") {
			die($I18N->getI18NMessage('errorinparams'));
		}
		
		// Create a GlueletManger client object.
		$rest_client = new GlueletManagerRestClient($user, "", $glueletmanager);
		// Delete instance request.
		$result = $rest_client->gluelet_delete_instance($instance);
		
		
		
		if ( $result[0] == false){		
			// If instance request has any problem show error details.
			// $result[1] is instance of GlueletManagerClientError.
			$result[1]->print_delete_intance_error_with_deatils($instance, $glueletmanager, $user, $lang);
			
		} else{
			// if there is no error at delete request show successful message.
			print("<p:0>".$I18N->getI18NMessage('defaultokmessage')."&nbsp;&nbsp;&nbsp; <b><font color=blue>'" . $instance . "'</font></b> " . $I18N->getI18NMessage('instacedeleted') . "</p>" );
			print("<p><font width=80% size=4px>".$I18N->getI18NMessage('noforgetsavearticlemessage')."</font></p:0>");
		}
	
	//print end body tag.
	print("</body>");

//print end html tag.
print("</html>");
?>


