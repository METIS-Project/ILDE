﻿<?php

/**
  This file is part of MediaWikiVLEAdapter.
  
  MediaWikiVLEAdapter is a property of the Intelligent & Cooperative Systems 
  Research Group (GSIC) from the University of Valladolid (UVA). 
  
  Copyright 2011 GSIC (UVA).

  MediaWikiVLEAdapter is licensed under the GNU General Public License (GPL) 
  EXCLUSIVELY FOR NON-COMMERCIAL USES. Please, note this is an additional 
  restriction to the terms of GPL that must be kept in any redistribution of
  the original code or any derivative work by third parties.

  If you intend to use MediaWikiVLEAdapter for any commercial purpose you can 
  contact to GSIC to obtain a commercial license at <glue@gsic.tel.uva.es>.

  If you have licensed this product under a commercial license from GSIC,
  please see the file LICENSE.txt included.

  The next copying permission statement (between square brackets []) is 
  applicable only when GPL is suitable, this is, when MediaWikiVLEAdapter is 
  used and/or distributed FOR NON COMMERCIAL USES.
  
  [ You can redistribute MediaWikiVLEAdapter and/or modify it under the 
    terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
  ]
*/

/** 
 * @author Javier Aragon
 */  
 
class xforms_to_form {

	// --- ATTRIBUTES ---  
	/** Configuration form definition loaded as DOM document */
	protected $_xform;
	/** XPath evaluator associated to _xmlDefinition */
	protected $_xpathForDefinition;
	/** Filled instance created as DOM document */
    protected $_xmlInstance;
    /** XPath evaluator associated to _xmlInstance */
    protected $_xpathForInstance;
	
	protected $_text_to_save;
	
	/** 
	 * xforms_to_form Constructor.
	 * 
	 * @access 	public 
	 * @author 	Javier Aragon, <jaragoncaz@gmail.com> 
	 * @param 	$from   String		String the form definiton: fields, submit, etc.
	 * @return 	void 
	 **/
	function __construct($form){
		$this->_xform = $form;
		
		$this->_xpathForDefinition = new DOMXPath($this->_xform);
        $this->_xpathForDefinition->registerNamespace("xf", "http://www.w3.org/2002/xforms");
        $this->_xpathForDefinition->registerNamespace("h", "http://www.w3.org/1999/xhtml");
	}
	
	
	/**
     * Configuration form specific set up. Abstract method overriden from moodleform inheritance.
     * All the data fields must be defined inside, including the optional ones.
     * Custom data passed through the second parameter of class constructor can be found in _customdata inherited attribute.
     * In this case, an XForms definition file saved in _customdata is parsed an UI elements are generated to satisfy its contents.
     *
     * LIMITATION: only <inpyut> and <upload> IU elements are parsed.
	 *
	 * @return	boolean		returns true if any filed has been printed or false in any other case.
     */
	function printformfields(){
			
		$xformUINodes = $this->_xpathForDefinition->query("//xf:*");
		
		$printed = 0;
		
		 for ($i=0; $i<$xformUINodes->length ; $i++) {
			$UINode = $xformUINodes->item($i);
			switch($UINode->localName){
			
			// Add more cases to parser more xforms elements
			
			// this case is to parse a input field
			case "input":
				 $this->printXFormsInput($UINode);
				 $printed++;
				break;
				
			// this case is to parse a file field
			case "upload":
				$this->printXFormsUpload($UINode);
				$printed++;
				break;
			
			//select element
			case "select1":
				$this->printXFormsSelect1($UINode);
				$printed++;
				break;
				
			//multi-select element
			case "select":
				$this->printXFormsSelect($UINode);
				$printed++;
				break;
			
			case "submit":
				break;
			
			case "label":
				break;
			
			// Nothing to do in dafult case.
			default:
				;
			}			
		 }
		 
		 // si no se han imprimido campos.. ¿no hay nada que configurar?
		 if ($printed <= 0){
			return false;
		 }
		 
		 // si que se ha imprimido algun campo del formulario.
		 return true;
	}

	
	
	
	/**
     * Reads a XForms 'input' element definition and inserts a proper moodleform input element in the form.
     *
     * LIMITATION: use '@ref' attribute for generating the name of the form element; it doesn't consider 'bind' XForms elements/attributes
     * LIMITATION: XForms label is considered as required
     * LIMITATION: XSD type checks are not considered
     *
     * @param $UINode   DOM node containing the XForms 'input' element
     */
	protected function printXFormsInput($UINode) {

        // extract data from XForms 'input' element
        $labels = $this->_xpathForDefinition->query("xf:label", $UINode);
        $refs = $this->_xpathForDefinition->query("@ref", $UINode);
		$fieldid = $this->encodeXFormsInfo("input", "", $refs->item(0)->value);
		
        //$element_name = $this->path_2_element($refs->item(0)->value);
        $element_name = $this->encodeXFormsInfo("input", "", $refs->item(0)->value);
		
        //new text element in form
        $label = $labels->item(0)->textContent;
		
        $default = $this->_xpathForDefinition->query("//xf:instance".$refs->item(0)->value)->item(0)->textContent;

		print ("<p>".$label."<input name='".$fieldid."' type='text' value='".$default."'/></p>");
    }

	
	
	/**
     * Reads a XForms 'upload' element definition and inserts a proper moodleform upload element in the form.
     *
     * LIMITATION: use '@ref' attribute for generating the name of the form element; it doesn't consider 'bind' XForms elements/attributes
     * LIMITATION: XForms label is considered as required
     *
     * @param $UINode   DOM node containing the XForms 'upload' element
     */
	  protected function printXFormsUpload($UINode) {
	  
	  
		// extract data from XForms 'upload' element
        $labels = $this->_xpathForDefinition->query("xf:label", $UINode);
        $refs = $this->_xpathForDefinition->query("@ref", $UINode);
        //$element_name = $this->path_2_element($refs->item(0)->value);
		
		$label = $labels->item(0)->textContent;
		$fieldid = $this->encodeXFormsInfo("upload", "", $refs->item(0)->value);

        // new upload element in form
		print("<INPUT TYPE='hidden' name='MAX_FILE_SIZE' value='10000000' />");
		print("<p>".$label."<input name='".$fieldid."' type='file'  size='20' value='".$labels->item(0)->textContent."' '></p>");

        // extract XForms 'filename' element; considered as optional
        $filenames = $this->_xpathForDefinition->query("xf:filename", $UINode);
        if ($filenames->length > 0) {
            $element_name = $this->encodeXFormsInfo("upload", "filename", $refs->item(0)->value);
            $refs = $this->_xpathForDefinition->query("@ref", $filenames->item(0));
			print("<INPUT TYPE='hidden' name='".$element_name."' value='".$refs->item(0)->value."'>");
        }

        // extract XForms 'mediatype' element; considered as optional
        $mediatypes = $this->_xpathForDefinition->query("xf:mediatype", $UINode);
        if ($mediatypes->length > 0) {
            $element_name = $this->encodeXFormsInfo("upload", "mediatype", $refs->item(0)->value);
            $refs = $this->_xpathForDefinition->query("@ref", $mediatypes->item(0));
            print("<INPUT TYPE='hidden' name='".$element_name."' value='".$refs->item(0)->value."'>");
        }

    }
    
     /**
     * Reads a XForms 'select1' element definition and inserts a proper select element in the form.
     *
     * LIMITATION: use '@ref' attribute for generating the name of the form element; it doesn't consider 'bind' XForms elements/attributes
     * LIMITATION: XForms label is considered as required
     * LIMITATION: XSD type checks are not considered
     *
     * @param $UINode   DOM node containing the XForms 'select1' element
     */
	protected function printXFormsSelect1($UINode) {

        // extract data from XForms 'select1' element
        $labels = $this->_xpathForDefinition->query("xf:label", $UINode);
        $refs = $this->_xpathForDefinition->query("@ref", $UINode);
		$fieldid = $this->encodeXFormsInfo("select1", "", $refs->item(0)->value);
		
        //$element_name = $this->path_2_element($refs->item(0)->value);
        $element_name = $this->encodeXFormsInfo("select1", "", $refs->item(0)->value);
		
        //new text element in form
        $label = $labels->item(0)->textContent;
		
        $default = $this->_xpathForDefinition->query("//xf:instance".$refs->item(0)->value)->item(0)->textContent;

		$item_nodes = $this->_xpathForDefinition->query("xf:item", $UINode);
		print ("<p>".$label."<select name='".$fieldid."'>");
		foreach($item_nodes as $item){
        	$item_label = $this->_xpathForDefinition->query("xf:label", $item)->item(0)->textContent;
        	$item_value = $this->_xpathForDefinition->query("xf:value", $item)->item(0)->textContent;
        	print ("<option value='".$item_value."'");
        	if ($default!=null && strcmp($default, $item_value)==0){
        		print (" selected ");
        	}
        	print (">".$item_value."</option>");
        } 
		print ("</select></p>");
    }
    
     /**
     * Reads a XForms 'select' element definition and inserts a proper multi-select element in the form.
     *
     * LIMITATION: use '@ref' attribute for generating the name of the form element; it doesn't consider 'bind' XForms elements/attributes
     * LIMITATION: XForms label is considered as required
     * LIMITATION: XSD type checks are not considered
     *
     * @param $UINode   DOM node containing the XForms 'select' element
     */
	protected function printXFormsSelect($UINode) {

        // extract data from XForms 'select1' element
        $labels = $this->_xpathForDefinition->query("xf:label", $UINode);
        $refs = $this->_xpathForDefinition->query("@ref", $UINode);
		$fieldid = $this->encodeXFormsInfo("select", "", $refs->item(0)->value);
		
        //$element_name = $this->path_2_element($refs->item(0)->value);
        $element_name = $this->encodeXFormsInfo("select", "", $refs->item(0)->value);
		
        //new text element in form
        $label = $labels->item(0)->textContent;
		
		if ($this->_xpathForDefinition->query("//xf:instance".$refs->item(0)->value)->length > 0){
        	$default = $this->_xpathForDefinition->query("//xf:instance".$refs->item(0)->value)->item(0)->textContent;
        	$checked_values = explode(';', $default);
        }else{
        	$default = null;
        }

		$item_nodes = $this->_xpathForDefinition->query("xf:item", $UINode);
		print ("<p>".$label."</p>");
		foreach($item_nodes as $item){
        	$item_label = $this->_xpathForDefinition->query("xf:label", $item)->item(0)->textContent;
        	$item_value = $this->_xpathForDefinition->query("xf:value", $item)->item(0)->textContent;
        	print ("<input type='checkbox' name='" . $element_name. "_".$item_value."' value='".$item_value."'");
        	
        	if ($default != null){
        		for ($i=0; $i < count($checked_values); $i++){
        			if (strcmp($checked_values[$i],$item_value)==0){
        				print(" checked ");
        			}
        		}
        	}
        	print("> ". $item_label);    	
        	print ("<br>");
        } 
    }


	
	/**
     * Reads a XForms 'label' element definition and inserts a proper moodleform label element in the form.
     *
     * LIMITATION: use '@ref' attribute for generating the name of the form element; it doesn't consider 'bind' XForms elements/attributes
     * LIMITATION: XForms label is considered as required
     *
     * @param $UINode   DOM node containing the XForms 'label' element
     */
	protected function printXFormsLabel($nodeContent){

		/*
		$refs = $this->_xpathForDefinition->query("@ref", $nodeContent);
		$labels = $this->_xpathForDefinition->query("xf:label", $nodeContent);
		print(1 . $refs->item(0)->value);
		print(1 . $labels->item(0)->value);
		*/
		print ("<p>".$nodeContent->textContent."</p>");
	}
	
	

	/**
     * Create an XForms XML response with the data from the filled form.
     *
     * @return  string      Serialized XML containing the XForms instance with the data from the form.
     */
	public function buildXFormsInstance() {

        $this->_xmlInstance = new DOMDocument();
        $instance = $this->getXFormsInstanceDefinition();      // get the XML <instance> node defined in the XForms configuration file
        if ($instance && $child = $instance->firstChild) {
            /// clone <instance> children to the XML response
            while ($child) {
                $this->_xmlInstance->appendChild($this->_xmlInstance->importNode($child, true));
                $child = $child->nextSibling;
            }
            /// initialize a new XPath helper
            $this->_xpathForInstance = new DOMXPath($this->_xmlInstance);
            $this->_xpathForInstance->registerNamespace("xf", "http://www.w3.org/2002/xforms");
            $this->_xpathForInstance->registerNamespace("h", "http://www.w3.org/1999/xhtml");
            $this->_xpathForInstance->registerNamespace("xsi", "http://www.w3.org/2001/XMLSchema-instance");

            /// bind data from filled input controls to XML response
            $filenames_to_save = array();
            $mediatypes_to_save = array();
            $formData = $this->get_data();
            $multi_selects_values = array();  //array where the checked values for each multi-select are stored
            foreach ((array)$formData as $element => $value) {      // 'foreach' through filled input controls
                $xforms_info = $this->decodeXFormsInfo($element);
                $element_tag = $xforms_info[0];
                $attribute_name = $xforms_info[1];
                $path = $xforms_info[2];                            // get the path to the binding node
                if ($element_tag == 'input') {
                    // <input> in original XForm definition
                    $this->bindXFormsText($path, $value);   // just bind the text

                } else if ($element_tag == 'select1'){
                	$this->bindXFormsText($path, $value);	//just bin the value of the selected option
                } else if ($element_tag == 'select'){
                	
                	if ($value != 0) //If the checkbox value is 0, the checkbox has not been checked
                	{
                		$select_name = substr($path, 0, strrpos($path, "/")); //get the multi-select name
                		//add the value checked to the list of checked values for that multi-select
                		$multi_selects_values[$select_name][]=$value;
                	}
                	//$this->bindXFormsText($path, $value);
                }
                
                else if ($element_tag == 'upload') {
                    if (!$attribute_name) {
                        // nothing to do now, uploaded contents are processed later

                    } else if ($attribute_name == 'filename') {
                        // original name of an uploaded file; save
                        $filenames_to_save[$path] = $value;

                    } else if ($attribute_name == 'mediatype') {
                        // original name of an uploaded file; save
                        $mediatypes_to_save[$path] = $value;
                    }
                }
            }
            foreach($multi_selects_values as $select_name => $checked_values){
            	//Join the values by ';'
            	$value_string = implode(';', $checked_values);
            	$this->bindXFormsText($select_name, $value_string);
            }
			
            /// bind uploaded files to XML response
			$filesuploaded = $_FILES;
			foreach ($filesuploaded as $key => $value) {
				if (!$this->is_file_error($value)){
					if ($value['name'] && $value['tmp_name']) {
						// read the file
 
						$file_handle = fopen($value['tmp_name'], 'rb');
						$content = fread($file_handle, filesize($value['tmp_name']));
						fclose($file_handle);
						
						$xforms_info = $this->decodeXFormsInfo($key);
						$path = $xforms_info[2];
						$this->bindXFormsUpload($path, $content, $value, $filenames_to_save, $mediatypes_to_save);
					}
				}
			}

        } // else nothing to do, no instance in the form file or empty instance

        return $this->_xmlInstance;
	}
	
	
	
	/**
     * Insert data and metadata from an uploaded file as the text content and attributes of an XML node specified by an XPath path through the filled XForms instance.
     *
     * @param   string      $path               XPath path to the XML node (element or attribute), descendant of <instance>, where the value must be bound.
     * @param   string      $content            String with the file raw content.
     * @param   array       $file_info          Data about upload saved by Moodle code.
     * @param   array       $filenames_to_save  XPath paths to the XML nodes where file names must be inserted.
     * @param   array       $mediatypes_to_save XPath paths to the XML nodes where media types must be inserted.
     */
    protected function bindXFormsUpload($path, $content2, $file_info, $filenames_to_save, $mediatypes_to_save) {

		/// encode file content
        $fulltype = $this->get_instance_element_type($path, null);
        strtok($fulltype, ":"); // take off the namespace prefix
        $type = strtok(":");
		
		
        if ($type == "hexBinary") {
			$content2 = bin2hex($content2);

		} else if ($type == "base64Binary") {
            $content2 = base64_encode($content2);

        } else if ($type == "anyURI") {
            error(get_string('anyURI_unavailable_yet_em', GLUELET_MOD));

        } else
            error(get_string('invalid_type_for_XForms_upload_em', GLUELET_MOD) . " ($fulltype)");


        /// bind file content
        $this->bindXFormsText($path, $content2, null, true);

        /// bind file metadata
        $contexts = $this->_xpathForInstance->query($path);
        if ($contexts->length > 0) {
            $context = $contexts->item(0);

			// insert filename
            if (isset($filenames_to_save[$path])){
                $this->bindXFormsText($filenames_to_save[$path], $file_info['name'], $context);
			}
			
            // insert mediatype
            if (isset($mediatypes_to_save[$path])){
                $this->bindXFormsText($mediatypes_to_save[$path], $file_info['type'], $context);
			}

        }
    }
	
	
	///////////////////////
    // Protected methods //
    ///////////////////////

	
	/**
	*	Tries to get file form data as they were sent. Gets data sent by $ _POST and $ _GET,
	*   stores it in the variable _formData (array with the info).
	*/
	protected function get_data(){
		
		// define the variable that will store file data
		$result = array();
		
		if ($_SERVER){
			if ($_SERVER['REQUEST_METHOD']){
				
				$method = $_SERVER['REQUEST_METHOD'];

				if ($method != ''){
				
					if ($method == 'GET'){
					// try to get file data from $_GET
						if ($_GET && !empty($_GET) ){
							// merge it with the returned value
							$result= array_merge ($result, $_GET);
						}
						$result = $this-> addFiles();
						
					} else if ($method == 'POST'){
						// try to get file data from $_POST
						if ($_POST && !empty($_POST) ){
							// merge it with the returned value
							$result= array_merge ($result, $_POST);
						}
						$result = $this-> addFiles($result);
						
					} else {
						die ('You Need To Submit data here !!! ');
					}
				} else {
					die ('How can you get this with out no request method?');
				}
				
				return $result;
				}
		}
	
	}
	
	
	/**
	*	Tries to get file form data as they were sent. Gets data sent by $_FILEs
	*   stores it in the variable _formData (array with the info).
	*/
	protected function addFiles($result){
		if ($_FILES){
			if (!empty($_FILES)) {
				return array_merge($result, $_FILES);
			}
		}
		return $result;
	}
	
	
    /**
     * Access to the 'instance' element node in the XForms definition tree
     */
    protected function getXFormsInstanceDefinition() {
        $instances = $this->_xpathForDefinition->query("//xf:model/xf:instance");
        if ($instances->length > 0)
            return $instances->item(0);
        else
            return null;
    }
	
	
	
	 
	
	/*
	* Returns a string with the element type or null if not found.
	*
	* @param   	string      $path           XPath path to the XML node (element or attribute), descendant of <instance>, where the value must be bound.
	* @param   	DOMNode     $context        Element, descendant of <instance>, to take as root of $path; if null, <instance> is used.
	* @return	String						The element type.
	*/
	protected function get_instance_element_type($path, $context) {
        // search for the binding node
        $path .= "/@xsi:type";
        if ($context)
            $binding_targets = $this->_xpathForInstance->query($path, $context);
        else
            $binding_targets = $this->_xpathForInstance->query($path);

        if ($binding_targets->length > 0) {
            $target = $binding_targets->item(0);
            return $target->nodeValue;
        }
        return null;
    }
	
	 /**
     * Insert a string as the text content of an XML node specified by an XPath path through the filled XForms instance.
     *
     * @param    string      $path           XPath path to the XML node (element or attribute), descendant of <instance>, where the value must be bound.
     * @param    string      $value          String value to be bound.
     * @param    DOMNode     $context        Element, descendant of <instance>, to take as root of $path; if null, <instance> is used.
     * @param    boolean     $eraseChildren  When 'true', children elements of the target node are erased before assigning text content.
     */
    protected function bindXFormsText($path, $value, $context = null, $eraseChildren = false) {
        // search for the binding node
        if ($context)
            $binding_targets = $this->_xpathForInstance->query($path, $context);
        else
            $binding_targets = $this->_xpathForInstance->query($path);

        if ($binding_targets->length > 0) {
            // $path specifies an existing node in <instance> definition; $value will become its contained text
            $target = $binding_targets->item(0);
            $child = $target->firstChild;
            $firstTextChild = null;
            while ($child) {
                $to_remove = null;
                if ($child->nodeType == XML_TEXT_NODE) {
                    if (!$firstTextChild)
                        $firstTextChild = $child;
                    else
                        $to_remove = $child;
                } else if ($eraseChildren && $child->nodeType == XML_ELEMENT_NODE) {
                    $to_remove = $child;
                }
                $child = $child->nextSibling;
                if ($to_remove)
                    $target->removeChild($to_remove);
            }
            if ($firstTextChild)
                $firstTextChild->nodeValue = $value;
            else
                $target->appendChild($this->_xmlInstance->createTextNode($value));

        } else {
            // $path specifies a non-existing node in <instance> definition; this is only valid when the node is an XML attribute
            if ($context && substr($path, 0, 1) == "@") {
                $att = $context->appendChild($this->_xmlInstance->createAttribute(substr($path, 1)));
                $att->nodeValue = $value;
            }
        }
    }
	
	
	
	/**
     * Generates a name suitable for a moodleform UI element using data from an XForms input element.
     *
     * @param   string  $element    XForms element tag.
     * @param   string  $attribute  XForms attribute name.
     * @param   string  $path       XPath binding path.
     * @return  string              Name for a moodleform input control.
     */
	protected function encodeXFormsInfo($element, $attribute, $path) {
        return $element . "_" . $attribute . "_" . str_replace("/", "_", $path);
    }
	
	
	/**
     * Generates the original XForms element data corresponding to a moodleform input control from its name.
     *
     * @param   string              $element_name   Element name to convert
     * @return  array of strings                    Element tag, name value and binding path of the original XForms element; fields are null when appropiate.
     */
    protected function decodeXFormsInfo($element_name) {
        $result = array(0 => null, 1 => null, 2 => null);
        $pos_0 = strpos($element_name, '_');
        if ($pos_0 !== FALSE) {
            $pos_1 = strpos($element_name, '_', $pos_0 + 1);
            if ($pos_1 !== FALSE) {
                $result[0] = substr($element_name, 0, $pos_0);
                if ($pos_1 - $pos_0 > 1) {
                    $result[1] = substr($element_name, $pos_0 + 1, $pos_1 - $pos_0 - 1);
                } // else $result[1] stays with null content
                $result[2] = str_replace("_", "/" , substr($element_name, $pos_1 + 1));
            }
        }
        return $result;
    }
	
	/**
	* 	Returns true if there is any error in file and false in any other case.
	*	This function prints an error message if an error is caused by trying to obtain a file or file info send by a POST or GET.
	*
	* @param	Array 	Array with file info.
	* @return	boolena true if error and false in any other case.
	*/
	protected function is_file_error($fileinfo){
					
		if ($fileinfo){
			if (!empty($fileinfo)){
				
					$error_code =  $fileinfo['error'];
					
					switch ($error_code) { 
								
						/**
						*	Value: 0; There is no error, the file uploaded with success. 
						*/
						case UPLOAD_ERR_OK:
							return false;
							
							
						/**
						*	Value: 1; The uploaded file exceeds the upload_max_filesize directive in php.ini. 
						*/
						case UPLOAD_ERR_INI_SIZE:
							print '<p>The uploaded file exceeds the upload_max_filesize directive in php.ini</p>';
							return true;
							
							
						/**
						*	Value: 2; The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form. 
						*/
						case UPLOAD_ERR_FORM_SIZE:
							print '<p>The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form</p>';
							return true;
							
							
						/**
						*	Value: 3; The uploaded file was only partially uploaded. 
						*/
						case UPLOAD_ERR_PARTIAL:
							print '<p>The uploaded file was only partially uploaded</p>';
							return true;
							
							
						/**
						*	Value: 4; No file was uploaded. 
						*/
						case UPLOAD_ERR_NO_FILE:
							// Do not print warning message when user don't upload a file.
							//print '<p>Warning!!! No file was uploaded</p>';
							return true;
							
							
						/**
						*	Value: 6; Missing a temporary folder. Introduced in PHP 4.3.10 and PHP 5.0.3. 
						*/
						case UPLOAD_ERR_NO_TMP_DIR:
							print '<p>Missing a temporary folder</p>';
							return true;
							
							
						/**
						*	Value: 7; Failed to write file to disk. Introduced in PHP 5.1.0. 
						*/
						case UPLOAD_ERR_CANT_WRITE:
							print '<p>Failed to write file to disk</p>';
							return true;
							
							
						/**
						*	Value: 8; A PHP extension stopped the file upload. PHP does not provide a way to 
						*	ascertain which extension caused the file upload to stop; examining the list of loaded 
						*	extensions with phpinfo() may help. Introduced in PHP 5.2.0. 
						*/
						case UPLOAD_ERR_EXTENSION:
							print '<p>File upload stopped by extension</p>';
							return true;

						
						/**
						*	Default value. print it, and return true error 'no try to process it'.
						*/
						default:
							print '<p>Unknown upload error</p>'; 
							return true;
							
					}
			}
		}

		/**
		*	Any case return error. no error_code or no file_info
		*/
		return true;
	}
}



?>