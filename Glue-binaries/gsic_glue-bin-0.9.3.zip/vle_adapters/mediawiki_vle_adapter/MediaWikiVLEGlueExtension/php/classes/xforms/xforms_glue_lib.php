<?php
/**
  This file is part of MediaWikiVLEAdapter.
  
  MediaWikiVLEAdapter is a property of the Intelligent & Cooperative Systems 
  Research Group (GSIC) from the University of Valladolid (UVA). 
  
  Copyright 2011 GSIC (UVA).

  MediaWikiVLEAdapter is licensed under the GNU General Public License (GPL) 
  EXCLUSIVELY FOR NON-COMMERCIAL USES. Please, note this is an additional 
  restriction to the terms of GPL that must be kept in any redistribution of
  the original code or any derivative work by third parties.

  If you intend to use MediaWikiVLEAdapter for any commercial purpose you can 
  contact to GSIC to obtain a commercial license at <glue@gsic.tel.uva.es>.

  If you have licensed this product under a commercial license from GSIC,
  please see the file LICENSE.txt included.

  The next copying permission statement (between square brackets []) is 
  applicable only when GPL is suitable, this is, when MediaWikiVLEAdapter is 
  used and/or distributed FOR NON COMMERCIAL USES.
  
  [ You can redistribute MediaWikiVLEAdapter and/or modify it under the 
    terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
  ]
*/

/** 
 * @author Javier Aragon
 */  
 
class xforms_lib{
    var $namespace;
    var $namespaceXforms;
    var $namespaceEvents;


	# Constructor for xforms lib
	function xforms_lib($ns, $nsxforms, $nsevents){
		$this->namespace = $ns;
		$this->namespaceXforms = $nsxforms;
		$this->namespaceEvents = $nsevents;
    }
    

	
	
	
	
	###################### MEthods for tags ######################
	
	# This method that returns the declaration for the opening HTML tag.
	function htmlTag($customNS='', $customNSnamespace=''){
        $xml = '<html';
        if($this->namespace != '')
            $xml .= ' xmlns="'.$this->namespace.'"';
        if($this->namespaceXforms != '')
            $xml .= ' xmlns:xforms="'.$this->namespaceXforms.'"';
        if($this->namespaceEvents != '')
            $xml .= ' xmlns:ev="'.$this->namespaceEvents.'"';
        if($this->customNS != '' && $this->customNSnamespace != '')
            $xml .= ' xmlns:'.$this->customNS.
                '="'.$this->customNSnamespace.'"';
        $xml .= ' >';
        return $xml;
    }
    
    
    
    
    
    function submissionTag($id, $action, $method = 'post', $ref='',
                           $instance = '', $replace = ''){
        $xml = '<xforms:submission id="'.$id.'" action="'.$action.
            '" method="'.$method.'"';
        if($ref != '')
            $xml .= ' ref="'.$ref.'"';
        if($instance != '')
            $xml .= ' instance="'.$instance.'"';
        if($replace != '')
            $xml .= ' replace="'.$replace.'"';
        $xml .= " />";
        return $xml;
    }
    
    
     function bindTag($nodeset, $relevant = '', $calculate = '',
                     $required = ''){
        $xml = '<xforms:bind nodeset="'.$nodeset.'"';
        if($relevant != '')
            $xml .= ' relevant="'.$relevant.'"';
        if($calculate != '')
            $xml .= ' calculate="'.$calculate.'"';
        $xml .= " />";
        return $xml;
    }
    
    
    
    
    
    
    function dispatchTag($name, $target){
        $xml = '<xforms:dispatch';
        if($name != '')
            $xml .= ' name="'.$name.'"';
        if($target != '')
            $xml .= ' target="'.$target.'"';
        $xml .= " />";
        return $xml;
    }
    
    
    
    
    
    
    function loadTag($resource = '', $ref = '', $show='replace'){
        $xml = '<xforms:load show="'.$show.'"';
        if($ref != '')
            $xml .= ' ref="'.$ref.'"';
        else if($resource != '')
            $xml .= ' resource="'.$resource.'"';
        $xml .= " />";
        return $xml;
    }
    
    
    
    
    
    function insertTag($nodeset, $at, $position = 'after'){
        $xml = '<xforms:insert nodeset="'.$nodeset.'" at="'.$at.
            '" position="'.$position.'" />';
        return $xml;
    }
    
    
    
    
    
    function setvalueTag($ref, $value){
        $xml = '<xforms:setvalue ref="'.$ref.'" value="'.$value.'" />';
        return $xml;
    }
    
    
    
    
    function inputTag($ref, $label = ''){
        $xml = '<xforms:input ref="'.$ref.'">';
        if($label != '')
            $xml .= '<xforms:label>'.$label.'</xforms:label>';
        $xml .= "</xforms:input>";
        return $xml;
    }
    
    
    
    
    function outputTag($value){
        $xml = '<xforms:output value="'.$value.'">';
        $xml .= '</xforms:output>';
        return $xml;
    }
    
    
    
    
    function select1Tag($ref, $label, $itemArray, $itemset,
                        $appearance = 'minimal'){
        $xml = '<xforms:select1 ref="'.$ref.'" appearance="'.
            $appearance.'">';
        $xml .= '<xforms:label>'.$label.'</xforms:label>';
        if(is_array($itemset)){
            $xml .= '<xforms:itemset nodeset="'.$itemset['nodeset'].'">';
            $xml .= '<xforms:label ref="'.$itemset['label'].'" />';
            $xml .= '<xforms:value ref="'.$itemset['value'].'" />';
            $xml .= '</xforms:itemset>';
        }
        else if(is_array($itemArray))
            foreach($itemArray as $value => $label){
                $xml .= '<xforms:item>';
                $xml .= '<xforms:label>'.$label.'</xforms:label>';
                $xml .= '<xforms:value>'.$value.'</xforms:value>';
                $xml .= '</xforms:item>';
            }
			
		// $xml. =	'<xforms:action ev:event="DOMActivate">';
        // $xml. =	'	<xforms:insert nodeset="instance("log")/event" at="last()" position="after"/>';
        // $xml. =	'</xforms:action>';

//            <xforms:setfocus control="in"/>
//         </xforms:action> 
        $xml .= '</xforms:select1>';
        return $xml;
    }
    
	// foreach($itemArray as $value => $label){
    //            $xml .= '<xforms:item>';
    //            $xml .= '<xforms:label>'.$label.'</xforms:label>';
    //            $xml .= '<xforms:value>'.$value.'</xforms:value>';
    //            $xml .= '</xforms:item>';
    //        }
    
    
    
    function commentTag($comment){
        $xml = '<!-- '.$comment.' -->';
        return $xml;
    }
    
    
    
    
    
    function instanceTag($id = '', $instanceXML = '', $src = ''){
        $xml = '<xforms:instance';
        if($id != '')
            $xml .= ' id="'.$id.'"';
        if($src != '')
            $xml .= ' src="'.$src.'"';
        else if($instanceXML != ''){
            $xml .= '>'."\r\n";
            $xml .= $instanceXML;
            $xml .= "\r\n".'</xforms:instance>';
        }
        else
            $xml .= " />";
        return $xml;
    }
    
    
    
    function submitTag($submission, $label='Submit', $ref = ''){
        $xml = '<xforms:submit submission="'.$submission.'"';
        if($ref != '')
            $xml .= ' ref="'.$ref.'"';
        $xml .= ' >';
        $xml .= '<xforms:label>'.$label.'</xforms:label>';
        $xml .= '</xforms:submit>';
        return $xml;
    }
    
    
    
    
    
    
    #### action, events tags
    function actionTagOpen($event){
        $xml = '<xforms:action ev:event="'.$event.'">';
        return $xml;
    }

    function actionTagClose(){
        $xml = '</xforms:action>';
        return $xml;
    }

    function repeatTagOpen($nodeset, $id = ''){
        $xml = '<xforms:repeat nodeset="'.$nodeset.'"';
        if($id != '')
            $xml .= ' id="'.$id.'"';
        $xml .= ' >';
        return $xml;
    }

    function repeatTagClose(){
        $xml = '</xforms:repeat>';
        return $xml;
    }

    function modelTagOpen($id = ''){
        $xml = '<xforms:model';
        if($id != '')
            $xml .= ' id="'.$id.'"';
        $xml .= ' >';
        return $xml;
    }

    function modelTagClose(){
        $xml = '</xforms:model>';
        return $xml;
    }

    function triggerTagOpen($ref, $submission = '', $label = 'default'){
        $xml = '<xforms:trigger ref="'.$ref.'"';
        if($submission != '')
            $xml .= ' submission="'.$submission.'"';
        $xml .= ' >';
        return $xml;
    }

    function triggerTagClose(){
        $xml = '</xforms:trigger>';
        return $xml;
    }
    
    

}

?>
