<?php

/**
  This file is part of MediaWikiVLEAdapter.
  
  MediaWikiVLEAdapter is a property of the Intelligent & Cooperative Systems 
  Research Group (GSIC) from the University of Valladolid (UVA). 
  
  Copyright 2011 GSIC (UVA).

  MediaWikiVLEAdapter is licensed under the GNU General Public License (GPL) 
  EXCLUSIVELY FOR NON-COMMERCIAL USES. Please, note this is an additional 
  restriction to the terms of GPL that must be kept in any redistribution of
  the original code or any derivative work by third parties.

  If you intend to use MediaWikiVLEAdapter for any commercial purpose you can 
  contact to GSIC to obtain a commercial license at <glue@gsic.tel.uva.es>.

  If you have licensed this product under a commercial license from GSIC,
  please see the file LICENSE.txt included.

  The next copying permission statement (between square brackets []) is 
  applicable only when GPL is suitable, this is, when MediaWikiVLEAdapter is 
  used and/or distributed FOR NON COMMERCIAL USES.
  
  [ You can redistribute MediaWikiVLEAdapter and/or modify it under the 
    terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
  ]
*/


/** 
 * Simple class to process internationalized messages, it requires previously include the path file I18N message  with the global $messages variable.
 * The default language is English if user language  preference  is not defined.
 *
 * @access public 
 * @author Javier Aragon
 * @version 2011/05/31-0.1
 * @package php/classes/i18n
 */  
 
require_once(dirname(__FILE__).'/MediaWikiVLEGlueExtension.i18n.php');
 
class I18NGlueLibMessages {
		
	// --- ATTRIBUTES ---  
	// Language selected, English is selected by default
	var $language = "en";

	
	 /** 
	 * I18NGlueLibMessages Contructor.
	 * 
	 * @access 	public 
	 * @author 	Javier Aragon, <jaragoncaz@gmail.com> 
	 * @param 	messages   	String		File path where is declared internationalized message matrix.
	 * @param 	lang   		String      User language selected.
	 * @return 	void 
	 **/
	public function __construct($lang="en"){
		if ($lang && $lang!=null && $lang!=""){
			$this->language = $lang;
		}
	}
	
	
	/** 
	 * Returns a message internationalized given by an identifier.
	 * It returns the message in the language defined at this object if it's found in the internationalization file or  the identifier given as a parameter in any other case.
	 * 
	 * @access 	public 
	 * @author 	Javier Aragon, <jaragoncaz@gmail.com> 
	 * @param 	id   	String		A message identifier to obtain this message internationalized.
	 * @return 	string 
	 **/
	public function getI18NMessage($id=""){
		// Call getI18NLangMessage function with the langauge defined at this object and the identifer given as parameter.
		return $this->getI18NLangMessage($this->language, $id);
	}
	
	/** 
	 * Returns a message internationalized given by the language and the identifier passed as parameters.
	 * It returns the message in the language selected if it's found in the internationalization file or  the identifier given as a parameter in any other case.	
	 * 
	 * @access 	public 
	 * @author 	Javier Aragon, <jaragoncaz@gmail.com> 
	 * @param 	id   	String		A message identifier to obtain this message internationalized.
	 * @param 	lang   	String      User language selected.
	 * @return 	string 
	 **/
	public function getI18NLangMessage($lang="en", $id=""){
		
		// try to obtain the matrix internationalized messages.
		global $messages;
		
		// if lang is not defined try to obtain the language defined at this object (Default English).
		if (!$lang || $lang==null || $lang==""){
			$lang = $this->language;
		}
		
		// if there is any error trying to process $messages from internazionlitation message return the id
		// also return the id if the 'id' is not found in messages or the message to return is empty.
		if (!$messages && $messages==null && empty($messages) && 
				!$messages[$lang] || $messages[$lang]==null || empty($messages[$lang]) ||
					!$messages[$lang][$id] || $messages[$lang][$id]==null || $messages[$lang][$id]=="" ){
			return $id;
		} else{
			return $messages[$lang][$id];
		}
		
	}
	

}

?>