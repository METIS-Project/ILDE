﻿<?php

/**
  This file is part of MediaWikiVLEAdapter.

  MediaWikiVLEAdapter is a property of the Intelligent & Cooperative Systems
  Research Group (GSIC) from the University of Valladolid (UVA).

  Copyright 2011 GSIC (UVA).

  MediaWikiVLEAdapter is licensed under the GNU General Public License (GPL)
  EXCLUSIVELY FOR NON-COMMERCIAL USES. Please, note this is an additional
  restriction to the terms of GPL that must be kept in any redistribution of
  the original code or any derivative work by third parties.

  If you intend to use MediaWikiVLEAdapter for any commercial purpose you can
  contact to GSIC to obtain a commercial license at <glue@gsic.tel.uva.es>.

  If you have licensed this product under a commercial license from GSIC,
  please see the file LICENSE.txt included.

  The next copying permission statement (between square brackets []) is
  applicable only when GPL is suitable, this is, when MediaWikiVLEAdapter is
  used and/or distributed FOR NON COMMERCIAL USES.

  [ You can redistribute MediaWikiVLEAdapter and/or modify it under the
    terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
  ]
*/


/**
 *	Internationalization file.
 *  @author Javier Aragon
 */


$messages = array();

$messages['en'] = array(

	// file name to define the button for a new instance.
	'newglueletbutton' 				=> 'button_glue_en.png',
	'notshowglueletbutton' 			=> 'button_glue_noshow_en.png',
	'showglueletbutton' 			=> 'button_glue_show_en.png',
	'notshowglueletbuttonlabel'		=> 'Hide gluelet article  list',
	'showglueletbuttonlabel'		=> 'Show gluelet article  list',
	'showglueletbuttonalttext'		=> '   show gluelets   ',
	'notshowglueletbuttonalttext'	=> '   hide gluelets   ',
	'newglueletbuttontittle' 		=> 'Add a New gluelet',
	'newglueletbuttonalttext' 		=> '  new gluelet  ',

	// file name to define the delete instance button
	'editinstancedivcontent'		=> 'divcontent',
	'editinstancecheckbox'			=> 'thechekbox',
	'ondeletefromarticleerror'		=> 'Se ha producido un error al eliminar el \"tag gluelet\" del artículo.\n\n',
	'ondeletefromdatabaseerror'		=> 'Se ha producido un error al eliminar el \"tag gluelet\" de la base de datos.\n\n',
	'deleteinstancebutton' 			=> 'delete_instance.png',
	'deleteinstancebuttontittle' 	=> 'Delete this gluelet',
	'deleteinstancetbuttonalttext' 	=> 'delete',
	'deleteinstancedatabasemessage'	=> 	'<font size=3px>'
											.'<p style=\'padding-left:15px;padding-right:10px\'>{number_of_matches} \"gluelettag(s)\" of <font color=blue>{gluelet_id_instance}</font> is going to be removed from article. Do you also want to remove it from the database of gluelets??.'
											.'This will imply that the gluelet contents will not be accessible any longer (even if it is referenced from other wiki pages). Also, this action might cause errors in the wiki article’s history.</p>'
											.'<p style=\'padding-left:15px;padding-right:10px\' >Click YES to remove the gluelet from the database and from the wiki article, NO to only remove it from the wiki article or CANCEL.</p>'
										.'</font>',
	'reallywanttodelete'			=> 'Do you really understand the effects delete this \'gluelet\' from database?. If you want the changes to take effect you must save article in your wiki.\n\nClick Accept to continue or Cancel to undo. ',
	'deleteinstanceyesbutton'		=> 'Yes, delete from database.',
	'deleteinstancenotbutton'		=> 'No, only from article.',
	'deleteinstancecancelbutton'	=> 'Cancel',
	'instacedeleted'				=> 'has been deleted succesfully from database.',
	'instancenotdeleted'			=> 'couldn\'t be deleted from database.',
	'noforgetsavearticlemessage'	=> 'Please, close this window and save the wiki article to make changes permanent.',
	'showdeatilserrormessage'		=> 'Show Error Message Details.',
	'hidedeatilserrormessage'		=> 'Hide Error Message Details.',
	'requestdeailslabel'			=> 'Rquest Details.',


	// Visualization gluelets messges, labels and errors
	'authorlabel' 					=> 'Author',
	'instanceidlabel'				=> 'id',
	'linklabel'						=> 'link',
	'updateddatelabel'				=> 'updated',
	'showglueletwintitle'			=> 'Your gluelet --> ',
	'showglueletpagetitle'			=> 'Want to view a Gluelet',
	'infglueletlabel'				=> 'Gluelet Report',
	'nodisplayerrormsg'				=> 'Unable to display the gluelet',
	'iframerrormsg'					=> 'Your browser does not support iframes.',
	'getinstanceerrormessage'		=> 'has appeared an error when requesting for this instance.',
	'showinstanceimagetitle'		=> 'Show instance.',
	'hideinstanceimagetitle'		=> 'Hide instance.',
	'showinstanceimagealt'			=> 'Show',
	'hideinstanceimagealt'			=> 'Hide',
	'reloadinstanceimagealt'		=> 'Reload',
	'newwindowinstanceimagealt'		=> 'Open New Window',
	'newtabinstanceimagealt'		=> 'Open New Tab',
	'reloadinstanceimagetitle'		=> 'Reload this instance.',
	'newwindowinstanceimagetitle'	=> 'Open this instance on new Window.',
	'newtabinstanceimagetitle'		=> 'Open this instance on new Tab.',


	// Configuration forms labels and messages
	'confwindowtitlelabel'			=> 'Configure your gluelet',
	'closewinbuttonlabel'			=> 'Close Window',
	'confloadingimagetext'			=> 'Loading ...',
	'selecttoollabel'				=> 'Select your tool --> ',
	'sendbuttonlabel'				=> 'Send',
	'finishbuttonlabel'				=> 'Finish',
	'backbuttonlabel'				=> 'Back',
	'noconfigfromerror'				=> 'Unable to get the tool\'s configuration form ',
	'instancecreatedmessage'		=> 'A gluelet instance has been created, it has next id --> ',
	'getgluetoolserrormessage'		=> 'Could not display tools list.',
	'getgluetoolsclosewindowmsg'	=> 'An error has occurred. Please, close that window.',
	'emptytoollistmessage'			=> 'There is no tools registered at Gluelet Manager or tool\'s list collected is empty.',
	'getconffromerrormessage'		=> 'failed when request for this tool\'s configuration form.',
	'noconfigurationmessage'		=> 'Nothing to configure here!!!',
	'noidgetinstanceerrormessage'	=> 'There was a problem while a new instance request of this tool: ',
	'conftoolnamelabel'				=> 'Configure an instance of: ',
	'instancetitleinputlabel'		=> 'Give a title to this instance:',
	'instancetitledefaultvalue'		=> ' -- Your Title Here -- ',



	// Error messages
	'errorinparams'					=> 'No params or wrong params.',
	'httpokbuterrormessage'			=> 'HTTP OK STATUS CODE RECEIVED BUT AN ERROR HAS OCCURRED -',

	// GlueletManagerClient.js: messages, errors and labels.
	'createhttpobjecterror'			=> 'Could not create HTTP request object.',

	// Delete Instances process messages, labels and errors
	'noinstancestodeleteerror'		=> ' ¡¡ ERROR !! -  No se han obtenido instancias para eliminar.',


	'defaulterrormessage'			=> ' ¡¡ ERROR !!',
	'defaultokmessage'				=> ' ¡¡ OK !!',
	'iloaderdefaultimagefile'		=> 'iloader_en.gif',

	'windowsdialogtheme'			=> 'mac_os_x',

	'defaultlangmessage'			=> 'Using english'

);


$messages['es'] = array(

	// nombre del fichero que contiene la imagen para el boton de crear un nueva instancia de GLUE!
	'newglueletbutton' 				=> 'button_glue_es.png',
	'notshowglueletbutton' 			=> 'button_glue_noshow_es.png',
	'showglueletbutton' 			=> 'button_glue_show_es.png',
	'notshowglueletbuttonlabel'		=> 'Mostrar la lista de gluelets del artículo',
	'showglueletbuttonlabel'		=> 'Ocultar la lista de gluelets del artículo',
	'showglueletbuttonalttext'		=> '   Mostrar Gluelets   ',
	'notshowglueletbuttonalttext'	=> '   Ocultar Gluelets   ',
	'newglueletbuttontittle' 		=> 'Crea un Nuevo gluelet',
	'newglueletbuttonalttext' 		=> '  Crear Un Gluelet  ',


	// file name to define the delete instance button
	'editinstancedivcontent'		=> 'divcontent',
	'editinstancecheckbox'			=> 'thechekbox',
	'deleteinstancebutton' 			=> 'delete_instance.png',
	'deleteinstancebuttontittle' 	=> 'Eliminar este gluelet',
	'deleteinstancetbuttonalttext' 	=> 'eliminar',
	'ondeletefromarticleerror'		=> 'Se ha producido un error al eliminar el \"tag gluelet\" del artículo.\n\n',
	'ondeletefromdatabaseerror'		=> 'Se ha producido un error al eliminar el \"tag gluelet\" de la base de datos.\n\n',
	'deleteinstancedatabasemessage'	=> 	"<font size=3px >"
											.'<p style=\'padding-left:15px;padding-right:10px\'>Vas a borrar del artículo {number_of_matches} \"gluelettag(s)\" de la instancia <font color=blue>{gluelet_id_instance}</font>. ¿Quieres borrarlo también de la base de datos?.'
											.'Esto puede hacer que el gluelet no se vuelva a visualizar. También puede causar errores en la recuperación del historial del artículo.</p>'
											.'<p style=\'padding-left:15px;padding-right:10px\'>Haz Click en SI para eliminarlo completamente, NO para sólo eliminarlo del artículo o CANCELAR para desahacer los cambios.</p>'
										.'</font>',
	'reallywanttodelete'			=> '¿Entendió realmente los efectos de eleiminar este \'gluelet\' de la base de datos?. Para que los cambios hagan efecto deberá salvar el Artículo de la wiki.\n\nPulse Aceptar para continuar y Cancelar para Abortar. ',
	'deleteinstanceyesbutton'		=> 'Sí, eliminar de base de datos.',
	'deleteinstancenotbutton'		=> 'No, sólo del articulo.',
	'deleteinstancecancelbutton'	=> 'Cancelar.',
	'instacedeleted'				=> 'eliminada con éxito de la base de datos.',
	'instancenotdeleted'			=> 'no se ha podido eliminar de la base de datos.',
	'noforgetsavearticlemessage'	=> 'Por favor, cierre la venta. En cualquier caso no olvide guardar los cambios de su artículo para que sean permanentes.',
	'showdeatilserrormessage'		=> 'Mostrar detalles del mensaje de error.',
	'hidedeatilserrormessage'		=> 'Ocultar detalles del mensaje de error.',
	'requestdeailslabel'			=> 'Detalles de la llamada.',


	// Visualization gluelets messges, labels and errors
	'authorlabel' 					=> 'Autor',
	'instanceidlabel'				=> 'Id',
	'linklabel'						=> 'Enlace',
	'updateddatelabel'				=> 'Actualizado',
	'showglueletwintitle'			=> 'Tu gluelet --> ',
	'showglueletpagetitle'			=> 'Quiero ver un Gluelet',
	'infglueletlabel'				=> 'Información del gluelet',
	'nodisplayerrormsg'				=> 'No se ha podido visualizar el gluelet',
	'iframerrormsg' 				=> 'Su navegador no soporta iframes.',
	'getinstanceerrormessage'		=> 'no se ha podido obtener esta instancia del GLUElet Manager.',
	'showinstanceimagetitle'		=> 'Mostrar instancia.',
	'hideinstanceimagetitle'		=> 'Ocultar instancia.',
	'showinstanceimagealt'			=> 'Mostrar.',
	'hideinstanceimagealt'			=> 'Ocultar.',
	'reloadinstanceimagealt'		=> 'Reload',
	'newwindowinstanceimagealt'		=> 'Open New Window',
	'newtabinstanceimagealt'		=> 'Open New Tab',
	'reloadinstanceimagetitle'		=> 'Reload this instance.',
	'newwindowinstanceimagetitle'	=> 'Open this instance on new Window.',
	'newtabinstanceimagetitle'		=> 'Open this instance on new Tab.',



	// Configuration forms labels and messages
	'confwindowtitlelabel'			=> 'Configura tu gluelet',
	'closewinbuttonlabel'			=> 'Cerrar Ventana',
	'confloadingimagetext'			=> 'Cargando ...',
	'selecttoollabel'				=> 'Elija una herramienta: ',
	'sendbuttonlabel'				=> 'Enviar',
	'finishbuttonlabel'				=> 'Terminar',
	'backbuttonlabel'				=> 'Volver',
	'noconfigfromerror'				=> 'No se ha podido obtener el formulario de configuración de la herramienta ',
	'instancecreatedmessage'		=> 'Se ha creado una nueva instancia con id --> ',
	'getgluetoolserrormessage'		=> 'No se ha podido obtener la lista de herramientas.',
	'getgluetoolsclosewindowmsg'	=> 'Ha ocurrido un error. Por favor, cierre esta ventana.',
	'emptytoollistmessage'			=> 'No hay herramientas registradas en el Gluelet Manager o la lista obtenida está vacía.',
	'getconffromerrormessage'		=> 'no se ha podido obtener el formulario de configuración de esta herramienta.',
	'noconfigurationmessage'		=> 'No hay nada que configurar para esta herramienta.',
	'noidgetinstanceerrormessage'	=> 'Ha ocurrido un problema mientras se solicitiba una nueva instancia de esta herramienta: ',
	'conftoolnamelabel'				=> 'Configura una instancia de: ',
	'instancetitleinputlabel'		=> 'Introduzca un título para su instancia:',
	'instancetitledefaultvalue'		=> ' -- Escriba su título aquí -- ',


	// Error messages
	'errorinparams'					=> 'No hay parámetros o los parámetros son incorrectos.',
	'httpokbuterrormessage'			=> 'SE HA RECIBIDO UN CODIGO HTTP OK PERO HA OCURRIDO UN ERROR -',


	// GlueletManagerClient.js: messages, errors and labels.
	'createhttpobjecterror'			=> 'No se pudo crear el objeto de solicitudes HTTP para el GlueletManager.',


	// Delete Instances process messages, labels and errors
	'noinstancestodeleteerror'		=> ' ¡¡ ERROR !! -  No se han obtenido instancias para eliminar.',

	'defaulterrormessage'			=> ' ¡¡ ERROR !!',
	'defaultokmessage'				=> ' ¡¡ OK !!',
	'iloaderdefaultimagefile'		=> 'iloader_es.gif',

	'windowsdialogtheme'			=> 'mac_os_x',

	'defaultlangmessage'			=> 'Usando español'
);


$messages['fr'] = array(

	// file name to define the button for a new instance.
	'newglueletbutton' 				=> '[fr]button_glue_en.png',
	'notshowglueletbutton' 			=> '[fr]button_glue_noshow_en.png',
	'showglueletbutton' 			=> '[fr]button_glue_show_en.png',
	'notshowglueletbuttonlabel'		=> '[fr]Hide gluelet article  list',
	'showglueletbuttonlabel'		=> '[fr]Show gluelet article  list',
	'showglueletbuttonalttext'		=> '   [fr]show gluelets   ',
	'notshowglueletbuttonalttext'	=> '   [fr]hide gluelets   ',
	'newglueletbuttontittle' 		=> '[fr]Add a New gluelet',
	'newglueletbuttonalttext' 		=> '  [fr]new gluelet  ',

	// file name to define the delete instance button
	'deleteinstancebutton' 			=> '[fr]delete_instance.png',
	'deleteinstancebuttontittle' 	=> '[fr]Delete this gluelet',
	'deleteinstancetbuttonalttext' 	=> '[fr]delete',
	'deleteinstancedatabasemessage'	=> '[fr]This \"gluelettag\" is going to be deleted from article. ¿Do you want to delete from database?.\n\n'
										+'This will cause the gluelet can\'t ever shown again. Also it can cause errors in the article\'s history.\n\n'
										+'Click YES to delete it, NO to only delete from article or CANCEL to disscard changes.\n\n',

	// Visualization gluelets messges, labels and errors
	'authorlabel' 					=> '[fr]Author',
	'instanceidlabel'				=> '[fr]id',
	'linklabel'						=> '[fr]link',
	'updateddatelabel'				=> '[fr]updated',
	'showglueletwintitle'			=> '[fr]Your gluelet --> ',
	'showglueletpagetitle'			=> '[fr]Want to view a Gluelet',
	'infglueletlabel'				=> '[fr]Gluelet Report',
	'nodisplayerrormsg'				=> '[fr]Unable to display the gluelet',
	'iframerrormsg'					=> '[fr]Your browser does not support iframes.',

	// Configuration forms labels and messages
	'confwindowtitlelabel'			=> '[fr]Configure your gluelet',
	'closewinbuttonlabel'			=> '[fr]Close Window',
	'confloadingimagetext'			=> '[fr]Loading ...',
	'selecttoollabel'				=> '[fr]Select your tool --> ',
	'sendbuttonlabel'				=> '[fr]Send',
	'finishbuttonlabel'				=> '[fr]Finish',
	'backbuttonlabel'				=> '[fr]Back',
	'noconfigfromerror'				=> '[fr]Unable to get the tool\'s configuration form ',
	'instancecreatedmessage'		=> '[fr]A gluelet instance has been created, it has next id --> ',


	// Error messages
	'errorinparams'					=> '[fr]No params or wrong params.',

	'defaultlangmessage'			=> '[fr]Using french'

);




?>
