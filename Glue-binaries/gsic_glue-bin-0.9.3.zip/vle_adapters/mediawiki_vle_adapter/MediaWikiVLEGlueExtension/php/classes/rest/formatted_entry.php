<?php

/**
  This file is part of MediaWikiVLEAdapter.
  
  MediaWikiVLEAdapter is a property of the Intelligent & Cooperative Systems 
  Research Group (GSIC) from the University of Valladolid (UVA). 
  
  Copyright 2011 GSIC (UVA).

  MediaWikiVLEAdapter is licensed under the GNU General Public License (GPL) 
  EXCLUSIVELY FOR NON-COMMERCIAL USES. Please, note this is an additional 
  restriction to the terms of GPL that must be kept in any redistribution of
  the original code or any derivative work by third parties.

  If you intend to use MediaWikiVLEAdapter for any commercial purpose you can 
  contact to GSIC to obtain a commercial license at <glue@gsic.tel.uva.es>.

  If you have licensed this product under a commercial license from GSIC,
  please see the file LICENSE.txt included.

  The next copying permission statement (between square brackets []) is 
  applicable only when GPL is suitable, this is, when MediaWikiVLEAdapter is 
  used and/or distributed FOR NON COMMERCIAL USES.
  
  [ You can redistribute MediaWikiVLEAdapter and/or modify it under the 
    terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
  ]
*/

/**
 *  @author Javier Aragon
 */


/**
 * Class to support the reading of Atom+GLUE formatted responses (<entry>)
 */
class formatted_entry {

    ////////////////
    // Attributes //
    ////////////////

    /** Entry loaded as DOM document */
    protected $_entry;

    /** XPath evaluator associated to _entry */
    protected $_xpath;

    ////////////////////
    // Public methods //
    ////////////////////

    /**
     * Constructor
     */
    public function __construct($entry = null) {

        if ($entry) {
            /// load entry in memory
            if (is_string($entry)) {
            	$doc = new DOMDocument();
        		$doc->loadXML($entry);
				$this->_entry = $doc;
                //$this->_entry = DOMDocument::loadXML($entry);
            } else if (is_object($entry)) {
                $this->_entry = new DOMDocument();
                $this->_entry->appendChild($this->_entry->importNode($entry, true));
            }
        } else {
            /// new entry - just for POST
            $this->_entry = new DOMDocument();
        }

        /// init XPath helper
        if ($this->_entry) {
            $this->_xpath = new DOMXPath($this->_entry);
            $this->_xpath->registerNamespace("atom", "http://www.w3.org/2005/Atom");
            $this->_xpath->registerNamespace("glue", "http://gsic.uva.es/glue/1.0");
        }

        if (!$entry) {
            //$this->_entry->appendChild($this->_entry->createElement("http://www.w3.org/2005/Atom", "entry"));
            $entryNode = $this->_entry->appendChild($this->_entry->createElement("entry"));
            $attrNode = $entryNode->appendChild($this->_entry->createAttribute("xmlns"));
            $attrNode->appendChild($this->_entry->createTextNode("http://www.w3.org/2005/Atom"));
            $attrNode = $entryNode->appendChild($this->_entry->createAttribute("xmlns:glue"));
            $attrNode->appendChild($this->_entry->createTextNode("http://gsic.uva.es/glue/1.0"));
        }
    }


    /**
     * Getter for text content in an Atom-standard simple XML element
     */
    public function getAtomSimpleElement($tag) {
        return $this->getSimpleElement("atom", $tag);
    }


    /**
     * Getter for text content in a GLUE-specific simple XML element
     */
    public function getExtendedSimpleElement($tag) {
        return $this->getSimpleElement("glue", $tag);
    }

    /**
     * Getter for the value of an attribute in an Atom element
     *
     * @param tag   string      Tag of the target element.
     * @param att   string      Name of the target attribute.
     * @return      string      Value of the target attribute.
     */
    public function getAtomAttribute($tag, $att) {
        $targetURLs = $this->_xpath->query("/atom:entry/atom:$tag/@$att");
        if ($targetURLs->length > 0)
            return $targetURLs->item(0)->textContent;
        return null;
    }

    /**
     * Adds a new simple element as child of <entry>
     *
     * @param   $tag            string      Name for the new element.
     * @param   $textContent    string      Text content to set as value of the new element.
     */
    public function addExtendedSimpleElement($tag, $textContent) {
        $entryNode = null;
        $nodes = $this->_xpath->query("//entry");
        for ($i=0; $i<$nodes->length; $i++) {
            $node = $nodes->item($i);
            if ($node->nodeType == XML_ELEMENT_NODE) {
                //$node->appendChild($this->_entry->createElementNS("http://gsic.uva.es/glue/1.0", $tag, $textContent));
                $node->appendChild($this->_entry->createElement("glue:$tag", $textContent));
                break;
            }
        }
    }


    /**
     * Adds a new structured element as child of <entry> cloning the root element of the DOM Document $doc
     *
     * @param   $tag    string      Name for the new element.
     * @param   $doc    string      DOM Document to clone as new child element
     */
    public function addExtendedStructuredElement($tag, $doc) {
        $entryNode = null;
        $nodes = $this->_xpath->query("//entry");
        for ($i=0; $i<$nodes->length; $i++) {
            $node = $nodes->item($i);
            if ($node->nodeType == XML_ELEMENT_NODE) {  // TODO delete, it's unnecesary; XPath query is requiring it!!
                //$newNode = $node->appendChild($this->_entry->createElementNS("http://gsic.uva.es/glue/1.0", $tag));
                $newNode = $node->appendChild($this->_entry->createElement("glue:$tag"));
                $newNode->appendChild($this->_entry->importNode($doc->documentElement, true));
                break;
            }
        }
    }


    /**
     * Add a new structured element as child of <entry>, containing a list of children simple elements
     *
     * @param   $listName   string              Name for the list element.
     * @param   $itemName   string              Name for every child of element $listName
     * @param   $listName   array of string     Array with the text values for every simple child element
     */
    public function addExtendedStructuredList($listName, $itemName, $items) {
        $entryNode = null;
        $nodes = $this->_xpath->query("//entry");
        for ($i=0; $i<$nodes->length; $i++) {
            $node = $nodes->item($i);
            if ($node->nodeType == XML_ELEMENT_NODE) {  // TODO delete, it's unnecesary; XPath query is requiring it!!
                $listNode = $node->appendChild($this->_entry->createElement("glue:$listName"));
                foreach ($items as $key => $value)
                    $itemNode = $listNode->appendChild($this->_entry->createElement("glue:$itemName", $value));
                break;
            }
        }
    }


    /**
     * Getter for an Atom-standard structured XML element
     */
    public function getAtomStructuredElement($tag) {
        $nodes = $this->_xpath->query("//atom:$tag");
        for ($i=0; $i<$nodes->length; $i++) {
            $node = $nodes->item($i);
            if ($node->nodeType == XML_ELEMENT_NODE) {
                return $node;
            }
        }
        return null;
    }


    /**
     * Search the text content of a simple XML element
     */
    protected function getSimpleElement($prefix, $tag) {
        $nodes = $this->_xpath->query("//$prefix:$tag");
        for ($i=0; $i<$nodes->length; $i++) {
            $node = $nodes->item($i);
            if ($node->nodeType == XML_ELEMENT_NODE) {
                return $node->textContent;
            }
        }
        return null;
    }


    /**
     * Dumps the internal XML tree back into a string
     */
     public function saveXML() {
        if ($this->_entry)
            return $this->_entry->saveXML();
        else
            return null;
     }


}
?>