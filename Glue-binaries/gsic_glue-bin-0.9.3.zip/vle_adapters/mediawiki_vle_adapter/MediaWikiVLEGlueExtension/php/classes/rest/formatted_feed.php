<?php

/**
  This file is part of MediaWikiVLEAdapter.
  
  MediaWikiVLEAdapter is a property of the Intelligent & Cooperative Systems 
  Research Group (GSIC) from the University of Valladolid (UVA). 
  
  Copyright 2011 GSIC (UVA).

  MediaWikiVLEAdapter is licensed under the GNU General Public License (GPL) 
  EXCLUSIVELY FOR NON-COMMERCIAL USES. Please, note this is an additional 
  restriction to the terms of GPL that must be kept in any redistribution of
  the original code or any derivative work by third parties.

  If you intend to use MediaWikiVLEAdapter for any commercial purpose you can 
  contact to GSIC to obtain a commercial license at <glue@gsic.tel.uva.es>.

  If you have licensed this product under a commercial license from GSIC,
  please see the file LICENSE.txt included.

  The next copying permission statement (between square brackets []) is 
  applicable only when GPL is suitable, this is, when MediaWikiVLEAdapter is 
  used and/or distributed FOR NON COMMERCIAL USES.
  
  [ You can redistribute MediaWikiVLEAdapter and/or modify it under the 
    terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
  ]
*/

/**
 *  @author Javier Aragon
 */

/**
 * Class to support the reading of Atom+GLUE formatted responses (<feed>)
 */
class formatted_feed {

    ////////////////
    // Attributes //
    ////////////////

    /** Feed loaded as DOM document */
    protected $feed;

    /** XPath evaluator associated to _feed */
    protected $_xpath;

    ////////////////////
    // Public methods //
    ////////////////////

    /**
     * Constructor
     */
    public function __construct($entry) {

        /// load XForms definition
        $doc = new DOMDocument();
        $doc->loadXML($entry);
		$this->_feed = $doc;
        //$this->_feed = DOMDocument::loadXML($entry);

        /// init XPath helper
        $this->_xpath = new DOMXPath($this->_feed);
        $this->_xpath->registerNamespace("atom", "http://www.w3.org/2005/Atom");
        $this->_xpath->registerNamespace("glue", "http://gsic.uva.es/glue/1.0");

    }

    /**
     * Getter for text content in an Atom-standard simple XML element
     */
    public function getAtomSimpleElement($tag) {
        return $this->getSimpleElement("atom", $tag);
    }

    /**
     * Getter for text content in a GLUE-specific simple XML element
     */
    public function getExtendedSimpleElement($tag) {
        return $this->getSimpleElement("glue", $tag);
    }

    /**
     * Getter for array of formatted_entry objects
     */
    public function getFormattedEntries() {
        $nodes = $this->_xpath->query("//atom:entry");
        $result = array();
        $j = 0;
        for ($i=0; $i<$nodes->length; $i++) {
            $node = $nodes->item($i);
            if ($node->nodeType == XML_ELEMENT_NODE) {
                $result[$j] = new formatted_entry($node);
                $j++;
            }
        }
        return $result;
    }

    /**
     * Search the text content of a simple XML element
     */
    protected function getSimpleElement($prefix, $tag) {
        $nodes = $this->_xpath->query("//$prefix:$tag");
        for ($i=0; $i<$nodes->length; $i++) {
            $node = $nodes->item($i);
            if ($node->nodeType == XML_ELEMENT_NODE) {
                return $node->textContent;
            }
        }
        return null;
    }

}





function get_mediawiki_users($wikidbname, $wikihost, $dbuser, $dbpass, $wikidbextension){
 
	//sql connection ("host","user","pass")
	$conn = mysql_connect($wikihost,$dbuser,$dbpass);
	
	if (!$conn){
		die('Could not connect: ' . mysql_error());
	}
	
	$result = array();
	
	mysql_select_db($wikidbname, $conn);
	$sql = "SELECT user_name FROM ". $wikidbextension ."user";
	$users = mysql_query($sql);
	while($row = mysql_fetch_array($users)){
		$result[]= $row['user_name'];
	}

	return $result;
}

?>