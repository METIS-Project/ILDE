<?php

/**
  This file is part of MediaWikiVLEAdapter.
  
  MediaWikiVLEAdapter is a property of the Intelligent & Cooperative Systems 
  Research Group (GSIC) from the University of Valladolid (UVA). 
  
  Copyright 2011 GSIC (UVA).

  MediaWikiVLEAdapter is licensed under the GNU General Public License (GPL) 
  EXCLUSIVELY FOR NON-COMMERCIAL USES. Please, note this is an additional 
  restriction to the terms of GPL that must be kept in any redistribution of
  the original code or any derivative work by third parties.

  If you intend to use MediaWikiVLEAdapter for any commercial purpose you can 
  contact to GSIC to obtain a commercial license at <glue@gsic.tel.uva.es>.

  If you have licensed this product under a commercial license from GSIC,
  please see the file LICENSE.txt included.

  The next copying permission statement (between square brackets []) is 
  applicable only when GPL is suitable, this is, when MediaWikiVLEAdapter is 
  used and/or distributed FOR NON COMMERCIAL USES.
  
  [ You can redistribute MediaWikiVLEAdapter and/or modify it under the 
    terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
  ]
*/


 /** 
 * This class defines methods and properties to implements GlueletManger Client Error
 *
 * This class defines properties that are returned when a REST request has an error. This properties 
 * can be a status returned error code or http code that can be viewed in any explorer and represents 
 * this error.
 *
 * @access public 
 * @author Javier Aragon
 * @version 2011/05/31-0.1
 * @package php/classes/rest
 */  
class GlueletManagerClientError {

	// --- ATTRIBUTES ---  
	// cURL error status number.
	var $curll_number_error = -1;
	// HTTP error status number.
	var $status_error = -1;
	// result from an http request.
	var $result = "";
	// method name that caused this error.
	var $method = "";
	// HTTP nice code.
	var $nice_http_code = false;
	// HTTP reques details.
	var $caller_details = "";
	// Internationalization messages object
	var $I18N = null;
	// HTTP OK STATUs CODES
	var $http_ok_codes = array(200, 201, 202, 203, 204, 205, 206, 207, 226);
	
	 /** 
	 * GlueletManagerClientError Constructor.
	 * 
	 * @access 	public 
	 * @author 	Javier Aragon, <jaragoncaz@gmail.com> 
	 * @param	Integer		$curll_number_error 		cURL error status number.
	 * @param 	Integer		$status_error				HTTP error status number.
	 * @param	String		result						Result from an http request.
	 * @param	String		method						Method name that caused this error.
	 * @param	String		caller_details				HTTP request details.
	 * @param	String		nice_http_code				Error HTTP code.
	 * @return	void 
	 **/
	function __construct( $curll_number_error, $status_error, $result, $method, $nice_http_code, $caller_details){
	
		$this->curll_number_error 	= $curll_number_error;
		$this->status_error 		= $status_error;
		$this->result 				= $result;
		$this->method 				= $method;
		$this->nice_http_code	 	= $nice_http_code;
		$this->caller_details 		= $caller_details;
			
	}
	
	
	 /** 
	 * Set I18N object to internazionalization
	 * 
	 * @access 	public 
	 * @author 	Javier Aragon, <jaragoncaz@gmail.com> 
	 * @param	String		$lang 		language string definition.
	 * @return	void 
	 **/
	private function setI18N ($lang){
		if($lang && $lang!=null && $lang!=""){
			// Internazionalitacion library required
			require_once('../classes/i18n/I18NGlueLibMessages.php');
			// create the internationalization object.
			$this->I18N = new I18NGlueLibMessages($lang);
		}else{
			// Internazionalitacion library required
			require_once('../classes/i18n/I18NGlueLibMessages.php');
			// create the internationalization object.
			$this->I18N = new I18NGlueLibMessages("en");
		}
		
	}
	
	
	
	/** 
	 * Print error status from PHP cURL error number or from HTTP request status code.
	 * 
	 * @access 	public 
	 * @author 	Javier Aragon, <jaragoncaz@gmail.com> 
	 * @return	void 
	 **/
	private function print_status_error(){
		if ($this->curll_number_error > 0){
			print ("<b><font size=3px> cURL HTTP ERROR - ".$this->curll_number_error.".</font></b><br>");
		}else if (in_array($this->status_error, $this->http_ok_codes)){
			print ("<b><font size=3px>".$this->I18N->getI18NMessage('httpokbuterrormessage')."  ".$this->status_error.".</font></b><br>");
		}else{
			print ("<b><font size=3px> HTTP ERROR - ".$this->status_error.".</font></b><br>");
		}		
	}
	
	
	/** 
	 * Print div content with a message. It's used to print a close window message.
	 * 
	 * @access 	public 
	 * @author 	Javier Aragon, <jaragoncaz@gmail.com> 
	 * @return	void 
	 **/
	private function print_close_window_message($close_msg){
		print("<div style='width:95%;float:left'><font width=80% size=4px>".$this->I18N->getI18NMessage($close_msg)."</font></br></div>");
	}
	
	
	
	/** 
	 * Print div content with a error message given. It's used to print a table with the message and an error image.
	 * 
	 * @access 	public 
	 * @author 	Javier Aragon, <jaragoncaz@gmail.com> 
 	 * @param	String		$error_msg	error message id definition.
	 * @param	String		$resource 	the instance id.
	 * @return	void 
	 **/
	private function print_error_table_messages($error_msg, $resource=""){
		print("<div style='width:90%;float:left'>");
			print("<table><tr>");
				print("<td>");
					print ("<img height='40' src='./images/error_image.png'> ");
				print("</td>");
				print("<td valign='middle'>");
					print($this->I18N->getI18NMessage('defaulterrormessage'));
					print("&nbsp;&nbsp;&nbsp; ");
					if ($resource && $resource!=null && $resource!="")
						print("<b><font color=#800517>'". $resource . "'</font></b> ");
					print(	$this->I18N->getI18NMessage($error_msg) );
					print("</td>");
			print("</tr></table>");
		print("</div>");
	}
	
	/** 
	 * Print a hide/show div content with error details.
	 * 
	 * @access 	public 
	 * @author 	Javier Aragon, <jaragoncaz@gmail.com> 
 	 * @param	Array		$callerparameters	the caller parameters if given from function that causes the error.
	 * @return	void 
	 **/	
	private function print_error_message_details($callerparameters){
		// print button and text to show/hide detailed error message.
		print ("<div style='float:left;width:100%' ><br><img style=cursor:pointer id='errordetailmessage' onclick=showerrordetails()  src='./images/table-add-row-after.gif' HEIGHT='10px' WIDTH='10px' /><font color=blue><u><span onclick=showerrordetails() style=cursor:pointer id='texttochange'>".$this->I18N->getI18NMessage('showdeatilserrormessage')."</span></font></u></div>");
		// print a div with detailed error message.
		print ("<div style='display:none; float:left' id='errordetails'><p>");
		// print a table with request parameters: instance id, gluelet manager host and caller user
		print ('<table border=1 cellspacing=0 cellpadding=2 >');		
		print ("<tr><td>");
			print($this->I18N->getI18NMessage('requestdeailslabel'));
		print ("</td></tr>");
		print ("<tr><td>");
			foreach ($callerparameters as $name => $value){
				print ( $name .' -> '.$value.'<br>');
			}
		print ('</td></tr></table> <br>');
		
		// print cURL number error or http request status error.
		$this->print_status_error();
			
			
		// print result.
		print ($this->result);
		print ("</p></div>");
	}
	
	
	
	
	
	
	/** 
	 * Print a complete error message when a DELETE instance request causes an error.
	 * 
	 * @access 	public 
	 * @author 	Javier Aragon, <jaragoncaz@gmail.com> 
 	 * @param	String		$instance	the instance id to be deleted.
	 * @param	String		$host		the host url/name where the request was sent.
	 * @param	String		$user		the user thar request this operation.
	 * @param	String		$language	the user preference language.
	 * @return	void 
	 **/	
	function print_delete_intance_error_with_deatils($instance="instance_id", $host="gluelet_manager_host", $user="caller_user", $language ){
		
		$this->setI18N($language);
		
		// Print a div and a table with error message
		//$this->print_close_window_message('noforgetsavearticlemessage');
		print("<div style='width:100%;float:left'><p:1><font width=80% size=4px>".$this->I18N->getI18NMessage('noforgetsavearticlemessage')."</font></p></div>");
		$this->print_error_table_messages('instancenotdeleted', $instance);
		
		
		// print a javascript to show/hide detailed error message.
		print("<script language='javascript'>");
			print("function showerrordetails(){");
				print("if (document.getElementById('errordetails').style.display==''){");
					print("document.getElementById('errordetails').style.display='none';");
					print("document.getElementById('errordetailmessage').src = './images/table-add-row-after.gif';");
					print("document.getElementById('texttochange').innerHTML='".$this->I18N->getI18NMessage('showdeatilserrormessage')."';");
				print("}else if (document.getElementById('errordetails').style.display=='none'){");
					print("document.getElementById('errordetails').style.display='';");
					print("document.getElementById('errordetailmessage').src = './images/table-add-row-before.gif';");
					print("document.getElementById('texttochange').innerHTML='".$this->I18N->getI18NMessage('hidedeatilserrormessage')."';");
				print("}");
			print("}");
		print("</script>");
		
		// print button and text to show/hide detailed error message.
		$params = array();
		if ($instance && $instance!=null && $instance!=""){
			$params['instance id'] = $instance;
		}
		$params['url'] = $host;
		$params['user'] = $user;
		$params['method'] = $this->method;
		
		$this->print_error_message_details($params);
		
	}
	
	
	/** 
	 * Print a complete error message when a GET tool's list request causes an error.
	 * 
	 * @access 	public 
	 * @author 	Javier Aragon, <jaragoncaz@gmail.com> 
	 * @param	String		$host		the host url/name where the request was sent.
	 * @param	String		$user		the user thar request this operation.
	 * @param	String		$language	the user preference language.
	 * @return	void 
	 **/	
	function print_get_tool_list_error_with_deatils($host="gluelet_manager_host", $user="caller_user", $language ){
	
		
		$this->setI18N($language);
	

		// Print a div and a table with error message
		$this->print_close_window_message('getgluetoolsclosewindowmsg');

		$this->print_error_table_messages('getgluetoolserrormessage');


		
		// print a javascript to show/hide detailed error message.
		print("<script language='javascript'>");
			// print a javascript to show/hide detailed error message.
			print("function showerrordetails(){");
				print("if (document.getElementById('errordetails').style.display==''){");
					print("document.getElementById('errordetails').style.display='none';");
					print("document.getElementById('errordetailmessage').src = './images/table-add-row-after.gif';");
					print("document.getElementById('texttochange').innerHTML='".$this->I18N->getI18NMessage('showdeatilserrormessage')."';");
				print("}else if (document.getElementById('errordetails').style.display=='none'){");
					print("document.getElementById('errordetails').style.display='';");
					print("document.getElementById('errordetailmessage').src = './images/table-add-row-before.gif';");
					print("document.getElementById('texttochange').innerHTML='".$this->I18N->getI18NMessage('hidedeatilserrormessage')."';");
				print("}");
			print("}");
		print("</script>");
		
		print("<script language='javascript'>");
			// print javascriptcode to try swho 'close window button'.
			print("window.top.document.getElementById('NewGlueletConfigurationform').style.display='';");
			print("window.top.document.getElementById('NewGlueletConfigurationform').style.height='87%';");
			print("window.top.document.getElementById('winCloseButtonGlue').style.display='';");
			print("window.top.document.getElementById('gluewindowinstance').style.display='none';");
			//addgluewindow89345711234
			print("var ErrorTool = true;");
		print("</script>");
		
		// print button and text to show/hide detailed error message.
		$params = array();
		$params['url'] = $host;
		$params['user'] = $user;
		$params['method'] = $this->method;
		
		$this->print_error_message_details($params);
		
	}
	
	
	
	
	/** 
	 * Print a complete error message when a GET tool configuration form request causes an error.
	 * 
	 * @access 	public 
	 * @author 	Javier Aragon, <jaragoncaz@gmail.com> 
 	 * @param	String		$toolid		the tool id to get its configuration form.
	 * @param	String		$host		the host url/name where the request was sent.
	 * @param	String		$user		the user thar request this operation.
	 * @param	String		$language	the user preference language.
	 * @return	void 
	 **/	
	function print_get_configuration_form_error_with_deatils($host, $user, $toolid, $toolname, $language){
			
		$this->setI18N($language);
		
		// Print a div and a table with error message
		$this->print_close_window_message('getgluetoolsclosewindowmsg');	
		
		$resource = "";
		if ($toolname && $toolname!=null && $toolname!=""){
			$resource = $toolname;
		} else{
			$resource = $toolid;
		}
		
		$this->print_error_table_messages('getconffromerrormessage', $resource);


		
		// print a javascript to show/hide detailed error message.
		print("<script language='javascript'>");
			print("function showerrordetails(){");
				print("if (document.getElementById('errordetails').style.display==''){");
					print("document.getElementById('errordetails').style.display='none';");
					print("document.getElementById('errordetailmessage').src = './images/table-add-row-after.gif';");
					print("document.getElementById('texttochange').innerHTML='".$this->I18N->getI18NMessage('showdeatilserrormessage')."';");
				print("}else if (document.getElementById('errordetails').style.display=='none'){");
					print("document.getElementById('errordetails').style.display='';");
					print("document.getElementById('errordetailmessage').src = './images/table-add-row-before.gif';");
					print("document.getElementById('texttochange').innerHTML='".$this->I18N->getI18NMessage('hidedeatilserrormessage')."';");
				print("}");
			print("}");
		print("</script>");
		
	
		print("<script language='javascript'>");
				// print javascriptcode to try swho 'close window button'.
				print("window.top.document.getElementById('NewGlueletConfigurationform').style.display='';");
				print("window.top.document.getElementById('NewGlueletConfigurationform').style.height='88%';");
				print("window.top.document.getElementById('winCloseButtonGlue').style.display='';");
				print("window.top.document.getElementById('gluewindowinstance').style.display='none';");
				//addgluewindow89345711234
				print("var ErrorConf = true;");
		print("</script>");
		
		$params = array();
		if ($toolid && $toolid!=null && $toolid!=""){
				$params['toolid'] = $toolid;
		}
		if ($toolname && $toolname!=null && $toolname!=""){
			$params['toolname'] = $toolname;
		}
		$params['url'] = $host;
		$params['user'] = $user;
		$params['method'] = $this->method;
		
		$this->print_error_message_details($params);
	}
	
	
	
	
	
	
	
	/** 
	 * Print a complete error message when a POST new instance request causes an error.
	 * 
	 * @access 	public 
	 * @author 	Javier Aragon, <jaragoncaz@gmail.com> 
 	 * @param	String		$toolid		the tool id to get its configuration form.
	 * @param	String		$toolname	the tool name to get its configuration form.
	 * @param	String		$host		the host url/name where the request was sent.
	 * @param	String		$user		the user thar request this operation.
	 * @param	String		$language	the user preference language.
	 * @return	void 
	 **/	
	function print_post_new_instance_error_with_deatils($host, $user, $toolid, $toolname, $language){
			
		$this->setI18N($language);
		
		// Print a div and a table with error message
		$this->print_close_window_message('getgluetoolsclosewindowmsg');
		
		$resource = "";
		if ($toolname && $toolname!=null && $toolname!=""){
			$resource = $toolname;
		} else{
			$resource = $toolid;
		}
		
		print("<div style='width:100%;float:left;position:static'>");
			print("<table width=80% ><tr>");
			print("<td>");
				print ("<img height='40' src='./images/error_image.png'> ");
			print("</td>");
			print("<td valign='middle'>");
				print($this->I18N->getI18NMessage('defaulterrormessage')
					."&nbsp;&nbsp;&nbsp;" . $this->I18N->getI18NMessage('noidgetinstanceerrormessage') ."<b><font color=#800517>'" 
					. $resource . "'</font></b> ");
			print("</td>");
		print("</tr></table>");		print("</div>");

		
		// print a javascript to show/hide detailed error message.
		print("<script language='javascript'>");
			print("function showerrordetails(){");
				print("if (document.getElementById('errordetails').style.display==''){");
					print("document.getElementById('errordetails').style.display='none';");
					print("document.getElementById('errordetailmessage').src = './images/table-add-row-after.gif';");
					print("document.getElementById('texttochange').innerHTML='".$this->I18N->getI18NMessage('showdeatilserrormessage')."';");
				print("}else if (document.getElementById('errordetails').style.display=='none'){");
					print("document.getElementById('errordetails').style.display='';");
					print("document.getElementById('errordetailmessage').src = './images/table-add-row-before.gif';");
					print("document.getElementById('texttochange').innerHTML='".$this->I18N->getI18NMessage('hidedeatilserrormessage')."';");
				print("}");
			print("}");
		print("</script>");
		
	
		print("<script language='javascript'>");
				// print javascriptcode to try swho 'close window button'.
				print("window.top.document.getElementById('NewGlueletConfigurationform').style.display='';");
				print("window.top.document.getElementById('NewGlueletConfigurationform').style.height='88%';");
				print("window.top.document.getElementById('winCloseButtonGlue').style.display='';");
				print("window.top.document.getElementById('gluewindowinstance').style.display='none';");
				//addgluewindow89345711234
				print("ErrorInstance = true;");
		print("</script>");
		
		
		$params = array();
		if ($toolid && $toolid!=null && $toolid!=""){
				$params['toolid'] = $toolid;
		}
		if ($toolname && $toolname!=null && $toolname!=""){
			$params['toolname'] = $toolname;
		}
		$params['url'] = $host;
		$params['user'] = $user;
		$params['method'] = $this->method;
		
		$this->print_error_message_details($params);
	}
	
	
	
	
	
	
	
	
	/** 
	 * Print a complete error message when a GET instance request causes an error.
	 * 
	 * @access 	public 
	 * @author 	Javier Aragon, <jaragoncaz@gmail.com> 
	 * @param	String		$instanceid		the instance id to be deleted.
	 * @param	String		$host			the host url/name where the request was sent.
	 * @param	String		$user			the user thar request this operation.
	 * @param	String		$language		the user preference language.
	 * @return	void 
	 **/		
	function print_get_instance_error($instanceid, $user, $host, $language){
		
		$this->setI18N($language);
		
		// Print a div and a table with error message
		$this->print_close_window_message('getgluetoolsclosewindowmsg');	
		
		$this->print_error_table_messages('getinstanceerrormessage', $instanceid);


		
		// print a javascript to show/hide detailed error message.
		print("<script language='javascript'>");
			print("function showerrordetails(){");
				print("if (document.getElementById('errordetails').style.display==''){");
					print("document.getElementById('errordetails').style.display='none';");
					print("document.getElementById('errordetailmessage').src = './images/table-add-row-after.gif';");
					print("document.getElementById('texttochange').innerHTML='".$this->I18N->getI18NMessage('showdeatilserrormessage')."';");
				print("}else if (document.getElementById('errordetails').style.display=='none'){");
					print("document.getElementById('errordetails').style.display='';");
					print("document.getElementById('errordetailmessage').src = './images/table-add-row-before.gif';");
					print("document.getElementById('texttochange').innerHTML='".$this->I18N->getI18NMessage('hidedeatilserrormessage')."';");
				print("}");
			print("}");
		print("</script>");
		
	
		print("<script language='javascript'>");
				// print javascriptcode to try swho 'close window button'.
				print("window.top.document.getElementById('ViewGlueletIframe').style.display='';");
				print("window.top.document.getElementById('ViewGlueletIframe').style.height='88%';");
				print("window.top.document.getElementById('winCloseButtonGlue').style.display='';");
				//print("window.top.document.getElementById('gluewindowinstance').style.display='none';");
				//addgluewindow89345711234
				print("ErrorInstance = true;");
		print("</script>");
		
		$params = array();
		$params['instance id'] = $instanceid;
		$params['url'] = $host;
		$params['user'] = $user;
		$params['method'] = $this->method;
		
		$this->print_error_message_details($params);
	}
	
	
	
	
	
	
	
	
	
	
	/** 
	 * Print a complete error message when a GET instance request causes an error when viewing an article on MediaWiki.
	 * 
	 * @access 	public 
	 * @author 	Javier Aragon, <jaragoncaz@gmail.com> 
	 * @param	String		$instanceid		the instance id to be deleted.
	 * @param	String		$host			the host url/name where the request was sent.
	 * @param	String		$user			the user thar request this operation.
	 * @param	String		$language		the user preference language.
	 * @return	void 
	 **/
	function print_get_instance_on_article_error($instanceid, $user, $host, $language){
		$this->setI18N($language);
		
		// Print a div and a table with error message
		//$this->print_close_window_message('getgluetoolsclosewindowmsg');	
		
		$this->print_error_table_messages('getinstanceerrormessage', $instanceid);


		
		// print a javascript to show/hide detailed error message.
		print("<script language='javascript'>");
			print("function showerrordetails(){");
				print("if (document.getElementById('errordetails').style.display==''){");
					print("document.getElementById('errordetails').style.display='none';");
					print("document.getElementById('errordetailmessage').src = './images/table-add-row-after.gif';");
					print("document.getElementById('texttochange').innerHTML='".$this->I18N->getI18NMessage('showdeatilserrormessage')."';");
				print("}else if (document.getElementById('errordetails').style.display=='none'){");
				print("document.getElementById('errordetails').style.display='none';");
					print("document.getElementById('errordetails').style.display='';");
					print("document.getElementById('errordetailmessage').src = './images/table-add-row-before.gif';");
					print("document.getElementById('texttochange').innerHTML='".$this->I18N->getI18NMessage('hidedeatilserrormessage')."';");
				print("}");
			print("}");
		print("</script>");
		
	
		print("<script language='javascript'>");
				// print javascriptcode to try swho 'close window button'.
				print("if (window.top.document.getElementById('glueloadingwindowinstance_2".$instanceid."'))");
					print("window.top.document.getElementById('glueloadingwindowinstance_2".$instanceid."').style.display='none';");
				print("else if (window.top.document.getElementById('glueloadingwindowinstance_".$instanceid."'))");
					print("window.top.document.getElementById('glueloadingwindowinstance_".$instanceid."').style.display='none';");
				
				print("if (window.top.document.getElementById('ViewGlueletIframe".$instanceid."')){");
					print("window.top.document.getElementById('winCloseButtonGlue').style.display='';");
					print("window.top.document.getElementById('ViewGlueletIframe".$instanceid."').style.visibility='visible';");
					print("window.top.document.getElementById('ViewGlueletIframe".$instanceid."').style.frameborder='no';");
				print("}");
				print("else if (window.top.document.getElementById('glue_instance_".$instanceid."')){");
					print("window.top.document.getElementById('glue_instance_".$instanceid."').style.visibility='visible';");
					print("window.top.document.getElementById('glue_instance_".$instanceid."').style.frameborder='no';");
					print("window.top.document.getElementById('glue_instance_".$instanceid."').scrolling='auto';");
					
				print("}");
		
				//print("window.top.document.getElementById('ViewGlueletIframe').style.height='88%';");
				//print("window.top.document.getElementById('winCloseButtonGlue').style.display='';");
				//print("window.top.document.getElementById('gluewindowinstance').style.display='none';");
				//addgluewindow89345711234
				print("ErrorInstance = true;");
		print("</script>");
		
		$params = array();
		$params['instance id'] = $instanceid;
		$params['url'] = $host;
		$params['user'] = $user;
		$params['method'] = $this->method;
		
		$this->print_error_message_details($params);
	}
}

?>