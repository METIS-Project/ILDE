<?php

/**
  This file is part of MediaWikiVLEAdapter.
  
  MediaWikiVLEAdapter is a property of the Intelligent & Cooperative Systems 
  Research Group (GSIC) from the University of Valladolid (UVA). 
  
  Copyright 2011 GSIC (UVA).

  MediaWikiVLEAdapter is licensed under the GNU General Public License (GPL) 
  EXCLUSIVELY FOR NON-COMMERCIAL USES. Please, note this is an additional 
  restriction to the terms of GPL that must be kept in any redistribution of
  the original code or any derivative work by third parties.

  If you intend to use MediaWikiVLEAdapter for any commercial purpose you can 
  contact to GSIC to obtain a commercial license at <glue@gsic.tel.uva.es>.

  If you have licensed this product under a commercial license from GSIC,
  please see the file LICENSE.txt included.

  The next copying permission statement (between square brackets []) is 
  applicable only when GPL is suitable, this is, when MediaWikiVLEAdapter is 
  used and/or distributed FOR NON COMMERCIAL USES.
  
  [ You can redistribute MediaWikiVLEAdapter and/or modify it under the 
    terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
  ]
*/


/**
 * @author Javier Aragon
 */

	/**
	 * Requests to MediaWiki database the registered users.
	 *
	 * @param   String 	$wikidbname         MediaWiki data base name.
	 * @param   String 	$wikihost           MediaWiki data base host.
	 * @param   String  $dbuser             MediaWiki data base user name.
	 * @param   String  $dbpass             MediaWiki data base user password.
	 * @param   String 	$wikidbextension    MediaWiki data base tables prefix.
	 * @return  Array                      	A String array with MediaWiki registered users.
	 */
	function glue_get_mediawiki_users($wikidbname, $wikihost, $dbuser, $dbpass, $wikidbextension){
 
	//sql connection ("host","user","pass")
	$conn = mysql_connect($wikihost,$dbuser,$dbpass);
	
	if (!$conn){
		die('Could not connect: ' . mysql_error());
	}
	
	$result = array();
	
	mysql_select_db($wikidbname, $conn);
	$sql = "SELECT user_name FROM ". $wikidbextension ."user";
	$users = mysql_query($sql);
	while($row = mysql_fetch_array($users)){
		$result[]= $row['user_name'];
	}

	return $result;
	}
	
	/**
	 * Requests to MediaWiki database the registered users.
	 *
	 * @param   String 	$wikidbname         MediaWiki data base name.
	 * @param   String 	$wikihost           MediaWiki data base host.
	 * @param   String  $dbuser             MediaWiki data base user name.
	 * @param   String  $dbpass             MediaWiki data base user password.
	 * @param   String 	$wikidbextension    MediaWiki data base tables prefix.
	 * @return  Array                      	A String array with MediaWiki registered users.
	 */
	function glue_get_mediawiki_users_string_list($wikidbname, $wikihost, $dbuser, $dbpass, $wikidbextension, $wiki_default_user=null){
		global $wgGlueExtensionDefaultUser;
		$userlist = glue_get_mediawiki_users($wikidbname, $wikihost, $dbuser, $dbpass, $wikidbextension);
		
		// Transform the user list (array) into a string.
		$userliststring = "";
		if ($userlist && !empty($userlist)){
			foreach ($userlist as $i => $value) {
				$userliststring .= $value.",";
			}
			// add default glue MediaWiki user at the end of users list.
			if ($wiki_default_user && $wiki_default_user!=null && $wiki_default_user!=""){
				$userliststring .= $wgGlueExtensionDefaultUser;
			}
		}
		return $userliststring;
	}



	function glue_get_instnace_url($url) {
		
		// cURL handler creation
		$ch = curl_init();

		// HTTP method
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");

		// URL
		
		//curl_setopt($ch, CURLOPT_URL, 'http://157.88.130.174:8185/GLUEletManager/tools');
		//curl_setopt($ch, CURLOPT_URL, 'http://localhost:8185/GLUEletManager/tools');
		curl_setopt($ch, CURLOPT_URL, $url);

		// set the handler for delivering answers in strings, instead of being directly printed on page
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

		// perform the HTTP request
		$out = curl_exec($ch);

		// get answer HTTP code
		$status = curl_getinfo($ch, CURLINFO_HTTP_CODE);

		// get cURL error code
		$curl_errno = curl_errno($ch);

		// extract tools list from Atom response
		if (!$curl_errno && $status == 200) {
			$result[0] = false;
			$result[1] = $out;		
		} else{
			// there is a cURL error or http request returned an error status.
			$result[0] = false;
			$result[1] = new GlueletManagerClientError($curl_errno, $status, ($curl_errno ? curl_error($ch) : $out) , 'get_url', false, null);
		}
		
			
		
		// free resources
		curl_close($ch);

		return $result;
	}


?>