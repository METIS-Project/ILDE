<?php

/**
  This file is part of MediaWikiVLEAdapter.
  
  MediaWikiVLEAdapter is a property of the Intelligent & Cooperative Systems 
  Research Group (GSIC) from the University of Valladolid (UVA). 
  
  Copyright 2011 GSIC (UVA).

  MediaWikiVLEAdapter is licensed under the GNU General Public License (GPL) 
  EXCLUSIVELY FOR NON-COMMERCIAL USES. Please, note this is an additional 
  restriction to the terms of GPL that must be kept in any redistribution of
  the original code or any derivative work by third parties.

  If you intend to use MediaWikiVLEAdapter for any commercial purpose you can 
  contact to GSIC to obtain a commercial license at <glue@gsic.tel.uva.es>.

  If you have licensed this product under a commercial license from GSIC,
  please see the file LICENSE.txt included.

  The next copying permission statement (between square brackets []) is 
  applicable only when GPL is suitable, this is, when MediaWikiVLEAdapter is 
  used and/or distributed FOR NON COMMERCIAL USES.
  
  [ You can redistribute MediaWikiVLEAdapter and/or modify it under the 
    terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
  ]
*/

/**
 * VLE GLUE extension - allows users view, create and delete gluelets.
 *
 * @file 
 * @author Javier Aragon
 */

 
if ( ! defined( 'MEDIAWIKI' ) ){
        die();
	}


 
 // Extension credits that will show up on Special:Version
$wgExtensionCredits['parserhook'][] = array(
	'path' => __FILE__,     // Magic so that svn revision number can be shown
	'name' => 'MediaWikiVLEGlueExtension',
	'author' => 'javier aragon',
	'url' => 'http://www.gsic.uva.es/glue/',
	'version' => '0.5',
	'description' => 'A extension to use MediaWiki as a VLE with GLUE',
);


 
//############# Internationalization messages ###############################################
// File with internationalization messages definition.										#
$i18nfile = dirname( __FILE__ ) . '/php/classes/i18n/MediaWikiVLEGlueExtension.i18n.php';	#
// Variable to use internationalization messages in MediaWiki								#
$wgExtensionMessagesFiles['MediaWikiVLEGlueExtension'] = $i18nfile;							#
																							#
//###########################################################################################

	
//############ Directories variables for this extension #####################################
// dir where is instaled this extension.													#
$extensionDIR = "/extensions/MediaWikiVLEGlueExtension"; 									#
// dir where is php package (PHP pages and classes).										#
$phplibDIR = "/php"; 																		#
//path to absolute references.																#
$absolutepath = $wgScriptPath.$extensionDIR;												#
if (defined("wgExtensionAssetsPath")){														#
	$absolutepath = $wgExtensionAssetsPath;													#
}																							#
																							#
//###########################################################################################


//####### Used Hooks Definition #############################################################
// Gluelettag parser Hook.																	#
$wgExtensionFunctions[] = 'wfGlueletParserInit';											#
// GlueToolbar Hook (Insert glue buttons at edit tool bar).									#
$wgHooks['EditPageBeforeEditToolbar'][] = 'wfAddMyGlueletButtonToolBar';					#
// Injects code into the edit page (Imports, javascript, variables).						#
$wgHooks['EditPage::showEditForm:initial'][] = 'wfShowEditorsShowBox';						#
// Displays the gluelets list of gluelet tags contained in article.							#
$wgHooks['EditPage::showEditForm:fields'][] = 'wfNewIFrameLinkDisplay';						#
																							#
//###########################################################################################




//####### Parser Hook Functions #############################################################	

// To interpretate gluelet tags
 function wfGlueletParserInit(/* &$parser*/) {
       global $wgParser;
        $wgParser->setHook( 'gluelettag', 'glueletRender' );
		return true;
}


// To renderize a gluelettag into article view.
function glueletRender( $input, $args, $parser, $frame ) {
		// General global variables from mediawiki.
		global $wgUser, $wgDBserver, $wgDBname , $wgDBuser, $wgDBpassword, $wgDBprefix, $wgTitle, $IP, $wgLang, $i18nfile,  $wgScriptPath, $wgVersion;
		// MediaWikiVLEGlueExtension global variables from extension configuration (@LocalSettings.php).
		global $wgGlueExtensionDefaultUser, $wgNewGlueExtensionGlueletManagerURL, $extensionDIR, $absolutepath;
		// use GlueletManger Host variable as 'glueURL'.
		$glueURL = $wgNewGlueExtensionGlueletManagerURL;

		// Diable cahe as shown at MediaWiki Parser Extension examples.
		$parser->disableCache();
		
		// Try to get caller user to get_instance. If there's no logged user at Mediwiki use default 
		// glue user for MediaWiki defined at MediaWikiVLEGlueExtension configuration in any other case 
		// use the name of logged user at MediaWiki.
		if ($wgUser->getId()==0 || $wgUser->getName()=="127.0.0.1"){
			$user=$wgGlueExtensionDefaultUser;
		} else{
			$user = $wgUser->getName();
		}

		// If input is found (there is any match with the string defined to parse the article).
		// $input variable contains the text parsed. In this case the text returned must be the 
		// text between the open and close gluelettag tags, the text will be the instance id.
		if ($input && $input!=null && $input !=""){
		
			//Before parser text try to get glueletlat parameters
			$title_instance_text = $input;
			if ($args && $args!=null && !empty($args) ){
				// if args not null and not empty
				if ($args['title'] && $args['title']!=null && $args['title']!=""){
					$title_instance_text = $args['title'];
				}
			}
			
			// Build parsetext with an iframe that contains the instance url showed
			// JavaScript to show an hide get_instance call info.
			//$parsetext .=	"";
			$parsetext =	"";
			
			// add scripts in GlueLib.js
			// Try to print an array javascript variable with internationalized messages.

			$parsetext .=	"<script type='text/javascript' src='".$absolutepath."/javascripts/windows/prototype.js'> </script>";
			$parsetext .=	"<script type='text/javascript' src='".$absolutepath."/javascripts/windows/window.js'> </script>";			
			// Delete window effects from article view, renderize problems.
			// $parsetext .=	"<script type='text/javascript' src='../".$extensionDIR."/javascripts/windows/effects.js'> </script>";
			// $parsetext .=	"<script type='text/javascript' src='../".$extensionDIR."/javascripts/windows/window_effects.js'> </script>";
			$parsetext .=	"<script type='text/javascript' src='".$absolutepath."/javascripts/windows/debug.js'> </script>";
			$parsetext .=	"<script type='text/javascript' src='".$absolutepath."/javascripts/GlueLib.js'> </script>";
			$parsetext .=	"<link href='".$absolutepath."/themes/mac_os_x.css' rel='stylesheet' type='text/css'/>"; 
			$parsetext .=	"<link href='".$absolutepath."/themes/default.css' rel='stylesheet' type='text/css'/>"; 
			$parsetext .=	"<link href='".$absolutepath."/themes/ceneterpagediv.css' rel='stylesheet' type='text/css'/>"; 
			
			
			$showimagebutton_alt = wfMsg('showinstanceimagealt');
			$showimagebutton_title = wfMsg('showinstanceimagetitle');
			$hideimagebutton_alt = wfMsg('hideinstanceimagealt');
			$hideimagebutton_title = wfMsg('hideinstanceimagetitle');
			$viewinstancetitle  = wfMsg('showglueletwintitle') . $title_instance_text;
			
			
			
			$image_minimize_url = $absolutepath."/images/minimize.gif";
			$image_maximize_url = $absolutepath."/images/minimize.gif";
			$image_newtab_url 	= $absolutepath."/images/new_tab.png";
			$image_newwin_url 	= $absolutepath."/images/new_window.png";
			$image_reload_url 	= $absolutepath."/images/reload_icon.png";
			$image_loading_url	= $absolutepath."/images/".wfMsg('iloaderdefaultimagefile');
			
			//$parsetext .= 	"<div  id=".$input.">";
			$parsetext .= 		"<h2>";
			$parsetext .= 		"<table width=100% ><tr>";
			$parsetext .=				"<td>";
			$parsetext .=					"<span style='cursor:pointer' onclick=\"showGlueletInfo('".$input."','".$absolutepath."','".$showimagebutton_alt."','".$showimagebutton_title."','".$hideimagebutton_alt."','".$hideimagebutton_title."')\"  class='mw-headline' id='una_instancia'  >";
			$parsetext .=				" ".$title_instance_text."</img>";
			$parsetext .=				"</td>";
			
			$parsetext .=				"<td align=right width=150px >";																																																																																																								
			$parsetext .= 	    			"<img height=20 style='cursor:pointer' hspace=5 onclick=\"showGlueletInfo('".$input."','".$absolutepath."','".$showimagebutton_alt."','".$showimagebutton_title."','".$hideimagebutton_alt."','".$hideimagebutton_title."')\" id='instancedetailbutton_".$input."' alt='".wfMsg('hideinstanceimagealt')."' title='".wfMsg('hideinstanceimagetitle')."'  src='".$image_minimize_url."' >";
			$parsetext .=					"<img height=20 style='cursor:pointer' hspace=5 onclick=reloadInstanceFrame('".$input."') id='instancereloadbutton_".$input."' alt='".wfMsg('reloadinstanceimagealt')."'title='".wfMsg('reloadinstanceimagetitle')."'  src='".$image_reload_url."' >";
			$parsetext .=					"<img height=20 style='cursor:pointer' hspace=5 onclick=\"newWindowInstanceFrame('".$input."','".$viewinstancetitle."','".$absolutepath."','".wfMsg('iframerrormsg')."','".$image_loading_url."','". wfMsg('closewinbuttonlabel')."')\" id='instancnewwindowbutton_".$input."' alt='".wfMsg('newwindowinstanceimagealt')." 'title='".wfMsg('newwindowinstanceimagetitle')."'  src='".$image_newwin_url."' >";
			$parsetext .=					"<img height=20 style='cursor:pointer' hspace=5 onclick=newTabInstanceFrame('".$input."') id='instancenewtabbutton_".$input."' alt='".wfMsg('newtabinstanceimagealt')."'title='".wfMsg('newtabinstanceimagetitle')."'  src='".$image_newtab_url."' >";
			$parsetext .=				"</td>";
			$parsetext .= 		"</tr></table>";
			$parsetext .=		"</span></h2>";
			// the instance url iframe.
			// Try to get MediaWiki user list. Is used when the extension try to show an instance in edit page.
			// Needs to import deafutl functions Library.
			require_once(dirname(__FILE__).'/php/lib.php');
			
			// get mediawiki users request
			$userliststring = glue_get_mediawiki_users_string_list($wgDBname, $wgDBserver, $wgDBuser, $wgDBpassword, $wgDBprefix, $wgGlueExtensionDefaultUser);

			// Create a div to show the loading image.
			$parsetext .="<div align=center id='glueloadingwindowinstance_".$input."' >";
			$parsetext .="<p><img alt='".wfMsg('confloadingimagetext')."' src='".$image_loading_url."' ></img></p>";
			$parsetext .="</div>";
			
			$src = $absolutepath
				."/php/view/showAGlueletOnArticle.php?"
				."instance=".$input
				."&glueletmanager=".$glueURL
				.'&userid='.$user
				."&userlist=".$userliststring
				."&lang=".'es';
					
			$parsetext .=		"<iframe scrolling=no style='visibility:hidden' align=center src='".$src."' width='100%' height=200 id='glue_instance_".$input."' name='glue_instance_".$input."'> <p>".wfMsg('iframerrormsg')."</p> </iframe>";
			
			/*
			$parsetext .= "<script language='javascript'>";
			$parsetext .=		"document.getElementById('view_instance2_".$input."').style.display == 'none'";
			$parsetext .="</script>";
			*/
			//$parsetext .= 	"</div>";
			// return te parsetext.
			return $parsetext;
		} else{
			// If there is no get_instance result, the call failed, show a error message at article page.
			return "<p>- ".wfMsg('nodisplayerrormsg')." --> ". $input ."</p>";
		}
		
        
}
// End of parser hook
//###########################################################################################



//####### Edit Toolbar Buttons Hook Functions ###############################################
function wfAddMyGlueletButtonToolBar( &$toolbar  ) {
		
	// General global variables from mediawiki.
	global $wgUser, $wgDBname, $wgDBuser, $wgDBpassword, $wgDBserver, $wgDBprefix, $wgScriptPath;
	// MediaWikiVLEGlueExtension global variables from extension configuration (@LocalSettings.php).
	global $wgGlueExtensionDefaultUser, $wgNewGlueExtensionGlueletManagerURL, $extensionDIR, $phplibDIR, $absolutepath;
     
	
			
	// Try to get caller user to get_instance. If there's no logged user at Mediwiki use default 
	// glue user for MediaWiki defined at MediaWikiVLEGlueExtension configuration in any other case 
	// use the name of logged user at MediaWiki.
	if ($wgUser->getId()==0 || $wgUser->getName()=="127.0.0.1"){
		$user=$wgGlueExtensionDefaultUser;
	} else{
		$user = $wgUser->getName();
	}
	
	// Try to get MediaWiki user list. Is used when the extension try to show an instance in edit page.
	// Needs to import deafutl functions Library.
	require_once(dirname(__FILE__).'/php/lib.php');
	// get mediawiki users request
	$userlist = glue_get_mediawiki_users($wgDBname, $wgDBserver, $wgDBuser, $wgDBpassword, $wgDBprefix);
	// Transform the user list (array) into a string.
	$userliststring = "";
	if ($userlist && !empty($userlist)){
		foreach ($userlist as $i => $value) {
			$userliststring .= $value.",";
		}
		// add default glue MediaWiki user at the end of users list.
		$userliststring .= $wgGlueExtensionDefaultUser;
	}
	
	// internationalized labels and images for glue buttons.
	// create a gluelet image button.
	$newgluelet_imagebuttonurl = $absolutepath.'/images/'.wfMsg( 'newglueletbutton');
	// create a gluelet title text.
	$newgluelet_imagetitletext = wfMsg('newglueletbuttontittle');
	// create a gluelet alternative text.
	$newgluelet_imagealttext = wfMsg('newglueletbuttonalttext');
	// delete a gluelet image button.
	$showgluelets_imagebuttonurl = $absolutepath.'/images/'.wfMsg('notshowglueletbutton');
	// delete a gluelet alternative text.
	$showgluelets_imagealttext = wfMsg('notshowglueletbuttonalttext');
	// delete a gluelet title text.
	$showgluelets_imagetitletext = wfMsg('notshowglueletbuttonlabel');
	

	// define gluelet tag pattern to find divs.
	$tag="div";
	$pattern ="%<$tag.*?>(.*?)<\/$tag.*?>%is";
	preg_match_all($pattern,$toolbar,$m, PREG_PATTERN_ORDER);
	
	if ($toolbar && $toolbar!=null && $toolbar!=""){
		// Add New Gluelet Button to edit toolbar.
		$toolbar .= "<input type='hidden' id='instancecontrol'/><input type='hidden' id='instancetitlecontrol'/><script type='text/javascript' language='javascript'>
			if (document.getElementById('toolbar')){
				var tempInnerHTML = document.getElementById('toolbar').innerHTML;
				var newInnerHTML = tempInnerHTML.concat('<img style=cursor:pointer height=22 title=\'".$newgluelet_imagetitletext." \' alt=\' ".$newgluelet_imagealttext." \' src=".$newgluelet_imagebuttonurl." onclick=\"newInstanceDialogOnMacOSWindow(\'".$user."\',\'".$userliststring."\',\'".$wgNewGlueExtensionGlueletManagerURL."\',\'".$absolutepath."\',\'".$phplibDIR."\')\">');
				document.getElementById('toolbar').innerHTML = newInnerHTML;
			};
		</script>";
		
		// Add Delete Gluelet Button to edit toolbar.
		$toolbar .= "<input type='hidden' id='instancecontrol'><script type='text/javascript' language='javascript'>
			if (document.getElementById('toolbar')){
				var tempInnerHTML = document.getElementById('toolbar').innerHTML;
				var newInnerHTML = tempInnerHTML.concat('<img style=cursor:pointer id=showglueletsimage height=22 title=\'".$showgluelets_imagetitletext." \' alt=\' ".$showgluelets_imagealttext." \' src=".$showgluelets_imagebuttonurl." onclick=showInstancesClick(\'".$absolutepath."\')></a>');
				document.getElementById('toolbar').innerHTML = newInnerHTML;
			};
		</script>";

		return true;
	} else {
		return false;
	}

}
// End of toolbar buttons hook
//###################################################################################

 


//####### Injects code Hook Functions ###############################################
function wfShowEditorsShowBox( ) {
	
	// General global variables from mediawiki.
	global $wgOut, $wgLang, $wgScriptPath;
	// MediaWikiVLEGlueExtension global variables from extension configuration (@LocalSettings.php).
	global $extensionDIR,  $i18nfile, $absolutepath;

	
	// Javascript libraries Required.
	$wgOut->addHTML(" 
	<script type='text/javascript' src='".$absolutepath."/javascripts/windows/prototype.js'> </script> 
	<script type='text/javascript' src='".$absolutepath."/javascripts/windows/window.js'> </script> 
	<script type='text/javascript' src='".$absolutepath."/javascripts/windows/debug.js'> </script>


	<!-- Add this to have a specific theme--> 
	<link href='".$absolutepath."/themes/mac_os_x.css' rel='stylesheet' type='text/css'/> 
	<link href='".$absolutepath."/themes/default.css' rel='stylesheet' type='text/css'/> 
	
	<script type='text/javascript' src='".$absolutepath."/javascripts/GlueLib.js'> </script>
	<script type='text/javascript' src='".$absolutepath."/javascripts/GlueletManagerClient.js'> </script>

	");
	
	
	// Try to print an array javascript variable with internationalized messages.
	// This is cause need to use it in 'pop-up' windows that are implemented in javascript.
	$lang = $wgLang->getCode();
	require_once($i18nfile);
	$wgOut->addHTML("<script type='text/javascript'>");
	$wgOut->addHTML(" var languagearray = new Array(); ");		
	//$wgOut->addHTML(" var languagearray = new Array(); ");		
	if (!$messages[$lang]){
		$lang = 'en';
	}
	//foreach ($messages as $key => $value){
	$wgOut->addHTML("var defaultGlueUserLanguage = '".$lang."'; ");
	$wgOut->addHTML("languagearray['". $lang ."'] = new Array(); ");
		// S�lo a�adimos el lenguje definido por el usuario.
		foreach($messages[$lang] as $k => $v){
			$wgOut->addHTML("languagearray['". $lang ."']['". $k ."'] = \"".$messages[ $lang ][ $k ]."\"; ");
		}
	//}
	$wgOut->addHTML("</script>");	
	
	return true;
}
// End os inject hook function.
//###################################################################################



//########  Gluelets List Hook ######
function wfNewIFrameLinkDisplay(&$q, &$out) {

	

	// General global variables from mediawiki.
	global $wgUser, $wgDBname, $wgDBuser, $wgDBpassword, $wgDBserver, $wgDBprefix, $wgScriptPath;
	// MediaWikiVLEGlueExtension global variables from extension configuration (@LocalSettings.php).
	global $wgGlueExtensionDefaultUser, $wgNewGlueExtensionGlueletManagerURL, $extensionDIR, $phplibDIR, $absolutepath;
    // use GlueletManger Host variable as 'glueURL'.
	$glueURL = $wgNewGlueExtensionGlueletManagerURL;
			
	// Try to get caller user to get_instance. If there's no logged user at Mediwiki use default 
	// glue user for MediaWiki defined at MediaWikiVLEGlueExtension configuration in any other case 
	// use the name of logged user at MediaWiki.
	if ($wgUser->getId()==0 || $wgUser->getName()=="127.0.0.1"){
		$user=$wgGlueExtensionDefaultUser;
	} else{
		$user = $wgUser->getName();
	}
	
	
	// Print a parent div that will contain all tool divs
	$out->addHTML("<div id='instances'>");
	// Obtain the article's text to load the gluelets list.
	$texto = $q->getArticle()->getContent();
	// Define the gluelet tag label to parse it on article's text.
	$tag="gluelettag";
	/*
	// Define the parse pattern.
	$pattern ="%<$tag.*?>(.*?)<\/$tag.*?>%is";
	// Try to find the pattern.
	preg_match_all($pattern,$texto,$gluelets, PREG_PATTERN_ORDER);
	*/
	
	// Extract gluelets from article text
	require_once(dirname(__FILE__).'/php/classes/utils/TagInfoExtractor.php');
	$extractor = new TagInfoExtractor($texto,$tag);
	$gluelets = ($extractor->get_extraction());
	/*********************************************/
	
	
	//$gluelets[0] contains array of strings that matched full pattern, and $gluelets[1] contains array of strings enclosed by tags. 	
	if ($gluelets && $gluelets!=null && !empty($gluelets)){
		
		// Internationalized labels and images for delete instance button/image.
		// delete a gluelet image button.
		$imagebuttonurl = '/images/'.wfMsg( 'deleteinstancebutton');
		// delete a gluelet title text.
		$titletext = wfMsg('deleteinstancebuttontittle');
		// delete a gluelet alternative text.
		$alttext = wfMsg('deleteinstancetbuttonalttext');
		
		// Try to get MediaWiki user list. Is used when the extension try to show an instance in edit page.
		// Needs to import deafutl functions Library.
		require_once(dirname(__FILE__).'/php/lib.php');
		// get mediawiki users request
		$userlist = glue_get_mediawiki_users($wgDBname, $wgDBserver, $wgDBuser, $wgDBpassword, $wgDBprefix);
		// Transform the user list (array) into a string.
		$userliststring = "";
		if ($userlist && !empty($userlist)){
			foreach ($userlist as $i => $value) {
				$userliststring .= $value.",";
			}
			// add default glue MediaWiki user at the end of users list.
			$userliststring .= $wgGlueExtensionDefaultUser;
		}

		// If it has gluelets
		foreach($gluelets as $key => $tag_info_array){
				
				$title ="";
				$instanceid = "";
				$title_property= "title";
				
				if ($tag_info_array && $tag_info_array!=null && !empty($tag_info_array)){
					if ($tag_info_array['contents'] && $tag_info_array['contents']!=null && $tag_info_array['contents']!=""){
						$instanceid = $tag_info_array['contents'];
						if ($tag_info_array['attributes'] && $tag_info_array['attributes']!=null && !empty($tag_info_array['attributes']))
							if ($tag_info_array['attributes'][$title_property] && $tag_info_array['attributes'][$title_property]!=null && $tag_info_array['attributes'][$title_property]!="")
								$title = $tag_info_array['attributes'][$title_property];
					}
				}
							
				// Javascript gluelib library Required.
				$out->addHTML("<script type='text/javascript' src='".$absolutepath."/javascripts/GlueLib.js'> </script>");
				// Call to add a gluelet function. This function try to add a div with the gluelet instance id. This div contains 
				// a link to view the gluelet instance and a button to delete it. If the gluelet instance id given as $value 
				// variable already exists in the list it isn't added. We have to use a javascript function because it cannot be 
				// verifyed that the tool you want to add is not already listed.
				if ($instanceid && $instanceid!=null && $instanceid!=""){
					$out->addHTML("<script type='text/javascript'> addNewGlueInstance('".$instanceid."','".$title."','".$user."','".$glueURL."','".$absolutepath."','".$phplibDIR."','".$userliststring."',0); </script>");
				}
		}
	}
	
	//Close the parent div.
	$out->addHTML("</div>");
	
	

	return true; 
}
// End of gluetlist div add hook function.
//###################################################################################


?>