


		/** 
		* Returns a message internationalized given by the language and the identifier passed as parameters.
		* It returns the message in the language selected if it's found in the internationalization file or  the identifier given as a parameter in any other case.	
		* 
		* @access 	public 
		* @author 	Javier Aragon, <jaragoncaz@gmail.com> 
		* @param 	id   	String		A message identifier to obtain this message internationalized.
		* @param 	lang   	String      User language selected.
		* @return 	string 
		**/
		function getI18NMessages(idMessage){
			// try to get the message
			try{
				// Set language to defaultGlueUserLanguage, if it's not exists set it to default language 'en'/english
				if(defaultGlueUserLanguage && defaultGlueUserLanguage!=null && defaultGlueUserLanguage!=""){
					lang = defaultGlueUserLanguage;
				}else{
					lang ='en';
				}
				// Obtain de message from the langage array
				if (languagearray && languagearray!=null && languagearray.length<1 &&
						languagearray[lang] && languagearray[lang]!=null && languagearray[lang].length<1 &&
							languagearray[lang][idMessage] && languagearray[lang][idMessage]!=null && languagearray[lang][idMessage]!="") {
					return languagearray[lang][idMessage];
				} else{
					return idMessage;
				}
			}catch (err){
				// any case of exception return the idMessage.
				return idMessage;
			}
			
		}
		
		




		/** 
		* Change show gluelet list button to hide gluelet list button and backwards. Also hide and show the instance list.
		* 
		* 
		* @access 	public 
		* @author 	Javier Aragon, <jaragoncaz@gmail.com> 
		* @param 	dir   	String		path directory to get image button files.
		* @return 	void 
	 	*/
		function showInstancesClick(dir){

			imagenotshowgluelets = '/images/'+getI18NMessages('notshowglueletbutton');
			imageshowgluelets = '/images/'+getI18NMessages('showglueletbutton');
			labelnotshowgluelets = getI18NMessages('notshowglueletbuttonlabel');
			labelshowgluelets = getI18NMessages('showglueletbuttonlabel');
			altshowgluelets = getI18NMessages('showglueletbuttonalttext');		
			altnotshowgluelets = getI18NMessages('notshowglueletbuttonalttext');
			
			if (document.getElementById("instances").style.display==''){
				document.getElementById("instances").style.display='none';
				document.getElementById("showglueletsimage").src = dir+imageshowgluelets;
				document.getElementById("showglueletsimage").alt = altshowgluelets;
				document.getElementById("showglueletsimage").title = labelshowgluelets;
				//document.getElementById("showinstances").innerHTML="<a href=# onclick=showInstancesClick()> Mostrar Glulets Creados</a>";
				//document.getElementById("showinstances").innerHTML="<img src='./images/plus_add.png' onclick=showit()><u><b>  "+inflabel+"</img> </b></u></img>";
			}else if (document.getElementById("instances").style.display=='none'){
				document.getElementById("instances").style.display='';
				document.getElementById("showglueletsimage").src = dir+imagenotshowgluelets;
				document.getElementById("showglueletsimage").alt = altnotshowgluelets;
				document.getElementById("showglueletsimage").title = labelnotshowgluelets;
				//document.getElementById("showinstances").innerHTML="<a href=# onclick=showInstancesClick()> Ocultar Glulets Creados</a>";
				//document.getElementById("showinstances").innerHTML="<img src='./images/minus_remove.png' onclick=showit()><u><b>  "+inflabel+"</img> </b></u></img>";
			}
		}
		
		
		
		/** 
		* Adds a new element to the instance list.
		* 
		* 
		* @access 	public 
		* @author 	Javier Aragon, <jaragoncaz@gmail.com> 
		* @param 	instance_ID   				String		the instance id to be added to list.
		* @param 	title		   				String		a title for instance.
		* @param 	user   						String		ther caller user.
		* @param 	glueletmanagerURL  			String		gluelet manager host complete url.
		* @param 	dir   						String		path directory where is instaled this extension.
		* @param 	phpdir   					String		path directory where is php libraries.
		* @param 	userlist   					String		MediaWiki users list.
		* @param 	addGlueletToWpTextBox1		boolean		true if want to add gluelettag to text box.
		* @return 	void 
	 	*/
		function addNewGlueInstance(instance_ID, title, user, glueletmanagerURL, dir, phpdir, userlist, addGlueletToWpTextBox1){		

		
			if (instance_ID != null && instance_ID != "" ){
			
				// check before any operation if there is a div with id 'instance_ID'
				thereisanelement = false;
				try{
					thereisanelement = (document.getElementById(instance_ID) != null)
				}catch(eer){
				}
				
				if (!thereisanelement){
				
					imagebuttonurl = '/images/'+getI18NMessages('deleteinstancebutton');
					titletext = getI18NMessages('deleteinstancebuttontittle');
					alttext = getI18NMessages('deleteinstancetbuttonalttext');
			
					var tempInnerHTML = document.getElementById("instances").innerHTML;
				
					// Generate the new div for the instance text which is shown in edition when a new gluelet is created.
					var newinstancetext =""; 				
					newinstancetext = newinstancetext.concat(	"<div  style='position: relative;float:left;overflow:hidden;width:200px;height:30px' id="+instance_ID+">");
					newinstancetext = newinstancetext.concat(		"<div id='"+getI18NMessages('editinstancedivcontent')+instance_ID+"'>");			
					newinstancetext = newinstancetext.concat(			"<table valign=middle><tr>");
					newinstancetext = newinstancetext.concat(			"<td>");
					newinstancetext = newinstancetext.concat(				"<a href=# onclick=deleteGlueInstanceDialog('"+instance_ID+"','"+glueletmanagerURL+"','"+ user +"','"+dir+phpdir+"')><img heigth='' heigth='20px' width='20px' title='"+titletext+"' alt='"+alttext+"' src="+dir+imagebuttonurl+" ></a>");
					newinstancetext = newinstancetext.concat(			"</td>");
					newinstancetext = newinstancetext.concat(			"<td >");
					newinstancetext = newinstancetext.concat(				"<a href=# onclick=\"instanceDisplayMacOSWindow('"+ glueletmanagerURL +"','"+ instance_ID +"','"+ user +"','"+dir+"','"+userlist+"','"+title+"')\" >");
					/*if (title && title!=null && title!="")
						newinstancetext = newinstancetext.concat(				"'" + title + "'<br></a>"+"id: " + instance_ID);
					else */
					newinstancetext = newinstancetext.concat(					instance_ID + "</a>");
					newinstancetext = newinstancetext.concat(			"</td>");
					newinstancetext = newinstancetext.concat(			"</tr></table>");
					newinstancetext = newinstancetext.concat(		"</div>");
					newinstancetext = newinstancetext.concat(	"</div>");
				
					var newInnerHTML = tempInnerHTML.concat(newinstancetext);
					document.getElementById("instances").innerHTML = newInnerHTML;
		
					if (addGlueletToWpTextBox1){
						if (document.getElementById("wpTextbox1")){
							TheTextBox = document.getElementById("wpTextbox1");
						
							// insert gluelet tag at the end of the document.
							//TheTextBox.value = TheTextBox.value + '{gluelet}' + instance_ID + '{gluelet}';
						
							//insertar gluelet tag at cursor
							inittagtext = "";
							if (title && title!=null && title!="")
								inittagtext += '<gluelettag title=\"'+title+'\">'
							else
								inittagtext +='<gluelettag>'
							insertAtCursor(TheTextBox, inittagtext + instance_ID + '</gluelettag>');
						}
					}
				}
			}
		}
		
		
		/** 
		* Inserts a text into a text area at cursor position.
		* 
		* 
		* @access 	public 
		* @author 	Javier Aragon, <jaragoncaz@gmail.com> 
		* @param 	myField   	String		field form id.
		* @param 	myValue   	String		the text to be inserted.
		* @return 	void 
	 	*/
		function insertAtCursor(myField, myValue) {
			//IE support
			if (document.selection) {
				myField.focus();
				sel = document.selection.createRange();
				sel.text = myValue;
			}else if (myField.selectionStart || myField.selectionStart == '0') {
				//MOZILLA/NETSCAPE support
				var startPos = myField.selectionStart;
				var endPos = myField.selectionEnd;
				myField.value = myField.value.substring(0, startPos)
				+ myValue
				+ myField.value.substring(endPos, myField.value.length);
			} else {
				myField.value += myValue;
			}
		}
		
		
		
		/*
		* Global varibles used on deleted dialog
		*
		*/
		var instanceID = "";
		var glueletManagerURL="";
		var deletewin = null;
		var dirDeletePHP = "";
		var userDelete = "";
		
		
		/** 
		* Shows the instance delete dialog. This dialog allows to delete a instance from MediaWiki Article (deleting gluelet tag) or delete it from gluelet manager database and article
		* 
		* 
		* @access 	public 
		* @author 	Javier Aragon, <jaragoncaz@gmail.com> 
		* @param 	instance	   		String		the instance id to be added to list.
		* @param 	user   				String		ther caller user.
		* @param 	url   				String		gluelet manager host complete url.
		* @param 	phpdir   			String		path directory where is php libraries.
		* @return 	void 
	 	*/
		function deleteGlueInstanceDialog(instance, url, user, phpdir){
		
			instanceID = instance;
			glueletManagerURL = url;
			dirDeletePHP = phpdir;
			userDelete = user;
			
			if (document.getElementById("wpTextbox1")){
				
				TheTextBox = document.getElementById("wpTextbox1");
				if (TheTextBox){
					pattern = new RegExp('<gluelettag[^>]*>' + instance + '</gluelettag>', 'gim');
					matches = TheTextBox.value.match(pattern);
				}
				
				deletemessage = getI18NMessages('deleteinstancedatabasemessage');
				if (matches && matches!=null && matches.length>0)
					deletemessage = deletemessage.replace("{number_of_matches}",matches.length); 
				else 
					deletemessage = deletemessage.replace("{number_of_matches}","1"); 
				deletemessage = deletemessage.replace("{gluelet_id_instance}",instance);
				title = getI18NMessages('deleteinstancebuttontittle') + ' --> ' + instance;
				yeslabel = getI18NMessages('deleteinstanceyesbutton');
				nolabel = getI18NMessages('deleteinstancenotbutton');
				cancellabel = getI18NMessages('deleteinstancecancelbutton');
				
				theme_dialog = getI18NMessages('windowsdialogtheme');
					
				deletewin =	DeleteInstanceDialog.confirm('<p>'+deletemessage+'</p>', 
							{height: 220, width:540, zIndex: 999999, recenterAuto:true, title: title, centerButtons: false,
							className: theme_dialog, 
							okLabel: yeslabel, 
							cancelLabel: cancellabel,
							noLabel: nolabel,
							ok: onDeleteOkButtonPressed,
							no: onDeleteNoButtonPressed,
							cancel: onDeleteCancelButtonPressed,
							});
				}
		}
		
		
		/** 
		* function throwed when OK button on 'Delete Instance Dialog' was pressed.
		* 
		* 
		* @access 	public 
		* @author 	Javier Aragon, <jaragoncaz@gmail.com> 
		* @return 	boolean 	true if delete instance from article and database (both) success or false in any other case. 
	 	*/
		function onDeleteOkButtonPressed(){
			if (confirm(getI18NMessages("reallywanttodelete"))) { 
				if (deleteInstanceGlueletTagFromArticle(instanceID))
					if (deleteInstanceGlueletTagFromDataBase())
						return true;
				else
					return false;
			} else {
				return false;
			}	
		}
		/** 
		* function throwed when NO button on 'Delete Instance Dialog' was pressed.
		* 
		* 
		* @access 	public 
		* @author 	Javier Aragon, <jaragoncaz@gmail.com> 
		* @return 	boolean 	true if delete instanc from article scces or false in any other case. 
	 	*/
		function onDeleteNoButtonPressed(){
			if (deleteInstanceGlueletTagFromArticle(instanceID))
				return true;
			else
				return false;
		}
		/** 
		* function throwed when CANCEL button on 'Delete Instance Dialog' was pressed.
		* 
		* 
		* @access 	public 
		* @author 	Javier Aragon, <jaragoncaz@gmail.com> 
		* @return 	boolean 	always true (nothing to do). 
	 	*/
		function onDeleteCancelButtonPressed(){
			return true;
		}
		
		/** 
		* function called when NO button or OK button on 'Delete Instance Dialog' were pressed. This function deletes the gluelettag from MediaWiki article.
		* 
		* 
		* @access 	public 
		* @author 	Javier Aragon, <jaragoncaz@gmail.com> 
		* @return 	boolean 	true if delete instanc from article scces or false in any other case. 
	 	*/
		function deleteInstanceGlueletTagFromArticle(instance){
			// try to get the article's edition text box, and try to delete de instance
			try{
			
				TheTextBox = document.getElementById("wpTextbox1");
				if (TheTextBox){
					pattern = new RegExp('<gluelettag[^>]*>' + instance + '</gluelettag>', 'gim');
					matches = TheTextBox.value.match(pattern);
				}
				
				if(matches && matches!=null && matches.length>0){
					for (i = 0; i < matches.length; i++){
						match = matches[i];
						while (TheTextBox.value.indexOf(match) != -1){
							TheTextBox.value = TheTextBox.value.replace(match,"");
						}
					}
				}
				
				if ( document.getElementById(getI18NMessages('editinstancedivcontent')+instance) )
					document.getElementById(getI18NMessages('editinstancedivcontent')+instance).innerHTML = "Eliminado - " + instance;
				
				return true;
			}catch (err){
				txt = getI18NMessages('ondeletefromarticleerror');
				txt+="Error description: " + err.description + "\n\n";
				txt+="Click OK to continue.\n\n";
				alert(txt);
				return false;
			}	
		}
		
		/** 
		* Function called when OK button on 'Delete Instance Dialog' were pressed. This function deletes the gluelettag from MediaWiki article
		* Shows a dialog that deletes the instance.
		* 
		* @access 	public 
		* @author 	Javier Aragon, <jaragoncaz@gmail.com> 
		* @return 	boolean 	true if delete instance from gluelet manager database success or false in any other case. 
	 	*/
		function deleteInstanceGlueletTagFromDataBase(){
			try{
				//theCheckBox = document.getElementById(getI18NMessages('editinstancecheckbox')+instance);
				//theCheckBox.checked=1;

				deletewin.setURL2(dirDeletePHP+"/delete/delete_instances_interface.php?instance="+instanceID+"&user="+userDelete+"&glueletmanager="+glueletManagerURL+"&lang="+defaultGlueUserLanguage,
					getI18NMessages('closewinbuttonlabel'));
				return false;
				//var glueletManagerHttpClient = new GlueletManagerClient(glueletManagerURL);
				//glueletManagerHttpClient.doDeleteInstance(instance)
			}catch (err){
				txt = getI18NMessages('ondeletefromdatabaseerror');
				txt+="Error description: " + err.description + "\n\n";
				txt+="Click OK to continue.\n\n";
				alert(txt);
				return false;
			}
		}
		
		
		
		/** 
		* Shows the new instance dialog. This dialog allows to create a new instance into a MediaWiki Article. Create an instance and
		* insert the gluelet tag into article and add the instance to instaces list.
		* 
		* 
		* @access 	public 
		* @author 	Javier Aragon, <jaragoncaz@gmail.com> 
		* @param 	wikiuser   		String		ther caller user.
		* @param 	wikiuserlist	String		MediaWiki users list.
		* @param 	url   			String		gluelet manager host complete url.
		* @param 	dir  			String		path directory where is instaled this extension.
		* @param 	phpdir   		String		path directory where is php libraries.
		* @return 	void 
	 	*/
		function newInstanceDialogOnMacOSWindow(wikiuser, wikiuserlist, url, dir, phpdir){		
			
			document.getElementById("instancecontrol").value = '';
			
			// window observer. Sirve para capturar el evento de cierre de la ventana y as� poder acceder a ella y realizar operaciones...
			var myObserver = {
				onClose: function(eventName, win) {
					if (win.getId() == 'addgluewindow89345711234'){
						if(document.getElementById("instancecontrol")){
							if (document.getElementById("instancecontrol") && document.getElementById("instancecontrol")!=""){
								title = "";
								if (document.getElementById("instancetitlecontrol") && document.getElementById("instancetitlecontrol")!=null)
									title = document.getElementById("instancetitlecontrol").value;
								addNewGlueInstance(document.getElementById("instancecontrol").value, title, wikiuser, url, dir, phpdir, wikiuserlist, 1);
								document.getElementById("instancecontrol").value = '';
								document.getElementById("instancetitlecontrol").value = '';
							}
						}
					}
				},
				
				onHide: function(eventName, win){
					alert('onhide: ' + eventName);
				}
			};
			Windows.addObserver(myObserver);
			
			theme_dialog = getI18NMessages('windowsdialogtheme');
			
			win = new Window({id: "addgluewindow89345711234", className: theme_dialog, resizable: false, zIndex: 999999, recenterAuto:true, title: getI18NMessages('confwindowtitlelabel'), 
				width:500, height:200, destroyOnClose: true, recenterAuto:true, draggable:true, wiredDrag: true}); 
			
			win.setHTMLContent(
			"<link rel='stylesheet' href='"+dir+"/themes/ceneterpagediv.css'>"+
			"<div class=centerpagediv id='gluewindowinstance' >" +
				"<center><p><img alt='"+getI18NMessages('confloadingimagetext')+"' src='"+dir+"/images/"+getI18NMessages('iloaderdefaultimagefile')+"' ></img></p></center>" + 
			"</div>" +
				"<iframe style='display:none' name=NewGlueletConfigurationform id=NewGlueletConfigurationform align=center src='"+dir+phpdir+"/conf/configuration_1.php?user="+wikiuser+"&userlist="+wikiuserlist+"&glueletmanager="+url+"&lang="+lang+"' frameBorder=0 scrolling=auto "+
					"width='100%' height='100%' > <p>"+getI18NMessages('iframerrormsg')+"</p>" + 
				" </iframe>"+
			"<center>" + 
				"<div width='100%'  height=1 style='display:none' id='winCloseButtonGlue'><input type='button'  value='" + getI18NMessages('closewinbuttonlabel') + "' onclick='win.close()'>" +
				"</div>" + 
			"</center>");
			
			win.showCenter(true); 	
		} 
		
		
		/** 
		* Returns window size.
		* 
		* 
		* @access 	public 
		* @author 	Javier Aragon, <jaragoncaz@gmail.com> 
		* @return 	Array [x,y] [width,height] window size.
	 	*/
		function TamVentana() {  
			var Tamanyo = [0, 0];  
			if (typeof window.innerWidth != 'undefined')  {  
					Tamanyo = [  
						window.innerWidth,  
						window.innerHeight  
					];  
			}  else if (typeof document.documentElement != 'undefined' 
							&& typeof document.documentElement.clientWidth != 'undefined' 
								&& document.documentElement.clientWidth != 0)  {  
				 Tamanyo = [  
						document.documentElement.clientWidth,  
						document.documentElement.clientHeight  
					];  
			}  else   {  
				Tamanyo = [  
					document.getElementsByTagName('body')[0].clientWidth,  
					document.getElementsByTagName('body')[0].clientHeight  
				];  
			}  
			return Tamanyo;  
		}  
		
		
		
		/** 
		* Shows the an instance dialog. This dialog allows to view an instance url.
		* 
		* 
		* @access 	public 
		* @author 	Javier Aragon, <jaragoncaz@gmail.com> 
		* @param 	instance_ID		String		the instance id to be shown.
		* @param 	user   			String		ther caller user.
		* @param 	userlist		String		MediaWiki users list.
		* @param 	url   			String		gluelet manager host complete url.
		* @param 	dir  			String		path directory where is instaled this extension.
		* @return 	void 
	 	*/
		function instanceDisplayMacOSWindow(url, instance_ID, user, dir, userlist, instancetitle){
					
			var t = TamVentana();
			w = t[0] * 0.8;
			h = t[1] * 0.8;
			
			
			windowtitle = instance_ID;
			if (instancetitle && instancetitle!=null && instancetitle!="")
				windowtitle = instancetitle;
			if (windowtitle.length > 100)
				windowtitle = windowtitle.substr(0,100) + ' [...]';
				
			theme_dialog = getI18NMessages('windowsdialogtheme');
				
			winInstanceDisplay = new Window({id: "instanceDisplayWindow", className: theme_dialog,  resizable: false, zIndex: 999999, recenterAuto:true, 
				title: getI18NMessages('showglueletwintitle') + windowtitle, width:w, height:h, left:30, top:30,  
				destroyOnClose: true, recenterAuto:true}); 
			//, url: './extensions/showAGluelet.php?instance_ID='+instance_ID
				// Create a div to show the loading image.
			winInstanceDisplay.getContent().innerHTML="cargando 1:";
			winInstanceDisplay.showCenter(true); 
			winInstanceDisplay.setHTMLContent(
					// user center page div style
					"<link rel='stylesheet' href='"+dir+"/themes/ceneterpagediv.css'>"+
					"<div id=loadingdiv class=centerpagediv><center><p><img alt=' Cargando ... ' src='"+dir+"/images/"+getI18NMessages('iloaderdefaultimagefile')+"' ></img></p></center></div>" +
					"<iframe style='visibility:hidden' id='ViewGlueletIframe' align=center src='"+dir+'/php/view/showAGlueletOnEdit.php?toolid='+instance_ID+'&glueletmanager='+url+'&userid='+user+'&userlist='+userlist+'&lang='+lang+"' frameBorder=0 scrolling=auto "+
					"width='100%' height='100%' > <p>"+getI18NMessages('iframerrormsg')+"</p>" + 
					" </iframe>"+
					"<center>" + 
					"<div width='100%'  height=1 style='display:none' id='winCloseButtonGlue'><input type='button'  value='" + getI18NMessages('closewinbuttonlabel') + "' onclick='winInstanceDisplay.close()'>" +
						"</div>" + 
					"</center>");
			winInstanceDisplay.toFront();
		} 
		
		
				
		
		
		 function showGlueletInfo(cadena, extensiondir, showalt, showtitle, hidealt, hidetitle) {
			 if (document.getElementById('glue_instance_'+cadena).style.display == ''){
				 document.getElementById('glue_instance_'+cadena).style.display='none';
				 document.getElementById('instancedetailbutton_'+cadena).src= extensiondir+'/images/maximize.gif';
				 document.getElementById('instancedetailbutton_'+cadena).alt=showalt;
				 document.getElementById('instancedetailbutton_'+cadena).title=showtitle;
			 }else if(document.getElementById('glue_instance_'+cadena).style.display == 'none'){
				 document.getElementById('glue_instance_'+cadena).style.display='';
				 document.getElementById('instancedetailbutton_'+cadena).src=  extensiondir+'/images/minimize.gif';
				 document.getElementById('instancedetailbutton_'+cadena).alt=hidealt;
				 document.getElementById('instancedetailbutton_'+cadena).title=hidetitle;
			 } 
		 } 
		 

		function newTabInstanceFrame (instance){
			if (instance) if (instance!=null) if (instance!=''){
				thisinstanceframe = getInstanceFrame(instance);
				if (thisinstanceframe){
					window.open(thisinstanceframe.location,"_blank");
				}
			}
		}
		
		function newWindowInstanceFrame (instance, title, dir, iframeerrormessage,loadingimagefile, closelabel){
			if (instance) if (instance!=null) if (instance!=''){
				thisinstanceframe = getInstanceFrame(instance);
				if (thisinstanceframe){

					var t = TamVentana();
					w = t[0] * 0.8;
					h = t[1] * 0.8;
					var myViewIntanceWindowObserver = {
						onClose: function(eventName, win) {
							if (win.getId() == 'instanceDisplayWindow891324321423'){
								if (window.top.document.getElementById('glue_instance_'+instance)){
									window.top.document.getElementById('glue_instance_'+instance).style.visibility='visible';
								}	
							}
						}
					};
					// window observer. Sirve para capturar el evento de cierre de la ventana y as� poder acceder a ella y realizar operaciones...					
					Windows.addObserver(myViewIntanceWindowObserver);
					
					if (title.length > 100)
						title = title.substr(0,100) + ' [...]';
					
					winInstanceDisplay = new Window({id: "instanceDisplayWindow891324321423", className: 'mac_os_x',  resizable: false, zIndex: 999999, recenterAuto:true, 
						title: title, width:w, height:h, left:30, top:30,  
						destroyOnClose: true, recenterAuto:true});
						//, url: thisinstanceframe.location}); 
					winInstanceDisplay.setHTMLContent(
						"<div id='glueloadingwindowinstance_2"+instance+"' class=centerpagediv><center><p><img alt=' Cargando ... ' src='"+loadingimagefile+"' ></img></p></center></div>" +
						"<iframe style='visibility:hidden' id='ViewGlueletIframe"+instance+"' align=center src='"+thisinstanceframe.location+"' frameBorder=0 scrolling=auto "+
						"width='100%' height='100%' > <p>"+iframeerrormessage+"</p>" + 
						" </iframe>"+
						"<center>" + 
						"<div width='100%'  height=1 style='display:none' id='winCloseButtonGlue'><input type='button'  value='" +closelabel + "' onclick='winInstanceDisplay.close()'>" +
							"</div>" + 
						"</center>"
					);						
					winInstanceDisplay.showCenter(true); 
					if (window.top.document.getElementById('glue_instance_'+instance)){
						window.top.document.getElementById('glue_instance_'+instance).style.visibility='hidden';
					}
				}
			}
		}
		
		
		function getInstanceFrame(instance){
			instanceframe = null;
			if (instance) if (instance!=null) if (instance!=''){
				instanceframe = parent.frames['glue_instance_'+instance];
			}
			return instanceframe;
		}
		 
		 function reloadInstanceFrame(instance){
			 if (instance) if (instance!=null) if (instance!=''){
				 thisinstanceframe = getInstanceFrame(instance);
				 if (thisinstanceframe){
					if (window.top.document.getElementById('glue_instance_'+instance))
						window.top.document.getElementById('glue_instance_'+instance).style.visibility='hidden';
					if (window.top.document.getElementById('glueloadingwindowinstance_'+instance))
						window.top.document.getElementById('glueloadingwindowinstance_'+instance).style.display='';
					 thisinstanceframe.location.reload();
				 }
			 }
		 }
