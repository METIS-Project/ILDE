	function getI18NMessages(idMessage){
		// try to get the message
		try{
			// Set language to defaultGlueUserLanguage, if it's not exists set it to default language 'en'/english
			if(defaultGlueUserLanguage && defaultGlueUserLanguage!=null && defaultGlueUserLanguage!=""){
				lang = defaultGlueUserLanguage;
			}else{
				lang ='en';
			}
			// Obtain de message from the langage array
			if (languagearray && languagearray!=null && languagearray.length<1 &&
					languagearray[lang] && languagearray[lang]!=null && languagearray[lang].length<1 &&
						languagearray[lang][idMessage] && languagearray[lang][idMessage]!=null && languagearray[lang][idMessage]!="") {
				return languagearray[lang][idMessage];
			} else{
				return idMessage;
			}
		}catch (err){
			// any case of exception return the idMessage.
			return idMessage;
		}
		
	}