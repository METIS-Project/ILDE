document.write("<script language='JavaScript' type='text/JavaScript' src='./extensions/MediaWikiVLEGlueExtension/javascripts/I18NGlueLib.js'></script>");


function GlueletManagerClient(url){
	
	this.glueletManagerUrl = url;
	this.http = createRequestObject();
	
	
	this.doDeleteInstance = function doDeleteInstance(resourceURL){
		try{
			
			//this.doCall('DELETE', url+resourceURL, 'doDeleteInstance');
			/*
			xmlhttp=new XMLHttpRequest(); 
			alert(url+resourceURL);
			xmlhttp.open("DELETE",url+resourceURL,true) 
			xmlhttp.send(null);
			*/
			
			var result = null;
			result = new XMLHttpRequest();
				result.overrideMimeType('application/xml');
			if (window.XMLHttpRequest) {
				// FireFox, Safari, etc.
				result = new XMLHttpRequest();
				result.overrideMimeType('application/xml');
				//if (typeof result.overrideMimeType != 'undefined') {
				//	result.overrideMimeType('text/xml'); // Or anything else
				//}
			}
			else if (window.ActiveXObject) {
				// MSIE
				result = new ActiveXObject("Microsoft.XMLHTTP");
			} 
			else {
				// No known mechanism -- consider aborting the application
			}
			result.open("DELETE",url+resourceURL,true) 
			result.send();



			
		} catch (error){
			alert(error.description);
		}
	}
	
	function createRequestObject() {
		
		try{
			var reqObj;
			var browser = navigator.appName;
			
			if(browser == "Microsoft Internet Explorer"){
				alert('internet explorer');
				reqObj = new ActiveXObject("Microsoft.XMLHTTP");
			}else{
				reqObj = new XMLHttpRequest();
			}
			
			return reqObj;
			
		}catch (error){	
		}
		try{
			return new ActiveXObject("Msxml2.XMLHTTP");
		}catch (error){
			throw new Error(getI18NMessages('createhttpobjecterror'));	
		}
	}
	
	this.doCall = function doCall(callType, whereTo, functionName){
		alert(whereTo);
		alert(callType);
		this.http.open(callType, whereTo, true);
		// DO WE HAVE A FUNCTION TO CALL ONCE CALL IS COMPLETED?
		this.http.onreadystatechange = processCall(this.http);
		// SEND CALL
		this.http.send(null);

		return this.http.responseText;
	}
	
	function processCall(requester){
		alert(requester.readyState);
		if (requester.readyState == 4)
			if (requester.status == 200){
				//sucess
				alert(requester.responseText.length);
				alert(requester.status);
				alert(requester.statusText);
			} else{
				//failure
				throw new Error( 'Error('+requester.status+') - ' + functionName +'. '+requester.statusText );
			}
	}

}


	