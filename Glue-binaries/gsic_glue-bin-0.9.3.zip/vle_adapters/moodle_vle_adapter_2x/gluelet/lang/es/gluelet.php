<?php

/**
  This file is part of MoodleVLEAdapter.
  
  MoodleVLEAdapter is a property of the Intelligent & Cooperative Systems 
  Research Group (GSIC) from the University of Valladolid (UVA). 
  
  Copyright 2011 GSIC (UVA).

  MoodleVLEAdapter is licensed under the GNU General Public License (GPL) 
  EXCLUSIVELY FOR NON-COMMERCIAL USES. Please, note this is an additional 
  restriction to the terms of GPL that must be kept in any redistribution of
  the original code or any derivative work by third parties.

  If you intend to use MoodleVLEAdapter for any commercial purpose you can 
  contact to GSIC to obtain a commercial license at <glue@gsic.tel.uva.es>.

  If you have licensed this product under a commercial license from GSIC,
  please see the file LICENSE.txt included.

  The next copying permission statement (between square brackets []) is 
  applicable only when GPL is suitable, this is, when MoodleVLEAdapter is 
  used and/or distributed FOR NON COMMERCIAL USES.
  
  [ You can redistribute MoodleVLEAdapter and/or modify it under the 
    terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
  ]
*/

defined('MOODLE_INTERNAL') || die();

$string['gluelet'] = 'gluelet';

$string['modulename'] = 'GLUElet';
$string['modulenameplural'] = 'GLUElets';
$string['modulename_help'] = 'Usa el m&oacute;dulo gluelet para la integraci&oacute;n de herramientas externas de GLUE! en Moodle';

$string['pluginadministration'] = 'Administraci&oacute;n de Gluelet';
$string['pluginname'] = 'Gluelet';

/// error messages
$string['wrong_cmid_em'] = 'El identificador de modulo de curso no es correcto (cmid)';
$string['misconfigured_course_em'] = 'Error de configuraci&ocaute;n en el curso';
$string['wrong_cm_em'] = 'El modulo de curso no es correcto';
$string['cmid_or_instanceid_em'] = 'Debe especificarse un identificador de modulo de curso o un identificador de instancia de actividad';
$string['get_configuration_failed_em'] = 'No pudo obtenerse el formulario de configuraci&oacute;n';
$string['gluelet_creation_failed_em'] = 'Creacion de GLUElet fallida';
$string['gluelet_creation_some_failed_em'] = 'Creaci&oacute;n de m&uacute;ltiples GLUElets parcialmente fallida; algunos no se pudieron crear';
$string['gluelet_creation_all_failed_em'] = 'Creaci&oacute;n de m&uacute;ltiples GLUElets totalmente fallida; ning&uacute;n GLUElet se cre&oacute;';
$string['gluelet_reuse_all_failed_em'] = 'Reutitilizaci&oacute;n de m&uacute;ltiples GLUElets fallida; no se reutiliz&oacute; el GLUElet con ninguno de los grupos restantes';
$string['gluelet_access_failed_em'] = 'Acceso fallido a la instancia GLUElet';
$string['gluelet_multiple_access_failed_em'] = 'Acceso fallido a las instancias GLUElet';
$string['post_users_list_failed_em'] = 'Modificaci&oacte;n de lista de usuarios fallida';
$string['wrong_course_em'] = 'El identificador de curso no es correcto';
$string['get_tools_failed_em'] = 'No pudo obtenerse la lista de herramientas';
$string['gluelet_removal_failed_em'] = 'No pudo eliminarse la instancia GLUElet';
$string['anyURI_unavailable_yet_em'] = 'Formulario de configuraci&oacute;n incorrecto: el tipo anyURI no esta disponible aun para la subida de ficheros XFoms';
$string['invalid_type_for_XForms_upload_em'] = 'Formulario de configuraci&oacute;n incorrecto: tipo de datos no valido para la subida de ficheros XForms';
$string['unknown_error_em'] = 'Algo ha ido mal';

$string['timeout_em'] = 'Se ha superado el tiempo de espera m&aacute;ximo para la petici&oacute;n';
$string['not_found_em'] = 'No se encontr&oacute; el recurso solicitado';
$string['not_connected'] = 'No se pudo establecer conexi&oacute;n con GLUEletManager';
$string['curl_error_em'] = 'Error de comunicaci&oacute;n con GLUEletManager';
$string['server_error_em'] = 'GLUEletManager respondi&oacute; con un error de servicio <br /> (reint&eacute;ntelo m&aacute;s tarde)';
$string['client_error_em'] = 'Petici&oacute;n incorrecta <br /> (contacte con el administrador de su sistema)';
$string['unexpected_answer_em'] = 'Respuesta inesperada de GLUEletManager';
$string['unknown_answer_em'] = 'Respuesta incorrecta de GLUEletManager';

$string['empty_tools_list_em'] = 'Lista de herramientas vac&iacute;a o incomprensible';

/// notice messages
$string['forbidden_any_group'] =  'No tiene permiso para acceder al GLUElet de ningun grupo';
$string['forbidden_current_group'] = 'No tiene permiso para acceder al GLUElet correspondiente a este grupo';
$string['no_activity_instances'] = 'No hay instancias de la actividad gluelet';

/// create / update form strings
$string['glueletfieldset'] = 'Ajustes de GLUElet';
$string['glueletintro'] = 'Introducci&oacute;n';
$string['glueletname'] = 'Nombre';
$string['gluelet_help'] = 'El m&oacute;dulo gluelet permite la integraci&oacute;n de herramientas externas de GLUE! en Moodle';
$string['tool_id_label'] = 'Herramienta';
$string['group_warning_text'] = 'Cambiar el \'Modo de grupo\' de o a \'No hay grupos\' eliminar&aacute; cualquier GLUElet previamente configurado y provocar&aacute; la creaci&oacute;n de otros nuevos';
$string['grouping_warning_text'] = 'Cambiar el valor de \'Agrupamiento\' eliminar&aacute; los GLUElets de cualquier grupo descartado por el nuevo valor';
$string['submit_save_and_continue'] = 'Guardar cambios y continuar';

/// view page strings
$string['not_configured_yet'] = 'Este GLUElet no ha sido configurado aun';
$string['view_heading'] = 'GLUElet';
$string['ext_ref_label'] = 'Referencia externa:';

/// configuration form strings
$string['configuration_form_heading'] = 'Configuraci&oacute;n de GLUElet';
$string['groups_header_label'] = 'Grupos';
$string['groups_to_configure_select_label'] = 'Grupos por configurar: ';
$string['groups_already_configured_static_label'] = 'Grupos ya configurados: ';
$string['create_or_reuse_create_option_label'] = 'Crear nuevo GLUElet';
$string['create_or_reuse_reuse_option_label'] = 'Reutilizar GLUElet existente';
$string['create_header_label'] = 'Configure el nuevo GLUElet';
$string['nothing_to_configure_static_text'] = 'No se necesitan datos de configuraci&oacute;n';
$string['reuse_header_label'] = 'Elija el GLUElet a reutilizar';
$string['reusable_activities_label'] = 'GLUElets reutilizables:';
$string['submit_configure'] = 'Aceptar';
$string['submit_configure_group_label'] = 'Aplicar a grupo';
$string['submit_configure_all_label'] = 'Aplicar a todos';

/// administration form strings
$string['settings_server_heading'] = 'Configuraci&oacute;n de acceso a GLUEletManager';
$string['settings_server_name'] = 'Nombre del servidor';
$string['settings_server_name_description'] = 'Nombre (o IP) del servidor donde est&aacute; instalado GLUEletManager';
$string['settings_server_ip'] = 'IP del servidor';
$string['settings_server_ip_description'] = 'Direcci&oacute;n IP del servidor donde est&aacute; instalado GLUEletManager';
$string['settings_server_port'] = 'Puerto del servidor';
$string['settings_server_port_description'] = 'Puerto donde GLUEletManager atiende peticiones';
$string['settings_base_url'] = 'URL base: http://';
$string['settings_base_url_description'] = 'Comienzo de la direcci&oacute;n URL que apunta a GLUEletManager, incluyendo el nombre (o IP) del servidor donde est&aacute; instalado, el puerto en el que atiende peticiones y un prefijo (opcional) de la ruta a cada recurso antes de \'/GLUEletManager/[resource]\'';
$string['settings_timeout'] = 'Tiempo de espera';
$string['settings_timeout_description'] = 'N&uacute;mero m&aacute;ximo de segundos de espera en cada llamada a GLUEletManager';

?>
