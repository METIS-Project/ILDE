<?php

/**
  This file is part of MoodleVLEAdapter.

  MoodleVLEAdapter is a property of the Intelligent & Cooperative Systems
  Research Group (GSIC) from the University of Valladolid (UVA).

  Copyright 2011 GSIC (UVA).

  MoodleVLEAdapter is licensed under the GNU General Public License (GPL)
  EXCLUSIVELY FOR NON-COMMERCIAL USES. Please, note this is an additional
  restriction to the terms of GPL that must be kept in any redistribution of
  the original code or any derivative work by third parties.

  If you intend to use MoodleVLEAdapter for any commercial purpose you can
  contact to GSIC to obtain a commercial license at <glue@gsic.tel.uva.es>.

  If you have licensed this product under a commercial license from GSIC,
  please see the file LICENSE.txt included.

  The next copying permission statement (between square brackets []) is
  applicable only when GPL is suitable, this is, when MoodleVLEAdapter is
  used and/or distributed FOR NON COMMERCIAL USES.

  [ You can redistribute MoodleVLEAdapter and/or modify it under the
    terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
  ]
*/


/**
 * Class gluelet_configuration_form
 *
 * The configuration form to be filled before the creation of any GLUElet instance. Created and managed from edit.php.
 *
 * Standard core Moodle (>1.8) formslib is used. For more info, please visit http://docs.moodle.org/en/Development:lib/formslib.php
 *
 * @author  Javier Hoyos Torio
 * @author  David A. Velasco
 * @version 2012053001
 * @package mod/gluelet
 * @todo    Serious XForms parsing; or maybe not
 */

require_once("$CFG->libdir/formslib.php");

define("CREATE_RADIO_OPTION", 0);
define("REUSE_RADIO_OPTION", 1);

class gluelet_configuration_form extends moodleform {

    ////////////////
    // Attributes //
    ////////////////

    /** Configuration definition loaded as DOM document */
    protected $_xmlDefinition;

    /** XPath evaluator associated to _xmlDefinition */
    protected $_xpathForDefinition;

    /** Filled instance created as DOM document */
    protected /*var*/ $_xmlInstance;

    /** XPath evaluator associated to _xmlInstance */
    protected /*var*/ $_xpathForInstance;
    
    /** Name of the element used to upload a file*/
    protected $_element_name;
    
    /**
     */
    public $_files;



    ////////////////////
    // Public methods //
    ////////////////////

    /**
     * Configuration form specific set up. Abstract method overriden from moodleform inheritance.
     *
     * Called from the class constructor as part of form creation.
     *
     * All the data fields must be defined inside, including the optional ones.
     *
     * Custom data passed through the second parameter of class constructor can be found in _customdata inherited attribute.
     *
     * In this case, an XForms definition file saved in _customdata is parsed an UI elements are generated to satisfy its contents.
     *
     * LIMITATION: only <inpyut> and <upload> IU elements are parsed.
     */
    function definition() {

        global $CFG;
        $mform =& $this->_form;
        $reusable = false;
        $this->_files = array();
        //$systemcontext = get_context_instance(CONTEXT_SYSTEM);    // don't delete

        /// prepare XForms processing and check reusability flag ///
        ////////////////////////////////////////////////////////////
        //if (strlen($this->_customdata['cfg']) != 0) {       // be carefull!; a tool without configuration form could need a configuration_form object if reusable GLUElets exist!! ; in this case, _customdata['cfg'] == ""
            /// load XForms definition
            $this->_xmlDefinition = new DOMDocument();
            $this->_xmlDefinition->loadXML($this->_customdata['cfg']);

            /// init XPath helper
            $this->_xpathForDefinition = new DOMXPath($this->_xmlDefinition);
            $this->_xpathForDefinition->registerNamespace("xf", "http://www.w3.org/2002/xforms");
            $this->_xpathForDefinition->registerNamespace("h", "http://www.w3.org/1999/xhtml");    // better this way; issues appear when there are namespaces without prefix in the document
            $this->_xpathForDefinition->registerNamespace("glue", "http://gsic.uva.es/glue");

            /// extract ins:reusable element
            $reusableNodes = $this->_xpathForDefinition->query("//glue:reusable");
            if ($reusableNodes->length > 0) {
                $reusableNode = $reusableNodes->item(0);
                $reusable = ($reusableNode->nodeValue == 'true');
            }

        //}


        /// UI elements for groups support ///
        //////////////////////////////////////

        $groups_to_configure = $this->_customdata['groups_to_configure'];
        if (count($groups_to_configure) > 0) {
            $groups_already_configured = $this->_customdata['groups_already_configured'];
            $groups_to_configure_list = array();
            foreach ($groups_to_configure as $groupid => $group)
                $groups_to_configure_list[$groupid] = $group->name;
            $groups_already_configured_str = '';
            if (count($groups_already_configured) > 0) {
                foreach ($groups_already_configured as $groupid => $group)
                    $groups_already_configured_str .= $group->name . ', ';
                $groups_already_configured_str = substr($groups_already_configured_str, 0, -2);;
            }

            $mform->addElement('header', 'groups_header', get_string('groups_header_label', GLUELET_MOD));
            $mform->addElement('select', 'groups_to_configure_select', get_string('groups_to_configure_select_label', GLUELET_MOD), $groups_to_configure_list);
            $mform->setType('groups_to_configure_select', PARAM_RAW);

            $mform->addElement('static', 'groups_already_configured_static', get_string('groups_already_configured_static_label', GLUELET_MOD), '[' . $groups_already_configured_str . ']');
        }


        /// UI radio buttons for choosing configuration or reuse input ///
        //////////////////////////////////////////////////////////////////

        /// list of reusable gluelet instances
        if ($reusable) {
            $reusable_gluelet_instances = $this->_customdata['reusable_gluelet_instances'];
            $reusable_gluelet_instances_options = array();
            foreach($reusable_gluelet_instances as $instance) {
                $reusable_gluelet_instances_options[$instance->id] = get_string('activity') . ': \'' . $instance->name . '\'';
                if ($instance->group_name)
                    $reusable_gluelet_instances_options[$instance->id] .= ' ; ' . get_string('group') . ': \'' . $instance->group_name . '\'';
            }
            if (count($reusable_gluelet_instances_options) > 0) {
                $radioarray=array();
                $radioarray[] = &MoodleQuickForm::createElement('radio', 'create_or_reuse', '', get_string('create_or_reuse_create_option_label', GLUELET_MOD), CREATE_RADIO_OPTION);
                $radioarray[] = &MoodleQuickForm::createElement('radio', 'create_or_reuse', '', get_string('create_or_reuse_reuse_option_label', GLUELET_MOD), REUSE_RADIO_OPTION);
                $mform->addGroup($radioarray, 'radioar', '', array(' '), false);    // it will be erased in the next 'section' if the Xforms document doesn't include the ins:reusable flag set to true
                $mform->setDefault('create_or_reuse', CREATE_RADIO_OPTION);
                if (count($groups_to_configure) > 0)
                    $mform->closeHeaderBefore('create_or_reuse');
            }
        }


        /// UI elements for configuration input  ///
        ////////////////////////////////////////////

        /// header
        $mform->addElement('header', 'create_header', get_string('create_header_label', GLUELET_MOD));

        /// specific tool fields
        $input_elements_count = 0;
        if (strlen($this->_customdata['cfg']) != 0) {       // be carefull!; a tool without configuration form could need a configuration_form object if reusable GLUElets exist!! ; in this case, _customdata['cfg'] == ""
            /// load XForms definition
            /*$this->_xmlDefinition = new DOMDocument();
            $this->_xmlDefinition->loadXML($this->_customdata['cfg']);

            /// init XPath helper
            $this->_xpathForDefinition = new DOMXPath($this->_xmlDefinition);
            $this->_xpathForDefinition->registerNamespace("xf", "http://www.w3.org/2002/xforms");
            $this->_xpathForDefinition->registerNamespace("h", "http://www.w3.org/1999/xhtml");    // better this way; issues appear when there are namespaces without prefix in the document
            */

            /// parse XForms definition and create UI elements ///

            /// extract XForms elements
            $xformUINodes = $this->_xpathForDefinition->query("//xf:*");

            /// process XForms UI elements
            $upload_exists = false;
            for ($i=0; $i<$xformUINodes->length ; $i++) {
            	$element_names = array();
                $UINode = $xformUINodes->item($i);
                if ($UINode->localName == "input") {            // simple text input element
                    $element_names = $this->processXFormsInput($UINode);
                    $input_elements_count += count($element_names);

                } else if ($UINode->localName == "upload") {    // input element to upload files
                    if (!$upload_exists) {
                        $upload_exists = true;
                    }
                    $element_names = $this->processXFormsUpload($UINode);
                    $input_elements_count += count($element_names);

                } else if ($UINode->localName == "select1") {	//select element
                	$element_names = $this->processXFormsSelect1($UINode);
                	$input_elements_count += count($element_names);
                	
                } else if ($UINode->localName == "select") {	//multi-select element
                	$element_names = $this->processXFormsSelect($UINode);
                	$input_elements_count += count($element_names);
                }// else TODO many other elements for a complete XForms processor
				foreach($element_names as $element_name){
	                if ($reusable && ($UINode->localName == "input" || $UINode->localName == "upload" || $UINode->localName == "select1" || $UINode->localName == "select") &&
	                                count($reusable_gluelet_instances_options) > 0  )
	                    $mform->disabledIf($element_name, 'create_or_reuse', 'eq', REUSE_RADIO_OPTION);
				}
            }

        }
        if ($input_elements_count <= 0)
            $mform->addElement('static', 'nothing_to_configure_static', null, get_string('nothing_to_configure_static_text', GLUELET_MOD));


        /// UI elements for GLUElets reuse support ///
        //////////////////////////////////////////////

        if ($reusable && count($reusable_gluelet_instances_options) > 0) {
            $mform->addElement('header', 'reuse_header', get_string('reuse_header_label', GLUELET_MOD));
            $mform->addElement('select', 'reusable_activities_select', get_string('reusable_activities_label', GLUELET_MOD), $reusable_gluelet_instances_options);
            $mform->setType('reusable_activities_select', PARAM_RAW);

            $mform->disabledIf('reusable_activities_select', 'create_or_reuse', 'eq', CREATE_RADIO_OPTION);

            // TODO ERASE
            /// submit reuse buttons    ///
            /*if (count($groups_to_configure) > 0)
                $this->add_reuse_action_buttons();    // configure one, configure all, cancel
            else
                $this->add_reuse_action_buttons(true, get_string('submit_reuse', GLUELET_MOD), false);   // configure, cancel*/
        }


        /// Submit buttons ///
        //////////////////////

        if (count($groups_to_configure) > 0)
            $this->add_configuration_action_buttons();    // configure one, configure all, cancel
        else
            $this->add_configuration_action_buttons(true, get_string('submit_configure', GLUELET_MOD), false);   // configure, cancel


        /// other elements definitions ///
        //////////////////////////////////

        // data to be received from edit.php and sent back
        $mform->addElement('hidden','cmid');
        $mform->addElement('hidden','a');

        // send again to edit.php to avoid new calls to GLUEletManager if form is cancelled or wrongly filled
        $mform->setType('cfg', PARAM_RAW);
        $mform->addElement('hidden', 'cfg', $this->_customdata['cfg']);

    }


    /**
     * Create an XForms XML response with the data from the filled form.
     *
     * @return  string      Serialized XML containing the XForms instance with the data from the form.
     */
    public function buildXFormsInstance() {

        $this->_xmlInstance = new DOMDocument();
        $instance = $this->getXFormsInstanceDefinition();      // get the XML <instance> node defined in the XForms configuration file
        if ($instance && $child = $instance->firstChild) {
            /// clone <instance> children to the XML response
            while ($child) {
                $this->_xmlInstance->appendChild($this->_xmlInstance->importNode($child, true));
                $child = $child->nextSibling;
            }
            /// initialize a new XPath helper
            $this->_xpathForInstance = new DOMXPath($this->_xmlInstance);
            $this->_xpathForInstance->registerNamespace("xf", "http://www.w3.org/2002/xforms");
            $this->_xpathForInstance->registerNamespace("h", "http://www.w3.org/1999/xhtml");
            $this->_xpathForInstance->registerNamespace("xsi", "http://www.w3.org/2001/XMLSchema-instance");

            /// bind data from filled input controls to XML response
            $filenames_to_save = array();
            $mediatypes_to_save = array();
            $formData = $this->get_data();
            $multi_selects_values = array();  //array where the checked values for each multi-select are stored
            foreach ((array)$formData as $element => $value) {      // 'foreach' through filled input controls
                $xforms_info = $this->decodeXFormsInfo($element);
                $element_tag = $xforms_info[0];
                $attribute_name = $xforms_info[1];
                $path = $xforms_info[2];                            // get the path to the binding node
                if ($element_tag == 'input') {
                    // <input> in original XForm definition
                    $this->bindXFormsText($path, $value);   // just bind the text

                } else if ($element_tag == 'select1') {
                	$this->bindXFormsText($path, $value);   // just bind the value of the selected option
                } else if ($element_tag == 'select') {
                	
                	if ($value != 0){ //If the checkbox value is 0, the checkbox has not been checked
                		$select_name = substr($path, 0, strrpos($path, "/")); //get the multi-select name
                		//add the value checked to the list of checked values for that multi-select
                		$multi_selects_values[$select_name][]=$value;
                	}
                	//$this->bindXFormsText($path, $value);
                } 
                else if ($element_tag == 'upload') {
                    if (!$attribute_name) {
                        // nothing to do now, uploaded contents are processed later

                    } else if ($attribute_name == 'filename') {
                        // original name of an uploaded file; save
                        $filenames_to_save[$path] = $value;

                    } else if ($attribute_name == 'mediatype') {
                        // original name of an uploaded file; save
                        $mediatypes_to_save[$path] = $value;
                    }
                }
            }
            foreach($multi_selects_values as $select_name => $checked_values){
            	//Join the values by ';'
            	$value_string = implode(';', $checked_values);
            	$this->bindXFormsText($select_name, $value_string);
            }

            /// bind uploaded files to XML response
            foreach ($this->_files as $element => $file_info) {
                if ($file_info['originalname'] && $file_info['saved']) {
                    // read the file
                    $file_handle = fopen($file_info['fullpath'], 'r');
                    $content = fread($file_handle, filesize($file_info['fullpath']));
                    fclose($file_handle);

                    // insert in XML response
                    $xforms_info = $this->decodeXFormsInfo($element);
                    $path = $xforms_info[2];    // get the path to the binding node
                    $this->bindXFormsUpload($path, $content, $file_info, $filenames_to_save, $mediatypes_to_save);
                } // TODO fail support
            }

        } // else nothing to do, no instance in the form file or empty instance

        return $this->_xmlInstance;
}



    ///////////////////////
    // Protected methods //
    ///////////////////////

    /**
     * Access to the 'instance' element node in the XForms definition tree
     */
    protected function getXFormsInstanceDefinition() {
        $instances = $this->_xpathForDefinition->query("//xf:model/xf:instance");
        if ($instances->length > 0)
            return $instances->item(0);
        else
            return null;
    }


    /**
     * Reads a XForms 'input' element definition and inserts a proper moodleform input element in the form.
     *
     * LIMITATION: use '@ref' attribute for generating the name of the form element; it doesn't consider 'bind' XForms elements/attributes
     * LIMITATION: XForms label is considered as required
     * LIMITATION: XSD type checks are not considered
     *
     * @param $UINode   DOM node containing the XForms 'input' element
     * @return  array  The element name of the new 'input' elements
     */
    protected function processXFormsInput($UINode) {
    	$element_names = array();
        $mform =& $this->_form;

        // extract data from XForms 'input' element
        $labels = $this->_xpathForDefinition->query("xf:label", $UINode);
        $refs = $this->_xpathForDefinition->query("@ref", $UINode);
        //$element_name = $this->path_2_element($refs->item(0)->value);
        $element_name = $this->encodeXFormsInfo("input", "", $refs->item(0)->value);

        //new text element in form
        $mform->addElement('text', $element_name, $labels->item(0)->textContent);
        $default = $this->_xpathForDefinition->query("//xf:instance".$refs->item(0)->value)->item(0)->textContent;
        $mform->setDefault($element_name, $default);
        $mform->setType($element_name, PARAM_TEXT);
        $element_names[]=$element_name;
        return $element_names;
    }


    /**
     * Reads a XForms 'upload' element definition and inserts a proper moodleform upload element in the form.
     *
     * LIMITATION: use '@ref' attribute for generating the name of the form element; it doesn't consider 'bind' XForms elements/attributes
     * LIMITATION: XForms label is considered as required
     *
     * @param $UINode   DOM node containing the XForms 'upload' element
     *
     * @return  array  Name of the new upload elements
     */
    protected function processXFormsUpload($UINode) {
    	$element_names = array();
        $mform =& $this->_form;

        // extract data from XForms 'upload' element
        $labels = $this->_xpathForDefinition->query("xf:label", $UINode);
        $refs = $this->_xpathForDefinition->query("@ref", $UINode);
        //$element_name = $this->path_2_element($refs->item(0)->value);

        // new upload element in form
        $element_name = $this->encodeXFormsInfo("upload", "", $refs->item(0)->value);
        //$mform->addElement('file', $element_name, $labels->item(0)->textContent);
        $return_element_name = $element_name;
        //
        $this->_element_name = $element_name;
        $mform->addElement('filepicker', $element_name, $labels->item(0)->textContent, null, array('maxbytes' => 1024*1024, 'accepted_types' => '*'));

        // extract XForms 'filename' element; considered as optional
        $filenames = $this->_xpathForDefinition->query("xf:filename", $UINode);
        if ($filenames->length > 0) {
            $element_name = $this->encodeXFormsInfo("upload", "filename", $refs->item(0)->value);
            $filename_refs = $this->_xpathForDefinition->query("@ref", $filenames->item(0));
            $mform->addElement('hidden', $element_name, $filename_refs->item(0)->value);
        }

        // extract XForms 'mediatype' element; considered as optional
        $mediatypes = $this->_xpathForDefinition->query("xf:mediatype", $UINode);
        if ($mediatypes->length > 0) {
            $element_name = $this->encodeXFormsInfo("upload", "mediatype", $refs->item(0)->value);
            $mediatype_refs = $this->_xpathForDefinition->query("@ref", $mediatypes->item(0));
            $mform->addElement('hidden', $element_name, $mediatype_refs->item(0)->value);
        }
        $element_names[]=$return_element_name;
        return $element_names;

    }
    
     /**
     * Reads a XForms 'select1' element definition and inserts a proper moodleform select element in the form.
     *
     * LIMITATION: use '@ref' attribute for generating the name of the form element; it doesn't consider 'bind' XForms elements/attributes
     * LIMITATION: XForms label is considered as required
     *
     * @param $UINode   DOM node containing the XForms 'select1' element
     *
     * @return  array  Name of the new select elements
     */
    protected function processXFormsSelect1($UINode) {
    	$element_names = array();
        $mform =& $this->_form;

        // extract data from XForms 'select1' element
        $labels = $this->_xpathForDefinition->query("xf:label", $UINode);
        $refs = $this->_xpathForDefinition->query("@ref", $UINode);
        //$element_name = $this->path_2_element($refs->item(0)->value);
        $element_name = $this->encodeXFormsInfo("select1", "", $refs->item(0)->value);
        
        $itemNodes = $this->_xpathForDefinition->query("xf:item", $UINode);
        if ($this->_xpathForDefinition->query("//xf:instance".$refs->item(0)->value)->length > 0){
        	$default = $this->_xpathForDefinition->query("//xf:instance".$refs->item(0)->value)->item(0)->textContent;
        }else{
        	$default = null;
        }
        $options = array();
        foreach($itemNodes as $item){
        	$itemLabel = $this->_xpathForDefinition->query("xf:label", $item)->item(0)->textContent;
        	$itemValue = $this->_xpathForDefinition->query("xf:value", $item)->item(0)->textContent;
        	$options[$itemValue]=$itemLabel;
        }

        //new text element in form
        $mform->addElement('select', $element_name, $labels->item(0)->textContent, $options);
        $default = $this->_xpathForDefinition->query("//xf:instance".$refs->item(0)->value)->item(0)->textContent;
        if ($default != null){
        	$mform->setDefault($element_name, $default);
        }
        $mform->setType($element_name, PARAM_RAW);
        $element_names[]=$element_name;
        return $element_names;
    }
    
     /**
     * Reads a XForms 'select' element definition and inserts the necessary checkbox elements in the form (one for each possible value for the multi-select).
     *
     * LIMITATION: use '@ref' attribute for generating the name of the checkbox elements; it doesn't consider 'bind' XForms elements/attributes
     * LIMITATION: XForms label is considered as required
     *
     * @param $UINode   DOM node containing the XForms 'select' element
     *
     * @return  array  Name of the new checkbox elements
     */
    protected function processXFormsSelect($UINode) {
    	$element_names = array();
        $mform =& $this->_form;

        // extract data from XForms 'select' element
        $labels = $this->_xpathForDefinition->query("xf:label", $UINode);
        $refs = $this->_xpathForDefinition->query("@ref", $UINode);
        //$element_name = $this->path_2_element($refs->item(0)->value);
        $element_name = $this->encodeXFormsInfo("select", "", $refs->item(0)->value);
        
        $itemNodes = $this->_xpathForDefinition->query("xf:item", $UINode);
        if ($this->_xpathForDefinition->query("//xf:instance".$refs->item(0)->value)->length > 0){
        	$default = $this->_xpathForDefinition->query("//xf:instance".$refs->item(0)->value)->item(0)->textContent;
        	$checked_values = explode(';', $default);
        }else{
        	$default = null;
        }
        $mform->addElement('static', $element_name, $labels->item(0)->textContent);
        foreach($itemNodes as $item){
        	$itemLabel = $this->_xpathForDefinition->query("xf:label", $item)->item(0)->textContent;
        	$itemValue = $this->_xpathForDefinition->query("xf:value", $item)->item(0)->textContent;
        	
        	$mform->addElement('advcheckbox', $element_name."_".$itemValue, '', " ".$itemLabel, null, array(0,$itemValue));
        	
        	if ($default != null){
        		for ($i=0; $i < count($checked_values); $i++){
        			if (strcmp($checked_values[$i],$itemValue)==0){
        				$mform->setDefault($element_name."_".$itemValue, $itemValue);
        			}
        		}
        	}
        	
        	$element_names[] = $element_name."_".$itemValue;
        	
        }

        return $element_names;
    }


    /**
     * Generates a name suitable for a moodleform UI element using data from an XForms input element.
     *
     * @param   string  $element    XForms element tag.
     * @param   string  $attribute  XForms attribute name.
     * @param   string  $path       XPath binding path.
     * @return  string              Name for a moodleform input control.
     */
    protected function encodeXFormsInfo($element, $attribute, $path) {
        return $element . "_" . $attribute . "_" . str_replace("/", "_", $path);
    }


    /**
     * Generates the original XForms element data corresponding to a moodleform input control from its name.
     *
     * @param   string              $element_name   Element name to convert
     * @return  array of strings                    Element tag, name value and binding path of the original XForms element; fields are null when appropiate.
     */
    protected function decodeXFormsInfo($element_name) {
        $result = array(0 => null, 1 => null, 2 => null);
        $pos_0 = strpos($element_name, '_');
        if ($pos_0 !== FALSE) {
            $pos_1 = strpos($element_name, '_', $pos_0 + 1);
            if ($pos_1 !== FALSE) {
                $result[0] = substr($element_name, 0, $pos_0);
                if ($pos_1 - $pos_0 > 1) {
                    $result[1] = substr($element_name, $pos_0 + 1, $pos_1 - $pos_0 - 1);
                } // else $result[1] stays with null content
                $result[2] = str_replace("_", "/" , substr($element_name, $pos_1 + 1));
            }
        }
        return $result;
    }


    /**
     * Insert a string as the text content of an XML node specified by an XPath path through the filled XForms instance.
     *
     * @param    string      $path           XPath path to the XML node (element or attribute), descendant of <instance>, where the value must be bound.
     * @param    string      $value          String value to be bound.
     * @param    DOMNode     $context        Element, descendant of <instance>, to take as root of $path; if null, <instance> is used.
     * @param    boolean     $eraseChildren  When 'true', children elements of the target node are erased before assigning text content.
     */
    protected function bindXFormsText($path, $value, $context = null, $eraseChildren = false) {
        // search for the binding node
        if ($context)
            $binding_targets = $this->_xpathForInstance->query($path, $context);
        else
            $binding_targets = $this->_xpathForInstance->query($path);

        if ($binding_targets->length > 0) {
            // $path specifies an existing node in <instance> definition; $value will become its contained text
            $target = $binding_targets->item(0);
            $child = $target->firstChild;
            $firstTextChild = null;
            while ($child) {
                $to_remove = null;
                if ($child->nodeType == XML_TEXT_NODE) {
                    if (!$firstTextChild)
                        $firstTextChild = $child;
                    else
                        $to_remove = $child;
                } else if ($eraseChildren && $child->nodeType == XML_ELEMENT_NODE) {
                    $to_remove = $child;
                }
                $child = $child->nextSibling;
                if ($to_remove)
                    $target->removeChild($to_remove);
            }
            if ($firstTextChild)
                $firstTextChild->nodeValue = $value;
            else
                $target->appendChild($this->_xmlInstance->createTextNode($value));

        } else {
            // $path specifies a non-existing node in <instance> definition; this is only valid when the node is an XML attribute
            if ($context && substr($path, 0, 1) == "@") {
                $att = $context->appendChild($this->_xmlInstance->createAttribute(substr($path, 1)));
                $att->nodeValue = $value;
            }
        }
    }


    /**
     * Insert data and metadata from an uploaded file as the text content and attributes of an XML node specified by an XPath path through the filled XForms instance.
     *
     * @param   string      $path               XPath path to the XML node (element or attribute), descendant of <instance>, where the value must be bound.
     * @param   string      $content            String with the file raw content.
     * @param   array       $file_info          Data about upload saved by Moodle code.
     * @param   array       $filenames_to_save  XPath paths to the XML nodes where file names must be inserted.
     * @param   array       $mediatypes_to_save XPath paths to the XML nodes where media types must be inserted.
     */
    protected function bindXFormsUpload($path, $content, $file_info, $filenames_to_save, $mediatypes_to_save) {
        /// encode file content
        $fulltype = $this->get_instance_element_type($path, null);
        strtok($fulltype, ":"); // take off the namespace prefix
        $type = strtok(":");

        if ($type == "hexBinary") {
            $content = bin2hex($content);

        } else if ($type == "base64Binary") {
            $content = base64_encode($content);

        } else if ($type == "anyURI") {
            print_error('anyURI_unavailable_yet_em', GLUELET_MOD);

        } else
            error(get_string('invalid_type_for_XForms_upload_em', GLUELET_MOD) . " ($fulltype)");


        /// bind file content
        $this->bindXFormsText($path, $content, null, true);

        /// bind file metadata
        $contexts = $this->_xpathForInstance->query($path);
        if ($contexts->length > 0) {
            $context = $contexts->item(0);
            // insert filename
            if (isset($filenames_to_save[$path]))
                $this->bindXFormsText($filenames_to_save[$path], $file_info['originalname'], $context);
            // insert mediatype
            if (isset($mediatypes_to_save[$path]))
                $this->bindXFormsText($mediatypes_to_save[$path], $file_info['type'], $context);
        }
    }


    /**
     * Add configuration submit buttons
     *
     * Based on code from moodle/course/moodleform_mod.php
     *
     * @param   bool    $cancel         show cancel button
     * @param   string  $submitlabel    null means default, false means none, string is label text
     * @param   string  $submit2label   null means default, false means none, string is label text
     * @return  void
     */
    function add_configuration_action_buttons($cancel=true, $submitlabel=null, $submit2label=null) {
        if (is_null($submitlabel)) {
            $submitlabel = get_string('submit_configure_group_label', GLUELET_MOD);
        }

        if (is_null($submit2label)) {
            $submit2label = get_string('submit_configure_all_label', GLUELET_MOD);
        }

        $mform =& $this->_form;

        // elements in a row need a group
        $buttonarray = array();

        if ($submitlabel !== false) {
            $buttonarray[] = &$mform->createElement('submit', 'submit_configure_group', $submitlabel);
        }

        if ($submit2label !== false) {
            $buttonarray[] = &$mform->createElement('submit', 'submit_configure_all', $submit2label);
        }

        if ($cancel) {
            $buttonarray[] = &$mform->createElement('cancel');
        }

        $mform->addElement('html', '<br />');
        $mform->addGroup($buttonarray, 'buttonar', '', array(' '), false);
        $mform->setType('buttonar', PARAM_RAW);
        $mform->closeHeaderBefore('buttonar');
    }


    /**
     * Add reuse submit buttons
     *
     * Based on code from moodle/course/moodleform_mod.php
     *
     * @param   bool    $cancel         show cancel button
     * @param   string  $submitlabel    null means default, false means none, string is label text
     * @param   string  $submit2label   null means default, false means none, string is label text
     * @return  void
     */
    function add_reuse_action_buttons($cancel=true, $submitlabel=null, $submit2label=null) {
        if (is_null($submitlabel)) {
            $submitlabel = get_string('submit_reuse_group_label', GLUELET_MOD);
        }

        if (is_null($submit2label)) {
            $submit2label = get_string('submit_reuse_all_label', GLUELET_MOD);
        }

        $mform =& $this->_form;

        // elements in a row need a group
        $buttonarray = array();

        if ($submitlabel !== false) {
            $buttonarray[] = &$mform->createElement('submit', 'submit_reuse_group', $submitlabel);
        }

        if ($submit2label !== false) {
            $buttonarray[] = &$mform->createElement('submit', 'submit_reuse_all', $submit2label);
        }

        if ($cancel) {
            $buttonarray[] = &$mform->createElement('cancel');
        }

        $mform->addElement('html', '<br />');
        $mform->addGroup($buttonarray, 'buttonar2', '', array(' '), false);
        $mform->setType('buttonar2', PARAM_RAW);
        //$mform->closeHeaderBefore('buttonar');
    }


    protected function get_instance_element_type($path, $context) {
        // search for the binding node
        $path .= "/@xsi:type";
        if ($context)
            $binding_targets = $this->_xpathForInstance->query($path, $context);
        else
            $binding_targets = $this->_xpathForInstance->query($path);

        if ($binding_targets->length > 0) {
            $target = $binding_targets->item(0);
            return $target->nodeValue;
        }
        return null;
    }
    
    /**
     * Get the uploaded files from the file area
     */
    public function get_my_files($elname) {
        global $USER;

        if (!$this->is_submitted()) {
            return false;
        }

        $element = $this->_form->getElement($elname);

        if ($element instanceof MoodleQuickForm_filepicker || $element instanceof MoodleQuickForm_filemanager) {
            $values = $this->_form->exportValues($elname);
            if (empty($values[$elname])) {
            	//error or not uploaded file
                return false;
            }
            $draftid = $values[$elname];
            $fs = get_file_storage();
            $context = get_context_instance(CONTEXT_USER, $USER->id);
            if (!$files = $fs->get_area_files($context->id, 'user', 'draft', $draftid, 'id DESC', false)) {
                return null;
            }
            return $files;
        }
        return null;
    }
    
     /**
     * Get the name of the interface element used to upload files
     */
    public function get_element_name(){
    	return $this->_element_name;
    }

}

 ?>

