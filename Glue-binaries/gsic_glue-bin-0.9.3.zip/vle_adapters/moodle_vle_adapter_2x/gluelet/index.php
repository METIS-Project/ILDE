<?php

/**
  This file is part of MoodleVLEAdapter.
  
  MoodleVLEAdapter is a property of the Intelligent & Cooperative Systems 
  Research Group (GSIC) from the University of Valladolid (UVA). 
  
  Copyright 2011 GSIC (UVA).

  MoodleVLEAdapter is licensed under the GNU General Public License (GPL) 
  EXCLUSIVELY FOR NON-COMMERCIAL USES. Please, note this is an additional 
  restriction to the terms of GPL that must be kept in any redistribution of
  the original code or any derivative work by third parties.

  If you intend to use MoodleVLEAdapter for any commercial purpose you can 
  contact to GSIC to obtain a commercial license at <glue@gsic.tel.uva.es>.

  If you have licensed this product under a commercial license from GSIC,
  please see the file LICENSE.txt included.

  The next copying permission statement (between square brackets []) is 
  applicable only when GPL is suitable, this is, when MoodleVLEAdapter is 
  used and/or distributed FOR NON COMMERCIAL USES.
  
  [ You can redistribute MoodleVLEAdapter and/or modify it under the 
    terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
  ]
*/


/**
 * This page lists all the instances of gluelet activities in a particular course
 *
 * @author  Javier Hoyos Torio
 * @author  David A. Velasco 
 * @version 2012053001
 * @package mod/gluelet
 */


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////
    //                                    PRELIMINARS                                                        //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////

    require_once(dirname(dirname(dirname(__FILE__))).'/config.php');
    require_once(dirname(__FILE__).'/lib.php');


    // page parameters processing //
    ////////////////////////////////

    /// course (required)
    $id = required_param('id', PARAM_INT);
    if (! $course = $DB->get_record('course', array('id'=> $id))) {
        error(get_string('wrong_course_em', GLUELET_MOD));
    }


    // security checks and logging //
    /////////////////////////////////

    require_course_login($course);

    add_to_log($course->id, GLUELET_MOD, 'view all', "index.php?id=$course->id", '');




    ///////////////////////////////////////////////////////////////////////////////////////////////////////////
    //                                 WORK: SHOW LIST OF GLUELET ACTIVITIES                                 //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////


    /// print page header

    $strgluelets = get_string('modulenameplural', GLUELET_MOD);
    $strgluelet  = get_string('modulename', GLUELET_MOD);

    $navlinks = array();
    $navlinks[] = array('name' => $strgluelets, 'link' => '', 'type' => 'activity');
    $navigation = build_navigation($navlinks);

    print_header_simple($strgluelets, '', $navigation, '', '', true, '', navmenu($course));


    /// print the list of instances

    if (! $gluelet_activities = get_all_instances_in_course(GLUELET_MOD, $course)) {
        notice(get_string('no_activity_instances', GLUELET_MOD), "../../course/view.php?id=$course->id");
        die;
    }

    $timenow  = time();
    $strname  = get_string('name');
    $strweek  = get_string('week');
    $strtopic = get_string('topic');

    if ($course->format == 'weeks') {
        $table->head  = array ($strweek, $strname);
        $table->align = array ('center', 'left');

    } else if ($course->format == 'topics') {
        $table->head  = array ($strtopic, $strname);
        $table->align = array ('center', 'left', 'left', 'left');

    } else {
        $table->head  = array ($strname);
        $table->align = array ('left', 'left', 'left');
    }

    foreach ($gluelet_activities as $gluelet_activity) {
        if (!$gluelet_activity->visible) {
            // show dimmed if the mod is hidden
            $link = '<a class="dimmed" href="view.php?id='.$gluelet_activity->coursemodule.'">'.format_string($gluelet_activity->name).'</a>';
        } else {
            // show normal if the mod is visible
            $link = '<a href="view.php?id='.$gluelet_activity->coursemodule.'">'.format_string($gluelet_activity->name).'</a>';
        }

        if ($course->format == 'weeks' or $course->format == 'topics') {
            $table->data[] = array ($gluelet_activity->section, $link);
        } else {
            $table->data[] = array ($link);
        }
    }

    print_heading($strgluelets);
    print_table($table);


    /// print page footer
    //print_footer($course);
    echo $OUTPUT->footer($course);

?>
