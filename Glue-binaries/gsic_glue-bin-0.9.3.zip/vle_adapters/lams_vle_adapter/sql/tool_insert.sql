--
--	This file is part of LAMS_VLE_Adapter.
--  
--  LAMS_VLE_Adapter is a property of the Intelligent & Cooperative Systems 
--  Research Group (GSIC) from the University of Valladolid (UVA). 
--  
--  Copyright 2012 GSIC (UVA).
--
--  LAMS_VLE_Adapter is free software. You can redistribute LAMS_VLE_Adapter
--  and/or modify it under the terms of the GNU General Public License 
--  as published by the Free Software Foundation, either version 3 of the 
--  License, or (at your option) any later version.
--  
--  This program is distributed in the hope that it will be useful,
--  but WITHOUT ANY WARRANTY; without even the implied warranty of
--  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--  GNU General Public License for more details.
--
--  You should have received a copy of the GNU General Public License
--  along with this program. If not, see <http://www.gnu.org/licenses/>
-- ;
 
INSERT INTO lams_tool
(tool_signature, service_name, tool_display_name, description, tool_identifier, tool_version, learning_library_id, default_tool_content_id, valid_flag, grouping_support_type_id, supports_run_offline_flag, learner_url, learner_preview_url, learner_progress_url, author_url, monitor_url, define_later_url, export_pfolio_learner_url, export_pfolio_class_url, contribute_url, moderation_url, pedagogical_planner_url, help_url, language_file, create_date_time, modified_date_time, admin_url, supports_outputs)
VALUES
('gsglue10', 'glueletService', 'Gluelet', 'GLUE adapter for LAMS', 'gluelet', '2012053111', NULL, NULL, 0, 2, 1, 'tool/gsglue10/learning/viewGluelet.do?mode=learner', 'tool/gsglue10/learning/viewGluelet.do?mode=author', 'tool/gsglue10/learning/viewGluelet.do?mode=teacher', 'tool/gsglue10/authoring.do', 'tool/gsglue10/monitoring.do', 'tool/gsglue10/defineLater.do', 'tool/gsglue10/exportPortfolio?mode=learner', 'tool/gsglue10/exportPortfolio?mode=teacher', 'tool/gsglue10/contribute.do', 'tool/gsglue10/moderate.do', 'tool/gsglue10/authoring/initPedagogicalPlannerForm.do', 'http://www.gsic.uva.es/glue/', 'org.gsic.lams.tool.gluelet.ApplicationResources', NOW(), NOW(), 'tool/gsglue10/admin/start.do', 0);
