--
--	This file is part of LAMS_VLE_Adapter.
--  
--  LAMS_VLE_Adapter is a property of the Intelligent & Cooperative Systems 
--  Research Group (GSIC) from the University of Valladolid (UVA). 
--  
--  Copyright 2012 GSIC (UVA).
--
--  LAMS_VLE_Adapter is free software. You can redistribute LAMS_VLE_Adapter
--  and/or modify it under the terms of the GNU General Public License 
--  as published by the Free Software Foundation, either version 3 of the 
--  License, or (at your option) any later version.
--  
--  This program is distributed in the hope that it will be useful,
--  but WITHOUT ANY WARRANTY; without even the implied warranty of
--  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--  GNU General Public License for more details.
--
--  You should have received a copy of the GNU General Public License
--  along with this program. If not, see <http://www.gnu.org/licenses/>
-- ;
 
SET FOREIGN_KEY_CHECKS=0;

drop table if exists tl_gsglue10_attachment;
drop table if exists tl_gsglue10_gluelet;
drop table if exists tl_gsglue10_gluelet_user;
drop table if exists tl_gsglue10_gluelet_configuration;
drop table if exists tl_gsglue10_tool_session;

create table tl_gsglue10_attachment (
   uid bigint not null auto_increment,
   file_version_id bigint,
   file_type varchar(255),
   file_name varchar(255),
   file_uuid bigint,
   create_date datetime,
   gluelet_uid bigint,
   primary key (uid)
) TYPE=InnoDB;

create table tl_gsglue10_gluelet (
   uid bigint not null auto_increment,
   create_date datetime,
   update_date datetime,
   create_by bigint,
   title varchar(255),
   allow_anonym smallint,
   run_offline smallint,
   lock_on_finished smallint,
   instructions text,
   online_instructions text,
   offline_instructions text,
   content_in_use smallint,
   define_later smallint,
   content_id bigint unique,
   allow_edit smallint,
   allow_rich_editor smallint,
   allow_upload smallint, 
   reflect_instructions varchar(255),
   reflect_on_activity smallint, 
   mark_release_notify tinyint DEFAULT 0,
   toolId varchar(255),
   toolName varchar(255),
   configurationData LONGTEXT,
   configurationIsNeeded smallint,
   primary key (uid)
)TYPE=InnoDB;

create table tl_gsglue10_gluelet_user (
   uid bigint not null auto_increment,
   user_id bigint,
   last_name varchar(255),
   first_name varchar(255),
   session_id bigint,
   login_name varchar(255),
   session_finished smallint,
   primary key (uid)
)TYPE=InnoDB;

create table tl_gsglue10_gluelet_configuration (
   uid bigint not null auto_increment,
   config_key varchar(30) unique,
   config_value varchar(2048),
   primary key (uid)
)TYPE=InnoDB;

create table tl_gsglue10_tool_session (
   uid bigint not null auto_increment,
   version integer not null,
   session_end_date datetime,
   session_start_date datetime,
   status integer,
   mark_released smallint,
   gluelet_uid bigint,
   session_id bigint,
   session_name varchar(250),
   glueletInstanceUrl varchar(255),
   primary key (uid)
)TYPE=InnoDB;

alter table tl_gsglue10_attachment add index FK_NEW_474638196_389AD9A2131CE31E (gluelet_uid), add constraint FK_NEW_474638196_389AD9A2131CE31E foreign key (gluelet_uid) references tl_gsglue10_gluelet (uid);
alter table tl_gsglue10_gluelet add index FK_NEW_474638196_87917942E42F4351 (create_by), add constraint FK_NEW_474638196_87917942E42F4351 foreign key (create_by) references tl_gsglue10_gluelet_user (uid);
alter table tl_gsglue10_gluelet_user add index FK_NEW_474638196_7B83A4A85F0116B6 (session_id), add constraint FK_NEW_474638196_7B83A4A85F0116B6 foreign key (session_id) references tl_gsglue10_tool_session (uid);
alter table tl_gsglue10_tool_session add index FK_NEW_474638196_5A04D7AE131CE31E (gluelet_uid), add constraint FK_NEW_474638196_5A04D7AE131CE31E foreign key (gluelet_uid) references tl_gsglue10_gluelet (uid);

INSERT INTO tl_gsglue10_gluelet 
(uid, title, instructions, online_instructions, offline_instructions, content_id, allow_anonym, run_offline, lock_on_finished, content_in_use, define_later, allow_edit, allow_rich_editor, allow_upload, reflect_on_activity, configurationIsNeeded) 
VALUES
(1, "Gluelet", "Instructions", null, null, ${default_content_id}, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0);

INSERT INTO tl_gsglue10_gluelet_configuration (config_key, config_value) VALUES ('rootUrlToGlueletManager',	'http://localhost:8185');
INSERT INTO tl_gsglue10_gluelet_configuration (config_key, config_value) VALUES ('timeout', '30');


SET FOREIGN_KEY_CHECKS=1;
