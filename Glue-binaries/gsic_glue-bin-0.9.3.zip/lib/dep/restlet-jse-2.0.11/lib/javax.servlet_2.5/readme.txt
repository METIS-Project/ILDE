-----------------------
Java Servlet Technology
-----------------------

"Java Servlet technology provides Web developers with a simple, consistent 
mechanism for extending the functionality of a Web server and for accessing 
existing business systems. A servlet can almost be thought of as an applet 
that runs on the server side--without a face. Java servlets make many Web 
applications possible."

For more information:
http://java.sun.com/products/servlet/