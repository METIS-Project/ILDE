<?php

/**
  This file is part of MoodleVLEAdapter.
  
  MoodleVLEAdapter is a property of the Intelligent & Cooperative Systems 
  Research Group (GSIC) from the University of Valladolid (UVA). 
  
  Copyright 2011 GSIC (UVA).

  MoodleVLEAdapter is licensed under the GNU General Public License (GPL) 
  EXCLUSIVELY FOR NON-COMMERCIAL USES. Please, note this is an additional 
  restriction to the terms of GPL that must be kept in any redistribution of
  the original code or any derivative work by third parties.

  If you intend to use MoodleVLEAdapter for any commercial purpose you can 
  contact to GSIC to obtain a commercial license at <glue@gsic.tel.uva.es>.

  If you have licensed this product under a commercial license from GSIC,
  please see the file LICENSE.txt included.

  The next copying permission statement (between square brackets []) is 
  applicable only when GPL is suitable, this is, when MoodleVLEAdapter is 
  used and/or distributed FOR NON COMMERCIAL USES.
  
  [ You can redistribute MoodleVLEAdapter and/or modify it under the 
    terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
  ]
*/


/**
 * Library of functions and constants for module gluelet
 *
 * @author  David A. Velasco 
 * @version 2010040900
 * @package mod/gluelet
 */


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////
    //                    CORE FUNCTIONS NEEDED TO INTEGRATE THE MODULE IN MOODLE                            //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////

//require_once($CFG->dirroot.'/lib/grouplib.php');   // for the groups constants

define("GLUELET_MOD", "gluelet");
define("GLUELET_INS", "gluelet_instances");
define("GLUELET_USERS_CHANGES", "gluelet_users_list_changes");
define("GLUELET_USERS_CHANGE_ADD", 0);
define("GLUELET_USERS_CHANGE_DEL", 1);
define("GLUELET_TMPDIR", "temp/gluelet_uploads");

/**
 * Given an object containing all the necessary data,
 * (defined by the form in mod_form.php) this function
 * will create a new instance and return the id number
 * of the new instance.
 *
 * @param   object  $gluelet    An object from the form in mod_form.php
 * @return  int                 The id of the newly inserted gluelet record
 */
function gluelet_add_instance($gluelet) {
    // $gluelet is the $fromform object from modedit.php

    $gluelet->timecreated = time();

    // see set_data at mod_form.php to undestand the parsing of $gluelet->toolselection
    $separator_position = strpos($gluelet->toolselection, "<");
    $gluelet->toolid    = substr($gluelet->toolselection, 0, $separator_position);
    $gluelet->toolname  = substr($gluelet->toolselection, $separator_position + 1);

    return insert_record(GLUELET_MOD, $gluelet);
}


/**
 * Given an object containing all the necessary data,
 * (defined by the form in mod_form.php) this function
 * will update an existing instance with new data.
 *
 * @param   object  $gluelet    An object from the form in mod_form.php
 * @return  boolean             Success/Fail
 */
function gluelet_update_instance($gluelet) {

    global $USER;

    $gluelet->timemodified = time();
    $gluelet->id = $gluelet->instance;

    /// toolid and toolname can't be updated, by now

    /// get activity info to be overwriten when updated (coursemodule object)
    if (! $cm = get_coursemodule_from_id(GLUELET_MOD, $gluelet->coursemodule))
        return get_string('wrong_cmid_em', GLUELET_MOD);    // failed end returning error message
    $course = get_record('course', 'id', $cm->course);

    /// check changes, starting with group mode
    if ($cm->groupmode != NOGROUPS && $gluelet->groupmode != NOGROUPS) {

        // then check grouping; applying selective deletion: only delete GLUElets associated to groups in the old grouping but not in the new one
        $old_groups = groups_get_all_groups($course->id, 0, $cm->groupingid);
        foreach($old_groups as $old_group)
            $old_groupids[] = $old_group->id;
        $new_groups = groups_get_all_groups($course->id, 0, $gluelet->groupingid);
        foreach($new_groups as $new_group)
            $new_groupids[] = $new_group->id;
        $lost_groupids = array_diff($old_groupids, $new_groupids);
        if (count($lost_groupids > 0)) {
            $lost_groupids_list = '(';
            foreach ($lost_groupids as $groupid)
                $lost_groupids_list .= $groupid . ',';
            $lost_groupids_list{strlen($lost_groupids_list)-1} = ')';
            $instances = get_records_select(GLUELET_INS, 'glueletactivity=' . $gluelet->id . ' AND groupid IN ' . $lost_groupids_list);
            foreach ($instances as $key => $instance) {
                $delete_remote_instance_result = gluelet_delete_remote_instance($instance->url);    // GLUElet deletion ; fails are ignored
                delete_records(GLUELET_USERS_CHANGES, 'glueletinstance', $instance->id);            // delete any pending change on the users list, or else deletion in GLUELET_INS will fail
                delete_records(GLUELET_INS, 'id', $instance->id);                                   // delete data in 'gluelet_instances' table corresponding to the deleted actual GLUElet
            }
        }

        // check if visibility for groups is changing
        if ($cm->groupmode != $gluelet->groupmode) {
            /// update the users list for remaining GLUElets
            $instances = get_records_select(GLUELET_INS, 'glueletactivity='. $gluelet->id);
            if (is_array($instances)) {
                foreach ($instances as $instance) {
                    $users = gluelet_get_users($gluelet->coursemodule, $instance->groupid, $gluelet->groupmode);
                    $remote_result = gluelet_post_users_list($instance->url, $USER->username, $users);
                }
            }
        }

    } else if ($cm->groupmode != $gluelet->groupmode && ($cm->groupmode == NOGROUPS || $gluelet->groupmode == NOGROUPS)) {   // condition after '&&' is not necessary because of being in 'else'
        /// delete current GLUElet instance(s)
        $instances = get_records_select(GLUELET_INS, 'glueletactivity=' . $gluelet->id);
        foreach ($instances as $key => $instance) {
            $delete_remote_instance_result = gluelet_delete_remote_instance($instance->url);    // remote request to delete the GLUElet; fails are ignored
            delete_records(GLUELET_USERS_CHANGES, 'glueletinstance', $instance->id);            // delete any pending changes on the users list, or else deletion in GLUELET_INS will fail
            delete_records(GLUELET_INS, 'id', $instance->id);                                   // delete data in 'gluelet_instances' table corresponding to the deleted actual GLUElet
        }
        /// new GLUElet(s) will be created when redirecting to view.php (next step after edition page)
    }

    /// TODO - what could we make with failures?

    return update_record(GLUELET_MOD, $gluelet);
}


/**
 * Given an ID of an instance of this module,
 * this function will permanently delete the instance
 * and any data that depends on it.
 *
 * @param   int     $id     Id of the module instance
 * @return  boolean         Success/Failure
 */
function gluelet_delete_instance($id) {

    if (! $gluelet_activity = get_record(GLUELET_MOD, 'id', $id)) {
        return false;
    }

    // delete actual GLUElet instance(s)
    $instances_to_delete = get_records_select(GLUELET_INS, 'glueletactivity=' . $gluelet_activity->id);
    $remote_success = true;
    $local_success = true;
    foreach ($instances_to_delete as $instance_to_delete) {
        // check if the GLUElet is being reused by another GLUElet-activity
        //$reused_instances = get_records_select(GLUELET_INS, 'glueletactivity!=' . $gluelet_activity->id . ' AND url=\'' . ($instance_to_delete->url) . '\'');
        $reused_instances = get_records_select(GLUELET_INS, 'url=\'' . ($instance_to_delete->url) . '\'');  // previous condition doesn't work when several groups in the same activity reuse a GLUElet instance
        //add_to_log(0, GLUELET_MOD, "DELETE", "lib.php", 'reused_instances es ' . $reused_instances);
        //if (!$reused_instances) {
        if ((is_array($reused_instances) && count($reused_instances)<=1) || !$reused_instances) {   // !$reused_instances should never happen; at least one ($instance_to_delete) will be always found
            // remote request to delete the GLUElet
            $delete_remote_instance_result = gluelet_delete_remote_instance($instance_to_delete->url);
            $success = $delete_remote_instance_result[0];
            $remote_success = $remote_success && $success;
        } else {
            // when the GLUElet is reused, remote delete is not executed
            $success = true;
        }
        if ($success) {
            // delete any pending change on the users list, or else deletion in GLUELET_INS will fail
            delete_records(GLUELET_USERS_CHANGES, 'glueletinstance', $instance_to_delete->id);
            // delete data in 'gluelet_instances' table corresponding to the deleted actual GLUElet
            if (! delete_records(GLUELET_INS, 'id', $instance_to_delete->id))
                $local_success = false;
        } else $local_success = false;

    }

    $result = ($remote_success && $local_success);

    // delete activity instance record
    if ($result) {
        if (! delete_records(GLUELET_MOD, 'id', $gluelet_activity->id)) {
            $result = false;
        }
    }

    // TODO d000013
    return $result;
}


/**
 * Return a small object with summary information about what a
 * user has done with a given particular instance of this module
 * Used for user activity reports.
 * $return->time = the time they did it
 * $return->info = a short text description
 *
 * @return  null
 * @todo Finish documenting this function
 */
function gluelet_user_outline($course, $user, $mod, $gluelet) {
    return $return;
}


/**
 * Print a detailed representation of what a user has done with
 * a given particular instance of this module, for user activity reports.
 *
 * @return  boolean
 * @todo Finish documenting this function
 */
function gluelet_user_complete($course, $user, $mod, $gluelet) {
    return true;
}


/**
 * Given a course and a time, this module should find recent activity
 * that has occurred in gluelet activities and print it out.
 * Return true if there was output, or false is there was none.
 *
 * @return  boolean
 * @todo Finish documenting this function
 */
function gluelet_print_recent_activity($course, $isteacher, $timestart) {
    return false;  //  True if anything was printed, otherwise false
}


/**
 * Function to be run periodically according to the moodle cron
 * This function searches for things that need to be done, such
 * as sending out mail, toggling flags etc ...
 *
 * @return  boolean
 * @todo Finish documenting this function
 **/
function gluelet_cron () {
    return true;
}


/**
 * Must return an array of user records (all data) who are participants
 * for a given instance of gluelet. Must include every user involved
 * in the instance, independient of his role (student, teacher, admin...)
 * See other modules as example.
 *
 * @param   int     $glueletid  ID of an instance of this module
 * @return  mixed               boolean/array of students
 */
function gluelet_get_participants($glueletid) {
    // TODO gluelet_get_participants
    return false;
}


/**
 * This function returns if a scale is being used by one gluelet
 * if it has support for grading and scales. Commented code should be
 * modified if necessary. See forum, glossary or journal modules
 * as reference.
 *
 * @param   int     $glueletid  ID of an instance of this module
 * @return  mixed
 * @todo Finish documenting this function
 */
function gluelet_scale_used($glueletid, $scaleid) {
    // TODO gluelet_scale_used
    $return = false;

    //$rec = get_record("gluelet","id","$glueletid","scale","-$scaleid");
    //
    //if (!empty($rec) && !empty($scaleid)) {
    //    $return = true;
    //}

    return $return;
}


/**
 * Checks if scale is being used by any instance of gluelet.
 * This function was added in 1.9
 *
 * This is used to find out if scale used anywhere
 * @param   int     $scaleid
 * @return  boolean             True if the scale is used by any gluelet
 */
function gluelet_scale_used_anywhere($scaleid) {
    if ($scaleid and record_exists(GLUELET_MOD, 'grade', -$scaleid)) {
        return true;
    } else {
        return false;
    }
}


/**
 * Execute post-install custom actions for the module
 * This function was added in 1.9
 *
 * @return boolean true if success, false on error
 */
function gluelet_install() {
    // TODO gluelet_install()
    return true;
}


/**
 * Execute post-uninstall custom actions for the module
 * This function was added in 1.9
 *
 * @return boolean true if success, false on error
 */
function gluelet_uninstall() {
    // TODO gluelet_uninstall
    return true;
}



    ///////////////////////////////////////////////////////////////////////////////////////////////////////////
    //                              GLUELET MODULE SPECIFIC FUNCTIONS                                        //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////

// TODO move to localib.php

define("GLUELET_HTTP_STATUS_OK", 200);
define("GLUELET_HTTP_STATUS_CREATED", 201);
define("GLUELET_HTTP_STATUS_CLIENT_ERROR", 400);


/**
 * Class to support the reading of Atom+GLUE formatted responses (<entry>)
 */
class formatted_entry {

    ////////////////
    // Attributes //
    ////////////////

    /** Entry loaded as DOM document */
    protected $_entry;

    /** XPath evaluator associated to _entry */
    protected $_xpath;

    ////////////////////
    // Public methods //
    ////////////////////

    /**
     * Constructor
     */
    public function __construct($entry = null) {

        if ($entry) {
            /// load entry in memory
            if (is_string($entry)) {
                $this->_entry = DOMDocument::loadXML($entry);
            } else if (is_object($entry)) {
                $this->_entry = new DOMDocument();
                $this->_entry->appendChild($this->_entry->importNode($entry, true));
            }
        } else {
            /// new entry - just for POST
            $this->_entry = new DOMDocument();
        }

        /// init XPath helper
        if ($this->_entry) {
            $this->_xpath = new DOMXPath($this->_entry);
            $this->_xpath->registerNamespace("atom", "http://www.w3.org/2005/Atom");
            $this->_xpath->registerNamespace("glue", "http://gsic.uva.es/glue/1.0");
        }

        if (!$entry) {
            //$this->_entry->appendChild($this->_entry->createElement("http://www.w3.org/2005/Atom", "entry"));
            $entryNode = $this->_entry->appendChild($this->_entry->createElement("entry"));
            $attrNode = $entryNode->appendChild($this->_entry->createAttribute("xmlns"));
            $attrNode->appendChild($this->_entry->createTextNode("http://www.w3.org/2005/Atom"));
            $attrNode = $entryNode->appendChild($this->_entry->createAttribute("xmlns:glue"));
            $attrNode->appendChild($this->_entry->createTextNode("http://gsic.uva.es/glue/1.0"));
        }
    }


    /**
     * Getter for text content in an Atom-standard simple XML element
     */
    public function getAtomSimpleElement($tag) {
        return $this->getSimpleElement("atom", $tag);
    }


    /**
     * Getter for text content in a GLUE-specific simple XML element
     */
    public function getExtendedSimpleElement($tag) {
        return $this->getSimpleElement("glue", $tag);
    }

    /**
     * Getter for the value of an attribute in an Atom element
     *
     * @param tag   string      Tag of the target element.
     * @param att   string      Name of the target attribute.
     * @return      string      Value of the target attribute.
     */
    public function getAtomAttribute($tag, $att) {
        $targetURLs = $this->_xpath->query("/atom:entry/atom:$tag/@$att");
        if ($targetURLs->length > 0)
            return $targetURLs->item(0)->textContent;
        return null;
    }

    /**
     * Adds a new simple element as child of <entry>
     *
     * @param   $tag            string      Name for the new element.
     * @param   $textContent    string      Text content to set as value of the new element.
     */
    public function addExtendedSimpleElement($tag, $textContent) {
        $entryNode = null;
        $nodes = $this->_xpath->query("//entry");
        for ($i=0; $i<$nodes->length; $i++) {
            $node = $nodes->item($i);
            if ($node->nodeType == XML_ELEMENT_NODE) {
                //$node->appendChild($this->_entry->createElementNS("http://gsic.uva.es/glue/1.0", $tag, $textContent));
                $node->appendChild($this->_entry->createElement("glue:$tag", $textContent));
                break;
            }
        }
    }


    /**
     * Adds a new structured element as child of <entry> cloning the root element of the DOM Document $doc
     *
     * @param   $tag    string      Name for the new element.
     * @param   $doc    string      DOM Document to clone as new child element
     */
    public function addExtendedStructuredElement($tag, $doc) {
        $entryNode = null;
        $nodes = $this->_xpath->query("//entry");
        for ($i=0; $i<$nodes->length; $i++) {
            $node = $nodes->item($i);
            if ($node->nodeType == XML_ELEMENT_NODE) {  // TODO delete, it's unnecesary; XPath query is requiring it!!
                //$newNode = $node->appendChild($this->_entry->createElementNS("http://gsic.uva.es/glue/1.0", $tag));
                $newNode = $node->appendChild($this->_entry->createElement("glue:$tag"));
                $newNode->appendChild($this->_entry->importNode($doc->documentElement, true));
                break;
            }
        }
    }


    /**
     * Add a new structured element as child of <entry>, containing a list of children simple elements
     *
     * @param   $listName   string              Name for the list element.
     * @param   $itemName   string              Name for every child of element $listName
     * @param   $listName   array of string     Array with the text values for every simple child element
     */
    public function addExtendedStructuredList($listName, $itemName, $items) {
        $entryNode = null;
        $nodes = $this->_xpath->query("//entry");
        for ($i=0; $i<$nodes->length; $i++) {
            $node = $nodes->item($i);
            if ($node->nodeType == XML_ELEMENT_NODE) {  // TODO delete, it's unnecesary; XPath query is requiring it!!
                $listNode = $node->appendChild($this->_entry->createElement("glue:$listName"));
                foreach ($items as $key => $value)
                    $itemNode = $listNode->appendChild($this->_entry->createElement("glue:$itemName", $value));
                break;
            }
        }
    }


    /**
     * Getter for an Atom-standard structured XML element
     */
    public function getAtomStructuredElement($tag) {
        $nodes = $this->_xpath->query("//atom:$tag");
        for ($i=0; $i<$nodes->length; $i++) {
            $node = $nodes->item($i);
            if ($node->nodeType == XML_ELEMENT_NODE) {
                return $node;
            }
        }
        return null;
    }


    /**
     * Search the text content of a simple XML element
     */
    protected function getSimpleElement($prefix, $tag) {
        $nodes = $this->_xpath->query("//$prefix:$tag");
        for ($i=0; $i<$nodes->length; $i++) {
            $node = $nodes->item($i);
            if ($node->nodeType == XML_ELEMENT_NODE) {
                return $node->textContent;
            }
        }
        return null;
    }


    /**
     * Dumps the internal XML tree back into a string
     */
     public function saveXML() {
        if ($this->_entry)
            return $this->_entry->saveXML();
        else
            return null;
     }


}

/**
 * Class to support the reading of Atom+GLUE formatted responses (<feed>)
 */
class formatted_feed {

    ////////////////
    // Attributes //
    ////////////////

    /** Feed loaded as DOM document */
    protected $feed;

    /** XPath evaluator associated to _feed */
    protected $_xpath;

    ////////////////////
    // Public methods //
    ////////////////////

    /**
     * Constructor
     */
    public function __construct($entry) {

        /// load XForms definition
        $this->_feed = DOMDocument::loadXML($entry);

        /// init XPath helper
        $this->_xpath = new DOMXPath($this->_feed);
        $this->_xpath->registerNamespace("atom", "http://www.w3.org/2005/Atom");
        $this->_xpath->registerNamespace("glue", "http://gsic.uva.es/glue/1.0");

    }

    /**
     * Getter for text content in an Atom-standard simple XML element
     */
    public function getAtomSimpleElement($tag) {
        return $this->getSimpleElement("atom", $tag);
    }

    /**
     * Getter for text content in a GLUE-specific simple XML element
     */
    public function getExtendedSimpleElement($tag) {
        return $this->getSimpleElement("glue", $tag);
    }

    /**
     * Getter for array of formatted_entry objects
     */
    public function getFormattedEntries() {
        $nodes = $this->_xpath->query("//atom:entry");
        $result = array();
        $j = 0;
        for ($i=0; $i<$nodes->length; $i++) {
            $node = $nodes->item($i);
            if ($node->nodeType == XML_ELEMENT_NODE) {
                $result[$j] = new formatted_entry($node);
                $j++;
            }
        }
        return $result;
    }

    /**
     * Search the text content of a simple XML element
     */
    protected function getSimpleElement($prefix, $tag) {
        $nodes = $this->_xpath->query("//$prefix:$tag");
        for ($i=0; $i<$nodes->length; $i++) {
            $node = $nodes->item($i);
            if ($node->nodeType == XML_ELEMENT_NODE) {
                return $node->textContent;
            }
        }
        return null;
    }

}


/**
 * Call to GLUEletManager in order to get the list of availble tools for creating GLUElets.
 *
 * Method ::18:: at Informe_041b_01_02_09.pdf is called and its answer processed to extract the names and URIs of existing tools.
 *
 * @return array    Associative array with toolids as keys and toolnames as values, or null in case of fail.
 */
function gluelet_get_tools_list() {

    global $CFG;

    // cURL handler creation
    $ch = curl_init();

    // HTTP method
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");

    // URL
    //curl_setopt($ch, CURLOPT_URL, 'http://' . $CFG->{GLUELET_MOD . '_server_name'} . ':' . $CFG->{GLUELET_MOD . '_server_port'} . '/GLUEletManager/tools');
    curl_setopt($ch, CURLOPT_URL, 'http://' . $CFG->{GLUELET_MOD . '_base_url'} . '/GLUEletManager/tools');

    // set the timeout limit
    curl_setopt($ch, CURLOPT_TIMEOUT, $CFG->{GLUELET_MOD . '_timeout'});

    // set the handler for delivering answers in strings, instead of being directly printed on page
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);


    // perform the HTTP request
    $out = curl_exec($ch);

    // get answer HTTP code
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    // get cURL error code
    $curl_errno = curl_errno($ch);

    // extract tools list from Atom response
    $result = array(0 => false, 1 => null);
    $tools = null;
    $nice_http_code = false;
    $details = null;
    if (!$curl_errno && $status == GLUELET_HTTP_STATUS_OK) {
        $nice_http_code = true;
        $feed = new formatted_feed($out);
        $entries = $feed->getFormattedEntries();
        $i = 0;
        foreach ($entries as $index => $entry) {
            $toolid = $entry->getAtomSimpleElement("id");
            $toolid = substr($toolid, strlen('http://' . $CFG->{GLUELET_MOD . '_base_url'} . '/GLUEletManager'));   // save only the final part
            $toolname = $entry->getAtomSimpleElement("title");
            $toolprovider = $entry->getExtendedSimpleElement("toolProvider");
            /* implementation name is ignored ; [G000066]
            $toolimpname = $entry->getExtendedSimpleElement("impName");
            $tools[$toolid] = $toolname . " sobre " . $toolimpname . " dada por " . $toolprovider;
             */
            $tools[$toolid] = $toolname . " ( " . $toolprovider . " )";
        }
        $result[1] = $tools;
        $result[0] = (is_array($result[1]) && count($result[1]) > 0);
        if (!$result[0])
            $details = get_string('empty_tools_list_em', GLUELET_MOD);
    }
    if (!$result[0]) // something failed
        $result[1] = process_error($curl_errno, $status, ($curl_errno ? curl_error($ch) : $out), 'get_tools_list', $nice_http_code, $details);

    // free resources
    curl_close($ch);

    return $result;
}


/**
 * Call to GLUEletManager in order to get the configuration definition file needed to create GLUElet instacnes with a previously selected tool.
 *
 * Method ::25*:: at Informe_041b_01_02_09.pdf is called and its answer processed to extract the XForms configuration file.
 *
 * @param   string  $toolid     Final part of the URL to the tool resource whose configuration wants to be obtained
 * @return  string              XML configuration form, or null in case of fail.
 *
 */
function gluelet_get_configuration($toolid) {

    global $CFG;

    // cURL handler creation
    $ch = curl_init();

    // HTTP method
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");

    // URL
    //curl_setopt($ch, CURLOPT_URL, $toolid . "/configuration");
    curl_setopt($ch, CURLOPT_URL, 'http://' . $CFG->{GLUELET_MOD . '_base_url'} . '/GLUEletManager' . $toolid . '/configuration');

    // set the timeout limit
    curl_setopt($ch, CURLOPT_TIMEOUT, $CFG->{GLUELET_MOD . '_timeout'});

    // set the handler for delivering answers in strings, instead of being directly printed on page
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

    // perform the HTTP request
    $out = curl_exec($ch);

    // get answer HTTP
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    // get cURL error code
    $curl_errno = curl_errno($ch);

    // check status code and return appropiate result
    $result = array(0 => false, 1 => null);
    $nice_http_code = false;
    if (!$curl_errno && $status == GLUELET_HTTP_STATUS_OK) {
        $nice_http_code = true;
        $entry = new formatted_entry($out);
        $content =  $entry->getAtomStructuredElement("content");
        if ($content) {
            if (is_object($content->firstChild)) {
                // configuration form exists - extract from the entry
                $contentDOM = new DOMDocument();
                $contentDOM->appendChild($contentDOM->importNode($content->firstChild, true));  // importing before saving to avoid problems with namespace definitions (necessary!!)
                $result[1] = $contentDOM->saveXML($contentDOM->documentElement);
            } else
                // configuration form is not needed; GET CONF results in OK, but the 'content' element is empty (empty string, not null)
                $result[1] = $entry->getAtomSimpleElement("content");
            $result[0] = (is_string($result[1]));
        }
    }

    if (!$result[0]) // something failed
        $result[1] = process_error($curl_errno, $status, ($curl_errno ? curl_error($ch) : $out), 'get_configuration', $nice_http_code, null);

    // free resources
    curl_close($ch);

    return $result;
}


/**
 * Call to GLUEletManager in order to create a new GLUElet instance, with a previously selected tool and full configuration data.
 *
 * Method ::25:: at Informe_041b_01_02_09.pdf is called and its answer processed to extract the URI to the new GLUElet resource.
 *
 * @param   string              $toolId     URL to the tool resource to be used for creation.
 * @param   string              $xmlConf    DOM tree to send as XML with data for the creation of a new gluelet instance.
 * @param   array of string     $users      List of participants in the GLUElet
 * @return  string                          URL to the created GLUElet resource, or null in case of fail.
 */
function gluelet_post_new_instance($toolId, $xmlConf, $users) {
    global $USER, $CFG;

    // cURL handler creation
    $ch = curl_init();

    // build Atom+GLUE formatted set of parameters
    $entry = new formatted_entry();
    $entry->addExtendedSimpleElement("tool", $toolId);
    if ($xmlConf)
        $entry->addExtendedStructuredElement("configuration", $xmlConf);
    else
        $entry->addExtendedSimpleElement("configuration", "");
    //$entry->addExtendedStructuredList("students", "student", $students);
    $entry->addExtendedStructuredList("users", "user", $users);
    $entry->addExtendedSimpleElement("callerUser", $USER->username);  // current user

    // HTTP header; PHP cURL documentation states that it overrides present header, so I call it before all the other curl_setopt
    $headers = array(
        "Content-type: application/xml",
        //"Pragma: no-cache",   // maybe convenient?
        "Content-length: ".strlen($entry->saveXML()),
    );
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    // URL
    //$url =  'http://' . $CFG->{GLUELET_MOD . '_server_name'} . ':' . $CFG->{GLUELET_MOD . '_server_port'} . '/GLUEletManager/instance';
    $url =  'http://' . $CFG->{GLUELET_MOD . '_base_url'} . '/GLUEletManager/instance';
    //$url .= "?tool=" . urlencode($toolId);      // add URL to tool resource as an URL-parameter
    curl_setopt($ch, CURLOPT_URL, $url);

    // set the timeout limit
    curl_setopt($ch, CURLOPT_TIMEOUT, $CFG->{GLUELET_MOD . '_timeout'});

    // HTTP method
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");

    // set the handler for delivering answers in strings, instead of being directly printed on page
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

    // insert the XML as HTTP entity
    curl_setopt($ch, CURLOPT_POSTFIELDS, $entry->saveXML());

    // perform the HTTP request
    $out = curl_exec($ch);

    // get answer HTTP
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    // get cURL error code
    $curl_errno = curl_errno($ch);

    // check status code and return proper result
    $result = array(0 => false, 1 => null);
    $nice_http_code = false;
    if (!$curl_errno && $status == GLUELET_HTTP_STATUS_CREATED) {
        $nice_http_code = true;
        $entry = new formatted_entry($out);
        $id =  $entry->getAtomSimpleElement("id");
        $id = substr($id, strlen('http://' . $CFG->{GLUELET_MOD . '_base_url'} . '/GLUEletManager'));   // save only the final part
        $result[1] = $id;
        $result[0] = (is_string($result[1]) && strlen($result[1]) > 0);
    }
    if (!$result[0])
        $result[1] = process_error($curl_errno, $status, ($curl_errno ? curl_error($ch) : $out), 'post_instance', $nice_http_code, null);

    // free resources
    curl_close($ch);

    return $result;
}


/**
 * Call to GLUEletManager in order to obtain the URL to an actual GLUElet instance, known the URL to the GLUElet resource.
 *
 * Method ::30:: at Informe_041b_01_02_09.pdf is called and its answer processed to extract the URI to the actual GLUElet instance.
 *
 * @param   string  $resourceURL    Final part of the URL to the gluelet resource at GLUEletManager
 * @return  string                  URL to the actual gluelet instance.
 */
function gluelet_get_instance($resourceURL) {

    global $USER, $CFG;

    // cURL handler creation
    $ch = curl_init();

    // append URL parameters
    $resourceURL .= "?callerUser=" . urlencode($USER->username);      // add username

    // HTTP method
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");

    // URL
    //curl_setopt($ch, CURLOPT_URL, $resourceURL);
    curl_setopt($ch, CURLOPT_URL, 'http://' . $CFG->{GLUELET_MOD . '_base_url'} . '/GLUEletManager' . $resourceURL);

    // set the timeout limit
    curl_setopt($ch, CURLOPT_TIMEOUT, $CFG->{GLUELET_MOD . '_timeout'});

    // set the handler for delivering answers in strings, instead of being directly printed on page
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

    // perform the HTTP request
    $out = curl_exec($ch);

    // get the answer HTTP code
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    // get cURL error code
    $curl_errno = curl_errno($ch);

    // extract URL from Atom response
    $result = array(0 => false, 1 => null);
    $nice_http_code = false;
    if (!$curl_errno && $status == GLUELET_HTTP_STATUS_OK) {
        $nice_http_code = true;
        $response =  new formatted_entry($out);
        //$targetURL = $response->getAtomAttribute("content", "src");
        $result[1] = $response->getAtomAttribute("link", "href");
        $result[0] = (is_string($result[1]) && strlen($result[1]) > 0);
    }
    if (!$result[0]) // something failed
        $result[1] = process_error($curl_errno, $status, ($curl_errno ? curl_error($ch) : $out), 'get_instance', $nice_http_code, null);

    // free resources
    curl_close($ch);

    return $result;
}


/**
 * Check a gluelet activity instance to see if it has already been configured, in such a way that GLUElet instance(s) were created and associated to it.
 *
 * @param   $gluelet        string      Gluelet activity object extracted from 'gluelet' table at Moodle database.
 * @param   $groups_count   int         Number of groups that must have their own GLUElet instace of $gluelet.
 * @return                  boolean     'true' when GLUElet instance(s) has been configured yet, 'false' in other case
 */
function gluelet_is_configured($gluelet, $groups_count) {
    $count = count_records(GLUELET_INS, 'glueletactivity', $gluelet->id);
    return ($count > 0 && $count >= $groups_count);     // weak in groups check
}


/**
 * Returns an array with the usernames of EVERY USER who participate in $course and are members of the group with identifier $groupid.
 *
 * If $groupid is lesser than 0, the array contains all the usernames in $course.
 *
 * This code takes several assumptions that could make it weaker; take it easy, and have a look to [moodle]/user/index.php for more extensive code
 *  1.  A gluelet activity placed in the Moodle front page (it'a a course!!) could possibly induce a fail
 *  2.  No security check is being performed; only a teacher of the $course should use this function!!
 *
 * @param   $course     object              Course info
 * @param   $groupid    int                 Identifier of group
 * @param   $groupmode  int                 Group mode
 * @return              array of string     List of usernames members of the group with identifier $groupid
 *-/
function gluelet_get_users($course, $groupid = -1, $groupmode = NOGROUPS) { // or $group ? {

    global $CFG;

    $context = get_context_instance(CONTEXT_COURSE, $course->id);

    /// select
    $select = 'SELECT DISTINCT u.id, u.username, r.hidden ';

    /// from
    $from   =  "FROM {$CFG->prefix}user u
                JOIN {$CFG->prefix}role_assignments r   ON u.id=r.userid ";

    /// where
    // legacy: we are looking for all users with any role assigned in the context of $course OR HIGHER - davivel: �why HIGHER? �is it really useful for us? �admins? TO QUESTION
    if ($usercontexts = get_parent_contexts($context))
        $listofcontexts = '('.implode(',', $usercontexts).')';
    else
        $listofcontexts = '('.$sitecontext->id.')'; // must be site

    $where  = "WHERE (r.contextid = $context->id OR r.contextid in $listofcontexts)"    // role assigned in course context, or some ancestor of course context
                            . " AND u.deleted = 0"                                           // not deleted users
                            . " AND u.username != 'guest'";                                  // not guests (unnecessary)


    /// completing for groups
    if ($groupmode == SEPARATEGROUPS) {
        if ($groupid > 0) {
            $from  .= " LEFT JOIN {$CFG->prefix}groups_members gm     ON u.id = gm.userid ";
            $where .= " AND (gm.groupid = ". $groupid . " OR r.roleid < 5) " ;  // group is only considered for Students ; Teachers, Admin, ... in the $course context are always selected

        } else if ($groupid == 0) {
            // TODO: those not in a group - do we really want it?
            $from  .= " LEFT JOIN {$CFG->prefix}groups_members gm     ON u.id = gm.userid ";
            $where .= " AND gm.groupid IS NULL";
        }
    }

    /// $sort
    /// Always add r.hidden to sort in order to guarantee hiddens to "win"
    /// in the resolution of duplicates later - MDL-13935
    /// Only exception is frontpage that doesn't have such r.hidden info
    /// because it retrieves ALL users (without role checking) - MDL-14034
    $sort = ' ORDER BY r.hidden DESC';


    /// query execution
    $users_list = get_records_sql($select.$from.$where.$sort);

    /// results selection
    $result = array();
    if ($users_list != null)
        foreach ($users_list as $key => $user)
            $result[$key] = $user->username;

    return $result;
}
*/


/**
 * Returns an array with the usernames of EVERY USER who participate in the GLUElet activity corresponding to the context module
 * with id $cmid.
 *
 * If $groupmode is SEPARATEGROUPS, students are included in the list only when they are in the group with identifier $groupid.
 *
 * $groupid lesser than 0 means 'all groups'.
 *
 * This code takes several assumptions that could make it weaker; take it easy, and have a look to [moodle]/user/index.php for more extensive code
 *  1.  A gluelet activity placed in the Moodle front page (it's a course!!) could possibly induce a fail
 *
 * @param   $cmid       object              Course info
 * @param   $groupid    int                 Identifier of group
 * @param   $groupmode  int                 Group mode
 * @return              array of string     List of usernames
 */
function gluelet_get_users($cmid, $groupid = -1, $groupmode = NOGROUPS) {

    global $CFG;

    //$context = get_context_instance(CONTEXT_COURSE, $course->id);
    $context = get_context_instance(CONTEXT_MODULE, $cmid);

    /// select
    $select = 'SELECT DISTINCT u.id, u.username, r.hidden ';

    /// from
    $from   =  "FROM {$CFG->prefix}user u
                JOIN {$CFG->prefix}role_assignments r   ON u.id=r.userid ";

    /// where
    // legacy: we are looking for all users with any role assigned in the context of $course OR HIGHER - davivel: all the HIGHER? �is it really useful for us? �is enough with course level and chidlren? �admins? TO QUESTION
    if ($usercontexts = get_parent_contexts($context))
        $listofcontexts = '('.implode(',', $usercontexts).')';
    else
        $listofcontexts = '('.$sitecontext->id.')'; // must be site

    $where  = "WHERE (r.contextid = $context->id OR r.contextid in $listofcontexts)"    // role assigned in module context, or some ancestor of module context
                            . " AND u.deleted = 0"                                      // not deleted users
                            . " AND u.username != 'guest'";                             // not guests (unnecessary)

    /// completing for groups
    if ($groupmode == SEPARATEGROUPS) {
        if ($groupid > 0) {
            $from  .= " LEFT JOIN {$CFG->prefix}groups_members gm     ON u.id = gm.userid ";
            $where .= " AND (gm.groupid = ". $groupid . " OR r.roleid < 5) " ;          // group is only considered for Students ; Teachers, Admin, ... in the $course context are always selected

        } else if ($groupid == 0) {
            // TODO: those not in a group - davivel: has this any sense?
            $from  .= " LEFT JOIN {$CFG->prefix}groups_members gm     ON u.id = gm.userid ";
            $where .= " AND gm.groupid IS NULL";
        }
    }

    /// $sort
    /// Always add r.hidden to sort in order to guarantee hiddens to "win"
    /// in the resolution of duplicates later - MDL-13935
    /// Only exception is frontpage that doesn't have such r.hidden info
    /// because it retrieves ALL users (without role checking) - MDL-14034
    $sort = ' ORDER BY r.hidden DESC';


    /// query execution
    $users_list = get_records_sql($select.$from.$where.$sort);

    /// results selection
    $result = array();
    if ($users_list != null)
        foreach ($users_list as $key => $user)
            $result[$key] = $user->username;

    return $result;
}


/**
 * Call to GLUEletManager in order to delete a actual GLUElet instance, known the URL to the GLUElet resource.
 *
 * Method ::32:: at Informe_041b_01_02_09.pdf is called.
 *
 * @param   string  $resourceURL    Final part of the URL to the gluelet resource at GLUEletManager
 * @return  boolean                 Success/Fail
 */
function gluelet_delete_remote_instance($resourceURL) {

    global $CFG;

    // cURL handler creation
    $ch = curl_init();

    // HTTP method
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");

    // URL
    //curl_setopt($ch, CURLOPT_URL, $resourceURL);
    curl_setopt($ch, CURLOPT_URL, 'http://' . $CFG->{GLUELET_MOD . '_base_url'} . '/GLUEletManager' . $resourceURL);

    // set the timeout limit
    curl_setopt($ch, CURLOPT_TIMEOUT, $CFG->{GLUELET_MOD . '_timeout'});

    // set the handler for delivering answers in strings, instead of being directly printed on page
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

    // perform the HTTP request
    $out = curl_exec($ch);

    // get the answer HTTP code
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    // get cURL error code
    $curl_errno = curl_errno($ch);

    // check and process request result
    $result = array(0 => true, 1 => null);
    if ($curl_errno || $status != GLUELET_HTTP_STATUS_OK) {    // something failed
        $result[0] = false;
        $result[1] = process_error($curl_errno, $status, ($curl_errno ? curl_error($ch) : $out), 'delete_instance', false, null);
    }

    // free resources
    curl_close($ch);

    return $result;

}


/**
 * Classify an error found while invoking a GLUEletManager method, and generate a proper error message.
 *
 * @param   integer $curl_errno         Error code returned by cURL aftar the HTTP request
 * @param   integer $status             HTTP status code returned by the GLUEletManager method (obtained through cURL library)
 * @param   string  $result             HTTP output returned by the GLUEletManager method (obtained through cURL library)
 * @param   string  $method             Identifier of the GLUEletManager method failing
 * @param   boolean $nice_http_code     Boolean flag, 'true' when the HTTP status code is one of the expected
 * @param   string  $caller_details     Details for the error message passed from the caller function
 * @return  string                      Error message
 */
function process_error($curl_errno, $status, $result, $method, $nice_http_code, $caller_details) {
    $header = get_string('unknown_error_em', GLUELET_MOD);
    switch ($method) {
        case 'delete_instance':
            $header = get_string('gluelet_removal_failed_em', GLUELET_MOD);
            break;
        case 'get_configuration':
            $header = get_string('get_configuration_failed_em', GLUELET_MOD);
            break;
        case 'get_instance':
            $header = get_string('gluelet_access_failed_em', GLUELET_MOD);
            break;
        case 'get_tools_list':
            $header = get_string('get_tools_failed_em', GLUELET_MOD);
            break;
        case 'post_instance':
            $header = get_string('gluelet_creation_failed_em', GLUELET_MOD);
            break;
        case 'post_users_list':
            $header = get_string('post_users_list_failed_em', GLUELET_MOD);
            break;
    }

    $details = '';
    if ($curl_errno) {
        // cURL error
        if ($curl_errno == CURLE_OPERATION_TIMEOUTED) {
            // timeout
            $details = get_string('timeout_em', GLUELET_MOD);
            //$details = $result;

        } else if ($curl_errno == CURLE_COULDNT_CONNECT) {
            // URL not found
            $details = get_string('not_connected', GLUELET_MOD);
            //$details = $result;

        } else {
            // another error
            $details = get_string('curl_error_em', GLUELET_MOD) . '</p> <p>cURL error #' . $curl_errno . ', \"' . $result . '\"';

        }

    } else if ($status >= 500) {
        // HTTP, server error
        $details = get_string('server_error_em', GLUELET_MOD) . '</p> <p>HTTP ' . $status . ' </p> <p>' . $result;

    } else if ($status >= 400) {
        // HTTP, client error
        $details = get_string('client_error_em', GLUELET_MOD) . '</p> <p>HTTP ' . $status . ' </p> <p>' . $result;

    } else if ($status >= 100 && !$nice_http_code) {
        // HTTP, unexpected redirection, right or informational code
        $details = get_string('unexpected_answer_em', GLUELET_MOD) . '</p> <p>HTTP ' . $status . ' </p> <p>' . $result;

    } else {
        // unexpected situation or unreadable answer
        if ($caller_details != null)
            $details = $caller_details;
        else
            $details = get_string('unknown_answer_em', GLUELET_MOD) . '</p> <p>HTTP ' . $status . ' </p> <p>' . $result;
    }

    $message = '<p>' . $header . '</p> <p>' . $details . '</p>';

    return $message;
}


function gluelet_process_pending_users_changes($cmid, $instance, $groupmode) {

    global $USER;

    $changes = get_records_select(GLUELET_USERS_CHANGES, 'glueletinstance=' . $instance->id);
    if (is_array($changes) && count($changes) > 0) {
        // 1. 'owner' no more ; current user is enough
        $username =  $USER->username;

        // opcion correcta, pero tb fea: guardar el ID del profe creador de la gluelet_activity

        // opcion preciosa que no s� si es factible: obtener el ID del creador a partir de lo que ya se guarda en gluelet_activity
        // --> NO PARECE FACTIBLE

        // 2. get current users list
        $users = gluelet_get_users($cmid, $instance->groupid, $groupmode);

        // 3. add or delete users to build the new users list - ABSOLUTELY UNNECESARY :( ; the users list is updated in the result of gluelet_get_users ;
        //      all in all, the table is adequate; it can prevent unnecessary POSTs when a teacher adds and then removes any member in a group
        /*
        foreach($changes as $key => $change) {
            if ($change->action == GLUELET_USERS_CHANGE_ADD) {
            }
        }
        */

        // 4. POST the new users list
        //$remote_result = gluelet_post_users_list($instance->url, $teacher, $students);    // $users in the same format that in POST INSTANCE
        $remote_result = gluelet_post_users_list($instance->url, $username, $users);

        // 5. check error
        if (!$remote_result[0])
            error($remote_result[1]);

        // 6. delete changes - pending no more
        delete_records_select(GLUELET_USERS_CHANGES, 'glueletinstance=' . $instance->id);
    }
}


function gluelet_post_users_list($resourceURL, $callerUser, $users) {
    global $CFG;

    // cURL handler creation
    $ch = curl_init();

    // build Atom+GLUE formatted set of parameters
    $entry = new formatted_entry();
    //$entry->addExtendedStructuredList("students", "student", $students);
    $entry->addExtendedStructuredList("users", "user", $users);
    $entry->addExtendedSimpleElement("callerUser", $callerUser);

    // HTTP header; PHP cURL documentation states that it overrides present header, so I call it before all the other curl_setopt
    $headers = array(
        "Content-type: application/xml",
        //"Pragma: no-cache",   // maybe convenient?
        "Content-length: ".strlen($entry->saveXML()),
    );
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    // URL
    curl_setopt($ch, CURLOPT_URL, 'http://' . $CFG->{GLUELET_MOD . '_base_url'} . '/GLUEletManager' . $resourceURL);

    // set the timeout limit
    curl_setopt($ch, CURLOPT_TIMEOUT, $CFG->{GLUELET_MOD . '_timeout'});

    // HTTP method
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");

    // set the handler for delivering answers in strings, instead of being directly printed on page
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

    // insert the XML as HTTP entity
    curl_setopt($ch, CURLOPT_POSTFIELDS, $entry->saveXML());

    // perform the HTTP request
    $out = curl_exec($ch);

    // get answer HTTP
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    // get cURL error code
    $curl_errno = curl_errno($ch);

    // check status code and return proper result
    $result = array(0 => false, 1 => null);
    $nice_http_code = false;
    if (!$curl_errno && $status == GLUELET_HTTP_STATUS_OK) {
        $nice_http_code = true;
        $entry = new formatted_entry($out);
        $id =  $entry->getAtomSimpleElement("id");
        $id = substr($id, strlen('http://' . $CFG->{GLUELET_MOD . '_base_url'} . '/GLUEletManager'));
        $result[1] = $id;
        $result[0] = (is_string($result[1]) && strlen($result[1]) > 0);
    }
    if (!$result[0])
        $result[1] = process_error($curl_errno, $status, ($curl_errno ? curl_error($ch) : $out), 'post_users_list', $nice_http_code, null);

    // free resources
    curl_close($ch);

    return $result;
}


/**
 * Find the GLUElet instances that can be reused to create a GLUElet activity from a existing one.
 *
 * @param   int     $activity_id        Identifier of the GLUElet activity that is being configured
 * @param   int     $course_id          Identifier of the course containing the GLUElet activity; the only course where the search will be performed
 * @param   int     $tool_id            Identifier of the tool used to create the GLUElet activity
 * @return  array                       List of objects with data about all the GLUElet instances corresponding to GLUElet activities in course with
 *                                      $course_id and with toolid == $tool_id, except $activity_id
 */
function gluelet_get_reusable_activities($activity_id, $course_id, $tool_id) {
    $result = array();
    $gluelet_activities = get_records_select(   GLUELET_MOD,
                                                'id!=' . $activity_id . ' AND course=' . $course_id . ' AND toolid=\'' . $tool_id . '\'',
                                                '',
                                                'id, name');

    if (is_array($gluelet_activities) && count($gluelet_activities)>0) {
        $activity_ids_list = '(';
        foreach ($gluelet_activities as $gluelet_activity) {

            $activity_ids_list .= $gluelet_activity->id . ',';
        }
        $activity_ids_list{strlen($activity_ids_list)-1} = ')';
        $gluelet_instances = get_records_select(GLUELET_INS, 'glueletactivity IN ' . $activity_ids_list);

        $cached_group_names = array();
        if (is_array($gluelet_instances)) {
            foreach ($gluelet_instances as $gluelet_instance) {
                $dataobject = new StdClass;
                $dataobject->id = $gluelet_instance->id;
                $dataobject->url = $gluelet_instance->url;
                $gluelet_activity = $gluelet_activities[$gluelet_instance->glueletactivity];
                $dataobject->name = $gluelet_activity->name;
                if ($gluelet_instance->groupid > 0) {
                    if (array_key_exists($gluelet_instance->groupid, $cached_group_names))
                        $dataobject->group_name = $cached_group_names[$gluelet_instance->groupid];
                    else {
                        $dataobject->group_name = groups_get_group_name($gluelet_instance->groupid);
                        $cached_group_names[$gluelet_instance->groupid] = $dataobject->group_name;
                    }
                } else
                    $dataobject->group_name = null;
                $result[]= $dataobject;
            }
        }
    }

    return $result;
}



?>
