<?php

/**
  This file is part of MoodleVLEAdapter.
  
  MoodleVLEAdapter is a property of the Intelligent & Cooperative Systems 
  Research Group (GSIC) from the University of Valladolid (UVA). 
  
  Copyright 2011 GSIC (UVA).

  MoodleVLEAdapter is licensed under the GNU General Public License (GPL) 
  EXCLUSIVELY FOR NON-COMMERCIAL USES. Please, note this is an additional 
  restriction to the terms of GPL that must be kept in any redistribution of
  the original code or any derivative work by third parties.

  If you intend to use MoodleVLEAdapter for any commercial purpose you can 
  contact to GSIC to obtain a commercial license at <glue@gsic.tel.uva.es>.

  If you have licensed this product under a commercial license from GSIC,
  please see the file LICENSE.txt included.

  The next copying permission statement (between square brackets []) is 
  applicable only when GPL is suitable, this is, when MoodleVLEAdapter is 
  used and/or distributed FOR NON COMMERCIAL USES.
  
  [ You can redistribute MoodleVLEAdapter and/or modify it under the 
    terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
  ]
*/

$string['gluelet'] = 'gluelet';

$string['modulename'] = 'GLUElet';
$string['modulenameplural'] = 'GLUElets';

/// error messages
$string['wrong_cmid_em'] = 'Course Module ID was incorrect';
$string['misconfigured_course_em'] = 'Course is misconfigured';
$string['wrong_cm_em'] = 'Course module is incorrect';
$string['cmid_or_instanceid_em'] = 'You must specify a course_module ID or an instance ID';
$string['get_configuration_failed_em'] = 'Configuration form not found';
$string['gluelet_creation_failed_em'] = 'GLUElet creation failed';
$string['gluelet_creation_some_failed_em'] = 'Multiple GLUElet creation partially failed; some GLUElets were not created';
$string['gluelet_creation_all_failed_em'] = 'Multiple GLUElet creation failed; none GLUElet was created';
$string['gluelet_reuse_all_failed_em'] = 'Multiple GLUElet reuse failed; no remaining group reused the GLUElet';
$string['gluelet_access_failed_em'] = 'Failed access to GLUElet instance';
$string['gluelet_multiple_access_failed_em'] = 'Failed access to GLUElet instances';
$string['post_users_list_failed_em'] = 'Modification of users list failed';
$string['wrong_course_em'] = 'Course ID is incorrect';
$string['get_tools_failed_em'] = 'Tools list could not be retrieved';
$string['gluelet_removal_failed_em'] = 'GLUElet instance could not be removed';
$string['anyURI_unavailable_yet_em'] = 'Wrong configuration form: type anyURI is not available yet for XForms upload';
$string['invalid_type_for_XForms_upload_em'] = 'Wrong configuration form: invalid type for XForms upload';
$string['unknown_error_em'] = 'Something is wrong';

$string['timeout_em'] = 'Timeout overpassed';
$string['not_found_em'] = 'The requested resource could not be found';
$string['not_connected'] = 'Connection to GLUEletManager could not be set';
$string['curl_error_em'] = 'Communication error occured while connecting to GLUEletManager';
$string['server_error_em'] = 'GLUEletManager answered with a server error code <br /> Try again later';
$string['client_error_em'] = 'Wrong request <br /> Notice to the system administrator';
$string['unexpected_answer_em'] = 'Unexpected answer from GLUEletManager';
$string['unknown_answer_em'] = 'Wrong answer from GLUEletManager';

$string['empty_tools_list_em'] = 'Tools list is empty or unreadable';

/// notice messages
$string['forbidden_any_group'] =  'You are not allowed to access the GLUElet owned by any group';
$string['forbidden_current_group'] = 'You are not allowed to access the GLUElet owned by this group';
$string['no_activity_instances'] = 'There are no instances of gluelet activity';

/// create / update form strings
$string['glueletfieldset'] = 'Gluelet settings';
$string['glueletintro'] = 'Introduction';
$string['glueletname'] = 'Name';
$string['tool_id_label'] = 'Tool';
$string['group_warning_text'] = 'Changes in \'Group mode\' from or to \'No groups\' value will delete the already configured GLUElets and will trigger the creation of new ones';
$string['grouping_warning_text'] = 'Changes in \'Grouping\' will cause the deletion of GLUElets associated to every group out of the new grouping';
$string['submit_save_and_continue'] = 'Save and continue';

/// view page strings
$string['not_configured_yet'] = 'This GLUElet is not configured yet';
$string['view_heading'] = 'GLUElet';
$string['ext_ref_label'] = 'External reference:';

/// configuration form strings
$string['configuration_form_heading'] = 'GLUElet Configuration';
$string['groups_header_label'] = 'Groups';
$string['groups_to_configure_select_label'] = 'Groups to configure: ';
$string['groups_already_configured_static_label'] = 'Groups already configured: ';
$string['create_or_reuse_create_option_label'] = 'Create new GLUElet';
$string['create_or_reuse_reuse_option_label'] = 'Reuse existing GLUElet';
$string['create_header_label'] = 'Configure new GLUElet';
$string['nothing_to_configure_static_text'] = 'No configuration data are needed';
$string['reuse_header_label'] = 'Chose GLUElet to reuse';
$string['reusable_activities_label'] = 'Reusable GLUElets:';
$string['submit_configure'] = 'Accept';
$string['submit_configure_group_label'] = 'Apply to group';
$string['submit_configure_all_label'] = 'Apply to all';

/// administration form strings
$string['settings_server_heading'] = 'GLUEletManager access settings';
$string['settings_server_name'] = 'Server name';
$string['settings_server_name_description'] = 'The hostname (or IP) of the computer where GLUEletManager is installed';
$string['settings_server_ip'] = 'Server IP';
$string['settings_server_ip_description'] = 'IP address of the computer where GLUEletManager is installed';
$string['settings_server_port'] = 'Server port';
$string['settings_server_port_description'] = 'Port where GLUEletManager is listening for incoming requests';
$string['settings_base_url'] = 'Base URL: http://';
$string['settings_base_url_description'] = 'Beginning of the URL pointing to GLUEletManager, including the hostname (or IP) of the computer where is installed, the port where is listening for incoming requests, and the (optional) prefix in the path to every resource before the mandatory \'/GLUEletManager/[resource]\'';
$string['settings_timeout'] = 'Timeout';
$string['settings_timeout_description'] = 'Maximum number of seconds to wait for a single call to GLUEletManager';

?>
