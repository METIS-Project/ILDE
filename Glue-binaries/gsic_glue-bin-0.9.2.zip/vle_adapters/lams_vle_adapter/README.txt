########################################
# LAMS_VLE_Adapter                     #
# GSIC's VLE Adapter for LAMS          #
# Copyright 2012 GSIC (UVA)            #
########################################


###########
# LICENSE #
###########

LAMS_VLE_Adapter is a property of the Intelligent & Cooperative Systems 
Research Group (GSIC) from the University of Valladolid (UVA). 
  
LAMS_VLE_Adapter is licensed under the terms of the GNU General Public 
License as published by the Free Software Foundation, either version 3 
of the License, or (at your option) any later version. To see the 
details of the GPL, please see the GPL.txt file.

Please, note that some files included in this distribution package are not
part of LAMS_VLE_Adapter. The distribution and use of these files are governed
by their own licenses, that will be detailed in the sections below.

Any file in this package not detailed in the next sections must be considered
as part of LAMS_VLE_Adapter.
 
Other files are included in this package that are not part of 
LAMS_VLE_Adapter. Their licenses are described in the sections below.


##############################
# GSIC's GLUE-COMMON LIBRARY #
##############################

This package contains the file lib/glue-common.jar, containing the utility
library GLUE-Common used by different components in the GLUE! system.

GLUE-Common is a property of the Intelligent & Cooperative Systems 
Research Group (GSIC) from the University of Valladolid (UVA). 
  
GLUE-Common is licensed under the terms of the GNU Lesser General Public 
License as published by the Free Software Foundation, either version 3 
of the License, or (at your option) any later version. To see the 
details of the LGPL, please see the LGPL.txt file.


########################
# THIRD PARTY LICENSES #
########################

This package contains some third party libraries provided to make easier the
installation and configuration process. All the third party software included
is redistributed in binary form under the terms and conditions of their 
original licenses. These terms are compatible with the GPL license that 
governs GLUEletManager, for the purposes here intended.

The third party libraries included are:

 * RESTlet, version 2.0.11
   by Noelios Technologies
   under Apache 2 license
   placed at lib/restlet-jse-2.0.11/
   see http://www.restlet.org
   
 * LAMS Tool Deployer from LAMS, version 2.3.5
   by LAMS Foundation
   under GNU General Public license version 2
   placed at deploy/
   see http://www.lamsfoundation.org

The original license documents, copyright notices and other information 
documents are included in the subdirectory containing each third party component.

Only the binary jar files needed to run LAMS_VLE_Adapter have been included.
None of them was modified by GSIC. If you need a full copy of any third party 
library, visit the web site of its authors.
