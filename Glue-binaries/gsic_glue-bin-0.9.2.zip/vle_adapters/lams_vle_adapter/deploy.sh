#!/bin/sh
java -classpath deploy/lams-tool-deploy.jar:deploy/commons-configuration-1.1.jar:deploy/commons-lang-2.0.jar:deploy/commons-collections.jar:deploy/commons-logging.jar:deploy/commons-io-1.0.jar:deploy/commons-dbutils-1.0.jar:deploy/mysql-connector-java-5.0.8-bin.jar:deploy/xstream-1.1.2.jar org.lamsfoundation.lams.tool.deploy.Deploy ./deploy.xml true
