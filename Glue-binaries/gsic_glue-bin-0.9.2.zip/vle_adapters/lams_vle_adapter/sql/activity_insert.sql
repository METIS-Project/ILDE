--
--	This file is part of LAMS_VLE_Adapter.
--  
--  LAMS_VLE_Adapter is a property of the Intelligent & Cooperative Systems 
--  Research Group (GSIC) from the University of Valladolid (UVA). 
--  
--  Copyright 2012 GSIC (UVA).
--
--  LAMS_VLE_Adapter is free software. You can redistribute LAMS_VLE_Adapter
--  and/or modify it under the terms of the GNU General Public License 
--  as published by the Free Software Foundation, either version 3 of the 
--  License, or (at your option) any later version.
--  
--  This program is distributed in the hope that it will be useful,
--  but WITHOUT ANY WARRANTY; without even the implied warranty of
--  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--  GNU General Public License for more details.
--
--  You should have received a copy of the GNU General Public License
--  along with this program. If not, see <http://www.gnu.org/licenses/>
-- ;
 
INSERT INTO lams_learning_activity
(activity_ui_id, description, title, help_text, xcoord, ycoord, parent_activity_id, parent_ui_id, learning_activity_type_id, grouping_support_type_id, apply_grouping_flag, grouping_id, grouping_ui_id, order_id, define_later_flag, learning_design_id, learning_library_id, create_date_time, run_offline_flag, max_number_of_options, min_number_of_options, options_instructions, tool_id, tool_content_id, activity_category_id, gate_activity_level_id, gate_open_flag, gate_start_time_offset, gate_end_time_offset, gate_start_date_time, gate_end_date_time, library_activity_ui_image, create_grouping_id, create_grouping_ui_id, library_activity_id, language_file)
VALUES
(NULL, 'GLUE adapter for LAMS', 'Gluelet', 'Activity providing access to the tools registered in a GLUEletManager server', NULL, NULL, NULL, NULL, 1, 2, 0, NULL, NULL, NULL, 0, NULL, ${learning_library_id}, NOW(), 0, NULL, NULL, NULL, ${tool_id}, NULL, 2, NULL, NULL, NULL, NULL, NULL, NULL, 'tool/gsglue10/images/icon_gluelet.swf', NULL, NULL, NULL, 'org.gsic.lams.tool.gluelet.ApplicationResources');
