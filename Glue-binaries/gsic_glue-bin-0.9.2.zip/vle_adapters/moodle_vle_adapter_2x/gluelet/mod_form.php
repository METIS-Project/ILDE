<?php

/**
  This file is part of MoodleVLEAdapter.
  
  MoodleVLEAdapter is a property of the Intelligent & Cooperative Systems 
  Research Group (GSIC) from the University of Valladolid (UVA). 
  
  Copyright 2011 GSIC (UVA).

  MoodleVLEAdapter is licensed under the GNU General Public License (GPL) 
  EXCLUSIVELY FOR NON-COMMERCIAL USES. Please, note this is an additional 
  restriction to the terms of GPL that must be kept in any redistribution of
  the original code or any derivative work by third parties.

  If you intend to use MoodleVLEAdapter for any commercial purpose you can 
  contact to GSIC to obtain a commercial license at <glue@gsic.tel.uva.es>.

  If you have licensed this product under a commercial license from GSIC,
  please see the file LICENSE.txt included.

  The next copying permission statement (between square brackets []) is 
  applicable only when GPL is suitable, this is, when MoodleVLEAdapter is 
  used and/or distributed FOR NON COMMERCIAL USES.
  
  [ You can redistribute MoodleVLEAdapter and/or modify it under the 
    terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
  ]
*/


/**
 * Class mod_gluelet_mod_form
 *
 * Activity creation form.
 *
 * Standard core Moodle (>1.8) formslib is used. For more info, please visit http://docs.moodle.org/en/Development:lib/formslib.php
 *
 * @author  Javier Hoyos Torio 
 * @author  David A. Velasco
 * @version 2012053001
 * @package mod/gluelet
 */

defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot.'/course/moodleform_mod.php');   // for the ancestor form
require_once(dirname(__FILE__).'/lib.php');


class mod_gluelet_mod_form extends moodleform_mod {

    /**
     * Configuration form specific set up. Abstract method overriden from moodleform inheritance.
     *
     * Called from the class constructor as part of form creation.
     *
     * All the data fields must be defined inside, including the optional ones.
     *
     * Custom data passed through the second parameter of class constructor can be found in _customdata inherited attribute.
     *
     * In this case, an additional selection list is included with the standard creation elements, but it's not initialized here (see set_data(...)).
     */
    function definition() {

        global $COURSE;
        $mform =& $this->_form;

        // fields usual in Moodle activity creations //
        ///////////////////////////////////////////////

        /// 'general' fieldset, where all the common settings are showed
        $mform->addElement('header', 'general', get_string('general', 'form'));

        /// standard 'name' field
        $mform->addElement('text', 'name', get_string('glueletname', GLUELET_MOD), array('size'=>'64'));
        if (!empty($CFG->formatstringstriptags)) {
            $mform->setType('name', PARAM_TEXT);
        } else {
            $mform->setType('name', PARAM_CLEAN);
        }
        //$mform->setType('name', PARAM_TEXT);
        $mform->addRule('name', null, 'required', null, 'client');
        $mform->addRule('name', get_string('maximumchars', '', 255), 'maxlength', 255, 'client');

        /// standard 'introeditor' field to hold the description of the activity instance
        //$mform->addElement('editor', 'introeditor', get_string('glueletintro', GLUELET_MOD));
        //$mform->setType('introeditor', PARAM_RAW);
        //$mform->addRule('introeditor', get_string('required'), 'required', null, 'client');     // non required
        //$mform->setHelpButton('introeditor', array('writing', 'richtext'), false, 'editorhelpbutton');
        $this->add_intro_editor(true, get_string('glueletintro', GLUELET_MOD));


        // gluelet activity fields //
        /////////////////////////////

        /// new fieldset for GLUElet-specific settings
        $mform->addElement('header', 'glueletfieldset', get_string('glueletfieldset', GLUELET_MOD));

        /// selection list for tools
        $mform->addElement('select', 'toolselection', get_string('tool_id_label', GLUELET_MOD), null);   // options will be inserted later, in set_data (see below)
        $mform->setType('toolselection', PARAM_RAW);

        /// read-only field with selected tool
        $mform->addElement('static', 'selectedtool', get_string('tool_id_label', GLUELET_MOD), null);  // value will be inserted later, in set_data (see below)
        $mform->setType('selectedtool', PARAM_TEXT);

        /// hidden elements for info to keep in database
        $mform->addElement('hidden','toolname', 'THIS_VALUE_WAS_NOT_ASSIGNED');
        $mform->addElement('hidden','toolid', 'THIS_VALUE_WAS_NOT_ASSIGNED');


        // warning //
        /////////////
        $groupwarning = array();
        $groupwarning[] =& $mform->createElement('html', '<div style=" background:#FFAAAA;" class="box noticebox noticeboxcontent boxaligncenter "><h4> ' . get_string('group_warning_text', GLUELET_MOD) . '</h4> </div>');
        $mform->addGroup($groupwarning, 'groupwarninggroup', '', ' ', false);
        $mform->closeHeaderBefore('groupwarninggroup');
        $groupingwarning = array();
        $groupingwarning[] =& $mform->createElement('html', '<div style=" background:#FFAAAA;" class="box noticebox noticeboxcontent boxaligncenter "><h4> ' . get_string('grouping_warning_text', GLUELET_MOD) . '</h4> </div>');
        $mform->addGroup($groupingwarning, 'groupingwarninggroup', '', ' ', false);


        // standard elements, common to all modules (groups, visibility, etc...) //
        ///////////////////////////////////////////////////////////////////////////
        /*$features = new stdClass;
        $features->groups = true;               // 'true' by default; but it could be 'falsed'
        $features->groupings = true;            // a grouping id selector will be added
        $features->groupmembersonly = true;     // a check option will be added
        $this->standard_coursemodule_elements($features);
		*/
		$this->standard_coursemodule_elements();

        // standard form buttons //
        ///////////////////////////
        $this->add_action_buttons(true, get_string('submit_save_and_continue', GLUELET_MOD));

    }


    /**
     * Tricky overload.
     *
     * This is a little irregular way of completing the insertion of tools in 'toolselection' element in such a way that GET <tools> call to GLUEletManager
     * is not triggered when the form is cancelled or submitted.
     *
     * By now, we have not found any way to avoid the GET <tools> call when form is rendered again after being wrongly filled and submitted; we can't
     * keep at scope the contents of $tools array without modifying Moodle code. It would be easy to fix if the selection of tools were moved to a
     * subsequent form.
     *
     * Besides, to keep in sight both toolids and toolnames, each pair of toolid + toolname is concatenated in a string and this is inserted in the 'toolselection' element.
     *
     * DANGER: This code is highly dependent of moodle/course/modedit.php; if call to 'set_data' (after form object creation) is removed in that file,
     * then we can be sure that no tool at all will be visible in 'toolselection'; ever.
     *
     * @param mixed     $default_values     object or array of default values
     * @param boolean   $slashed            true if magic quotes applied to data values
     */
    function set_data($default_values, $slashed=false) {

        /// new GLUElet activity - tools are not listed in case of GLUElet update, tool can't be modified
        if (!empty($default_values->add)) {

            if (!$this->is_cancelled() &&
                (!$this->is_submitted() || !$this->is_validated())) // with this condition a full call to $this->get_data() is being avoided
                {
                // get tools from GLUEletManager, ::18::
                $get_tools_result = gluelet_get_tools_list();

                if (!$get_tools_result[0])
                    error($get_tools_result[1]);

                $tools = $get_tools_result[1];

                // insert list in 'toolselection'
                $selectionList = $this->_form->getElement('toolselection'); // class HTML_QuickForm_select
                foreach ($tools as $toolid => $toolname) {
                    //$lalo = $toolid . "<" . $toolname;
                    $selectionList->addOption($toolname, $toolid . "<" . $toolname, null);    // using '<' as separator character because it's not allowed in URLs
                }

            } else if ($this->is_submitted() || $this->is_validated()) {
                // TODO - DIRTY TEMPORAL FIX - list of tools will be really saved in 'memory' in a near future
                $selectionList = $this->_form->getElement('toolselection');
                $values = $this->_form->_submitValues;
                $selectionList->addOption("", $values['toolselection'], null); // possible security leak
            }

            // remove update-specific elements
            $this->_form->removeElement('selectedtool');
            $this->_form->removeElement('groupwarninggroup');
            $this->_form->removeElement('groupingwarninggroup');

        } else {
            /// updating a GLUElet activity

            $selectionStatic = $this->_form->getElement('selectedtool'); // class HTML_QuickForm_static
            $selectionStatic->setText($default_values->toolname);

            $this->_form->removeElement('toolselection');
        }

        parent::set_data($default_values, $slashed);    // we must be polite :)
    }

}

?>
