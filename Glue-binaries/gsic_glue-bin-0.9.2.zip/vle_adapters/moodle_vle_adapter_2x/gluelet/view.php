<?php

/**
  This file is part of MoodleVLEAdapter.
  
  MoodleVLEAdapter is a property of the Intelligent & Cooperative Systems 
  Research Group (GSIC) from the University of Valladolid (UVA). 
  
  Copyright 2011 GSIC (UVA).

  MoodleVLEAdapter is licensed under the GNU General Public License (GPL) 
  EXCLUSIVELY FOR NON-COMMERCIAL USES. Please, note this is an additional 
  restriction to the terms of GPL that must be kept in any redistribution of
  the original code or any derivative work by third parties.

  If you intend to use MoodleVLEAdapter for any commercial purpose you can 
  contact to GSIC to obtain a commercial license at <glue@gsic.tel.uva.es>.

  If you have licensed this product under a commercial license from GSIC,
  please see the file LICENSE.txt included.

  The next copying permission statement (between square brackets []) is 
  applicable only when GPL is suitable, this is, when MoodleVLEAdapter is 
  used and/or distributed FOR NON COMMERCIAL USES.
  
  [ You can redistribute MoodleVLEAdapter and/or modify it under the 
    terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
  ]
*/


/**
 * This page shows the GLUElet instance(s) corresponding to a particular gluelet activity
 *
 * @author  Javier Hoyos Torio 
 * @author  David A. Velasco
 * @version 2012053001
 * @package mod/gluelet
 */


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////
    //                                    PRELIMINARS                                                        //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////

    require_once(dirname(dirname(dirname(__FILE__))).'/config.php');
    require_once(dirname(__FILE__).'/lib.php');


    // page parameters processing //
    ////////////////////////////////

    /// one of 'id' or 'a' must exist
    $id             = optional_param('id', 0, PARAM_INT);               // course_module ID, or
    $a              = optional_param('a', 0, PARAM_INT);                // gluelet instance ID

    /// choose the current group; set by group header selector (never used in code, unnecesary)
    $changegroup    = optional_param('group', -1, PARAM_INT);

    /// recover data about current gluelet activity instance from Moodle database
    if ($id) {
        if (! $cm = get_coursemodule_from_id(GLUELET_MOD, $id)) {
            print_error('wrong_cmid_em', GLUELET_MOD);
        }
        if (! $course = $DB->get_record('course', array('id' => $cm->course))) {
            print_error('misconfigured_course_em', GLUELET_MOD);
        }
        if (! $gluelet_activity = $DB->get_record(GLUELET_MOD, array('id' => $cm->instance))) {
            print_error('wrong_cm_em', GLUELET_MOD);
        }

    } else if ($a) {
        if (! $gluelet_activity = $DB->get_record(GLUELET_MOD, array('id' => $a))) {
            print_error('wrong_cm_em', GLUELET_MOD);
        }
        if (! $course = $DB->get_record('course', array('id' => $gluelet_activity->course))) {
            print_error('misconfigured_course_em', GLUELET_MOD);
        }
        if (! $cm = get_coursemodule_from_instance(GLUELET_MOD, $gluelet_activity->id, $course->id)) {
            print_error('wrong_cmid_em', GLUELET_MOD);
        }

    } else {
        print_error('cmid_or_instanceid_em', GLUELET_MOD);
    }


    // security checks and logging //
    /////////////////////////////////

    // user login check
    require_login($course, true, $cm);
    $context = get_context_instance(CONTEXT_MODULE, $cm->id);   // from quiz/view.php

    // if gluelet has not been configured yet, instance has not been really created; redirect to edit.php to configure
    $groups_count = 1;
    $group_mode = groups_get_activity_groupmode($cm);
    if ($group_mode == SEPARATEGROUPS || $group_mode == VISIBLEGROUPS)
        $groups_count =  count(groups_get_all_groups($course->id, 0, $cm->groupingid));
    $configured = gluelet_is_configured($gluelet_activity, $groups_count);
    if (!$configured && has_capability('moodle/course:manageactivities', $context)) {
        redirect($CFG->wwwroot.'/mod/gluelet/edit.php?cmid=' . $cm->id);
    }

    // from forum/view.php
    if (empty($cm->visible) and !has_capability('moodle/course:viewhiddenactivities', $context)) {
        notice(get_string("activityiscurrentlyhidden"));
    }

    // log message
    if ($id)
        add_to_log($course->id, GLUELET_MOD, "view", "view.php?id=$id", "$gluelet_activity->id");
    else
        add_to_log($course->id, GLUELET_MOD, "view", "view.php?a=$a", "$gluelet_activity->id");




    ///////////////////////////////////////////////////////////////////////////////////////////////////////////
    //                                 WORK: SHOW GLUELET INSTANCE(S)                                        //
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////


    /// print page header
    $strgluelets = get_string('modulenameplural', GLUELET_MOD);
    $strgluelet  = get_string('modulename', GLUELET_MOD);

    $navlinks = array();
    $navlinks[] = array('name' => $strgluelets, 'link' => "index.php?id=$course->id", 'type' => 'activity');
    $navlinks[] = array('name' => format_string($gluelet_activity->name), 'link' => '', 'type' => 'activityinstance');

    $navigation = build_navigation($navlinks);

    print_header_simple(format_string($gluelet_activity->name), '', $navigation, '', '', true, update_module_button($cm->id, $course->id, $strgluelet), navmenu($course, $cm));


    /// print the group header
    groups_print_activity_menu($cm, $CFG->wwwroot . '/mod/gluelet/view.php?id=' . $cm->id);
    echo '<br />';


    /// print the main part of the page

    if (!$configured) {     // student trying to see a not configured gluelet (a teacher would have been redirected previously)
        echo '<h2>' . get_string('not_configured_yet', GLUELET_MOD) . '</h2>';

    } else {                // gluelet has been configured

        // get current info about groups
        $currentgroup = groups_get_activity_group($cm);
        $groupmode = groups_get_activity_groupmode($cm);

        // get the GLUElet instance(s) corresponding to the current group
        if ($currentgroup)
            $instances = $DB->get_records_select(GLUELET_INS, 'glueletactivity=' . $gluelet_activity->id . ' AND groupid=' . $currentgroup);     // if creation was well done, the array contains only ONE GLUElet instance
        else
            $instances = $DB->get_records(GLUELET_INS, array('glueletactivity' => $gluelet_activity->id));     // one instance, or as many as groups, depending upon groupmode


        // check the existance of pending changes about users lists, and process before go on
        foreach ($instances as $key => $instance) {
            gluelet_process_pending_users_changes($cm->id, $instance, $groupmode);   // this method will interrupt the view in case of error, triggering the error page
        }

        // filter instances according to group membership and capabilities
        $instances_to_show = array();
        if (($groupmode == NOGROUPS) || (has_capability('moodle/site:accessallgroups', $context)) ||
            ($groupmode == VISIBLEGROUPS) ) {    // condition added to let students see the GLUElets of other groups when group mode is 'visible', although modification can't be avoided.
            $instances_to_show = $instances;
        } else {
            foreach ($instances as $key => $instance) {
                if (groups_is_member($instance->groupid))
                    $instances_to_show[$key] = $instance;
            }
        }

        // show instances
        $count = count($instances_to_show);
        if ($count <= 0) {
            if ($currentgroup == 0)
                notice(get_string('forbidden_any_group', GLUELET_MOD));
            else
                notice(get_string('forbidden_current_group', GLUELET_MOD));

        } else {
            echo '<h2>';
            echo get_string('view_heading', GLUELET_MOD) . ': ' . $gluelet_activity->toolname;
            echo '</h2>';

            // print gluelet description (based on mod/quiz/view.php)
            if (trim(strip_tags($gluelet_activity->intro))) {
                $formatoptions->noclean = true;
                $formatoptions->para    = false;
                echo $OUTPUT->box(format_text($gluelet_activity->intro, FORMAT_MOODLE, $formatoptions), 'generalbox', 'boxalignleft');
                //print_box(format_text($gluelet_activity->intro, FORMAT_MOODLE, $formatoptions), 'generalbox', 'boxalignleft');
                //print_box(format_text($gluelet_activity->intro, FORMAT_MOODLE, $formatoptions), 'generalbox', 'intro');   // recover to center the box, as 'intro's use to appear in moodle activities
            }

            $failed_gets = array();
            $failed_message = '';
            foreach ($instances_to_show as $key => $instance) {
                $get_instance_result = gluelet_get_instance($instance->url);
                if (!$get_instance_result[0]) {
                    $failed_gets[] = $instance->url;
                    $failed_message = $get_instance_result[1];

                } else {
                    $targetURL = $get_instance_result[1];
                    if ($count > 1)
                        echo ' <h3>' . get_string('group') . ': ' . groups_get_group_name($instance->groupid) . ' </h3>';
                    echo ' <div>';
                    echo    get_string('ext_ref_label', GLUELET_MOD) . ' <a href="' . $targetURL . '"> ' . $targetURL . ' </a>';
                    echo    ' <p />';
                    echo    ' <object height="500px" width="100%" data="' . $targetURL . '">';    // TODO better size
                    echo        ' <param name="idle" value=""/>';     // idle parameter inserted to satisfy some browsers
                    echo    ' </object>';
                    echo    ' </div>';
                }
            }
            $failed_count = count($failed_gets);
            if ($failed_count > 0) {
                if ($failed_count > 1) {
                    $urls_list = ' ';
                    foreach ($failed_gets as $i => $url)
                        $urls_list .= $url . ', ';
                    $urls_list = substr($urls_list, 0, strlen($urls_list) - 2);
                    error(get_string('gluelet_multiple_access_failed_em', GLUELET_MOD) . $urls_list);
                } else
                    //error(get_string('gluelet_access_failed_em', GLUELET_MOD) . ' ' . $failed_gets[0]);
                    error($failed_message);
            }

        }

    }

    /// print page footer
    //print_footer($course);
    echo $OUTPUT->footer($course);

?>
