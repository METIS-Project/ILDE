<?php

/**
  This file is part of MoodleVLEAdapter.
  
  MoodleVLEAdapter is a property of the Intelligent & Cooperative Systems 
  Research Group (GSIC) from the University of Valladolid (UVA). 
  
  Copyright 2011 GSIC (UVA).

  MoodleVLEAdapter is licensed under the GNU General Public License (GPL) 
  EXCLUSIVELY FOR NON-COMMERCIAL USES. Please, note this is an additional 
  restriction to the terms of GPL that must be kept in any redistribution of
  the original code or any derivative work by third parties.

  If you intend to use MoodleVLEAdapter for any commercial purpose you can 
  contact to GSIC to obtain a commercial license at <glue@gsic.tel.uva.es>.

  If you have licensed this product under a commercial license from GSIC,
  please see the file LICENSE.txt included.

  The next copying permission statement (between square brackets []) is 
  applicable only when GPL is suitable, this is, when MoodleVLEAdapter is 
  used and/or distributed FOR NON COMMERCIAL USES.
  
  [ You can redistribute MoodleVLEAdapter and/or modify it under the 
    terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
  ]
*/


/**
 * Library of functions designed to handle interesting Moodle events
 *
 * @author  Javier Hoyos Torio 
 * @author  David A. Velasco
 * @version 2012053001
 * @package mod/gluelet
 */

require_once(dirname(__FILE__).'/lib.php');

////////////////////
/// USERS EVENTS ///
////////////////////

function user_created_handler($eventdata) {
    // full new record from mdl_user
    add_to_log(0, GLUELET_MOD, "event", '', 'USER CREATED event received');
    return true;
}


function user_deleted_handler($eventdata) {
    // record from mdl_user before marked as deleted
    add_to_log(0, GLUELET_MOD, "event", '', 'USER DELETED event received');
    return true;
}


function user_updated_handler($eventdata) {
    // full new record from mdl_user
    add_to_log(0, GLUELET_MOD, "event", '', 'USER UPDATED event received');
    return true;
}


////////////////////
/// ROLES EVENTS ///
////////////////////

function role_assigned_handler($eventdata) {
	global $DB;
    // full new record from mdl_role_assignments table
    add_to_log(0, GLUELET_MOD, "event", '', 'ROLE ASSIGNED event received');

    if ($eventdata->roleid != 7) {      // the only predefined Moodle role that we discard: 'Authenticated user' (not even guest)

        // 1. select GLUElet activities affected by the assignment
        $context = get_context_instance_by_id($eventdata->contextid);
        $activities = get_gluelet_activities_in_context($context);

        // 2. check GLUElet activities where the update is really needed
        if (is_array($activities)) {
            foreach ($activities as $activity) {
                $cm = get_coursemodule_from_instance(GLUELET_MOD, $activity->id, $activity->course);
                $module_context = get_context_instance(CONTEXT_MODULE, $cm->id);
                $roles = get_user_roles($module_context, $eventdata->userid);
                $count_roles = count($roles);
                // 3. update users list if this is the first role in the activity context for the user, and user is 'teacher' or activity groupmode is not SEPARATEGROUPS
                $doit = $count_roles <= 1 && ($eventdata->roleid < 5 || $cm->groupmode != SEPARATEGROUPS);
                // 4. if not first role, check if the user is being assigned a 'teacher' role for first time in the activity context (being group mode SEPARATEGROUPS)
                if ($count_roles > 1 && $eventdata->roleid < 5 && $cm->groupmode == SEPARATEGROUPS) {
                    $teacher_roles_count = 0;
                    foreach ($roles as $role)
                        if ($role->roleid < 5)
                            $teacher_roles_count++;
                    $doit = ($teacher_roles_count <= 1);
                }
                if ($doit) {
                    // 5. new record in the table of pending changes
                    $instances = $DB->get_records_select(GLUELET_INS, 'glueletactivity='. $activity->id);
                    if (is_array($instances)) {
                        foreach ($instances as $instance) {
                            $dataobject = new StdClass;
                            $dataobject->glueletinstance = $instance->id;
                            $dataobject->userid = $eventdata->userid;
                            $dataobject->action = GLUELET_USERS_CHANGE_ADD;
                            $DB->insert_record(GLUELET_USERS_CHANGES, $dataobject);
                        }
                    }
                }
            }
        }
    }
    return true;
}


function role_unassigned_handler($eventdata) {
	global $DB;
    // record from 'role_assignents'; course context only
    add_to_log(0, GLUELET_MOD, "event", '', 'ROLE UNASSIGNED event received');

    if ($eventdata->roleid != 7) {      // the only predefined Moodle role that we discard: 'Authenticated user' (not even guest)

        // 1. select GLUElet activities affected by the assignment
        $context = get_context_instance_by_id($eventdata->contextid);
        $activities = get_gluelet_activities_in_context($context);

        // 2. check GLUElet activities where the update is really needed
        if (is_array($activities)) {
            foreach ($activities as $activity) {
                $cm = get_coursemodule_from_instance(GLUELET_MOD, $activity->id, $activity->course);
                $module_context = get_context_instance(CONTEXT_MODULE, $cm->id);
                $roles = get_user_roles($module_context, $eventdata->userid);
                $count_roles = count($roles);

                // 3. update users list if the unassigned role is the last one in the activity context for the user
                $doit = $count_roles < 1;   // this can be true in some cases where the update is not really necessary
                /* / 3. update users list if the unassigned role is the last one in the activity context for the user, and user is 'teacher' or activity groupmode is not SEPARATEGROUPS
                $doit = count_roles < 1 && ($eventdata->roleid < 5 || $cm->groupmode != SEPARATEGROUPS); */
                // 4. update users list if the unassigned role is not the last one, BUT it is the last 'teacher' role of the user and group mode is SEPARATEGROUPS
                if ($count_roles > 0 && $eventdata->roleid < 5 && $cm->groupmode == SEPARATEGROUPS) {
                    $teacher_roles_count = 0;
                    foreach ($roles as $role)
                        if ($role->roleid < 5)
                            $teacher_roles_count++;
                    $doit = ($teacher_roles_count < 1); // // this can be true in some cases where the update is not really necessary ; membership of the user to any group associated to the activity should be discarded for more precision
                }
                if ($doit) {
                    // 5. new record in the table of pending changes
                    $instances = $DB->get_records_select(GLUELET_INS, 'glueletactivity='. $activity->id);
                    if (is_array($instances)) {
                        foreach ($instances as $instance) {
                            $dataobject = new StdClass;
                            $dataobject->glueletinstance = $instance->id;
                            $dataobject->userid = $eventdata->userid;
                            $dataobject->action = GLUELET_USERS_CHANGE_DEL;
                            $DB->insert_record(GLUELET_USERS_CHANGES, $dataobject);
                        }
                    }
                }
            }
        }
    }
    return true;
}


/**
 * Select GLUElet activities in a Moodle context.
 *
 * Search strategy is different depending on the context level.
 *
 *
 */
function get_gluelet_activities_in_context($context) {

	global $DB;
    $activities = null;

    if (    $context->contextlevel != CONTEXT_BLOCK     // block context never gives access to a GLUElet module context ; see Moodle contexts hierarchy: http://docs.moodle.org/en/Context
        &&  $context->contextlevel != CONTEXT_USER  )   // user context never gives access to a GLUElet module context ; see Moodle contexts hierarchy: http://docs.moodle.org/en/Context
                                                        {

        if ($context->contextlevel == CONTEXT_MODULE) {     // maybe the context of a specific GLUElet activity
            $cm = get_coursemodule_from_id(GLUELET_MOD, $context->instanceid);
            if ($cm){
                $activities = $DB->get_records(GLUELET_MOD, array('id' => $cm->instance));
            }

        } else if ($context->contextlevel == CONTEXT_COURSE) {     // level CONTEXT_COURSE includes front page context; front page is a special course that can't be included in a course category, but it is still a course
            $activities = $DB->get_records(GLUELET_MOD, array('course' => $context->instanceid));
        } else if ($context->contextlevel == CONTEXT_COURSECAT) {  // all the courses children of the category
            $course_list = array();
            $category_contexts_list[] = $context;   // queue of course category contexts; to breadth-first run the category tree
            for ($i=0; i<count($category_contexts_list); $i++) {
                $child_contexts_ids = get_child_contexts($category_contexts_list[i]);
                foreach($child_contexts_ids as $child_context_id) {
                    $child_context = get_context_instance_by_id($child_context_id);
                    if ($child_context->contextlevel == CONTEXT_COURSE) {
                        $course_list[] = $child_context->instanceid;
                    } else if ($child_context->contextlevel == CONTEXT_CATEGORY) {
                        $category_contexts_list[] = $child_context; // add to the queue
                    }
                }
            }
            $activities = $DB->get_records_select(GLUELET_MOD, 'in ('.implode(',', $course_list).')');

        } else if ($context->contextlevel == CONTEXT_SYSTEM) {  // system level enrolments affect to every activity
            $activities = $DB->get_records(GLUELET_MOD);
        }

    }

    return $activities;

}

//////////////////////
/// COURSES EVENTS ///
//////////////////////

function course_created_handler($eventdata) {
    // full course record
    add_to_log(0, GLUELET_MOD, "event", '', 'COURSE CREATED event received');
    // nothing to do
    return true;
}


function course_updated_handler($eventdata) {
    // full course record
    add_to_log(0, GLUELET_MOD, "event", '', 'COURSE UPDATED event received');
    // �?
    return true;
}


function course_deleted_handler($eventdata) {
    // full course record
    add_to_log(0, GLUELET_MOD, "event", '', 'COURSE DELETED event received');
    // confiemos en que se lancen deletes
    return true;
}


function course_category_deleted_handler($eventdata) {
    // full category record
    add_to_log(0, GLUELET_MOD, "event", '', 'COURSE CATEGORY DELETED event received');
    // confiemos en que se lancen deletes
    return true;
}


/////////////////////
/// GROUPS EVENTS ///
/////////////////////

function groups_member_added_handler($eventdata) {
	global $DB;
    //  groupid
    //  userid
    add_to_log(0, GLUELET_MOD, "event", '', 'GROUPS MEMBER ADDED event received');

    /// TODO avoid re-additions
    /// TODO check previous removals of members

    /// find all the raws in mdl_gluelet_instances where groupid value is $eventdata->groupid
    $instances = $DB->get_records(GLUELET_INS, array('groupid' => $eventdata->groupid));
    if (is_array($instances)) {
        foreach ($instances as $instance) {
            $dataobject = new StdClass;
            $dataobject->glueletinstance = $instance->id;
            $dataobject->userid = $eventdata->userid;
            $dataobject->action = GLUELET_USERS_CHANGE_ADD;
            $DB->insert_record(GLUELET_USERS_CHANGES, $dataobject);
        }
    }
    return true;
}


function groups_member_removed_handler($eventdata) {
	global $DB;
    //  groupid
    //  userid
    add_to_log(0, GLUELET_MOD, "event", '', 'GROUPS MEMBER REMOVED event received');
    /// TODO avoid repeated removals
    /// TODO check previous additions of members

    /// find all the raws in mdl_gluelet_instances where groupid value is $eventdata->groupid
    $instances = $DB->get_records(GLUELET_INS, array('groupid' => $eventdata->groupid));
    if (is_array($instances)) {
        foreach ($instances as $instance) {
            $dataobject = new StdClass;
            $dataobject->glueletinstance = $instance->id;
            $dataobject->userid = $eventdata->userid;
            $dataobject->action = GLUELET_USERS_CHANGE_DEL;
            $DB->insert_record(GLUELET_USERS_CHANGES, $dataobject);
        }
    }
    return true;
}


function groups_group_created_handler($eventdata) {
    // id, couseid, name, description, timecreated, timemodified, picture
    add_to_log(0, GLUELET_MOD, "event", '', 'GROUPS GROUP CREATED event received');
    // nuevo grupo -> falta por crear instancia;
    return true;
}


function groups_group_updated_handler($eventdata) {
    // id, courseid, name, description, timecreated, timemodified, picture
    add_to_log(0, GLUELET_MOD, "event", '', 'GROUPS GROUP UPDATED event received');
    return true;
}


function groups_group_deleted_handler($eventdata) {
	global $DB;
    // id, courseid, name, description, timecreated, timemodified, picture
    add_to_log(0, GLUELET_MOD, "event", '', 'GROUPS GROUP DELETED event received');

    /// find all the raws in mdl_gluelet_instances where groupid value is $eventdata->id
    $instances = $DB->get_records(GLUELET_INS, array('groupid' => $eventdata->id));
    if (is_array($instances)) {
        foreach ($instances as $instance) {
            $dataobject = new StdClass;
            $dataobject->glueletinstance = $instance->id;
            $dataobject->userid = -1;   // take that!
            $dataobject->action = GLUELET_USERS_CHANGE_DEL;
            $DB->insert_record(GLUELET_USERS_CHANGES, $dataobject);
        }
    }

    return true;
}


function groups_groups_deleted_handler($eventdata) {
	global $DB;
    // courseid (as plain integer, not object)
    // delete all groups IN A COURSE (be careful!)
    add_to_log(0, GLUELET_MOD, "event", '', 'GROUPS GROUPS DELETED event received');

    /// find all the GLUElet-activities where course column is $eventdata (courseid)
    // raws in mdl_gluelet_instances where groupid is >= 0
    //$activities = get_records_select(GLUELET_MOD, 'course', $eventdata);
    $activities = $DB->get_records_select(GLUELET_MOD, 'course='. $eventdata);
    if (is_array($activities)) {
        foreach ($activities as $activity) {
            // for each grouped GLUElet, add a row to the table of pending changes
            $instances = $DB->get_records_select(GLUELET_INS, 'glueletactivity='. $activity->id . ' AND groupid >= 0');
            if (is_array($instances)) {
                foreach ($instances as $instance) {
                    $dataobject = new StdClass;
                    $dataobject->glueletinstance = $instance->id;
                    $dataobject->userid = -1;   // take that
                    $dataobject->action = GLUELET_USERS_CHANGE_DEL;
                    $DB->insert_record(GLUELET_USERS_CHANGES, $dataobject);
                }
            }
        }
    }
    return true;
}


function groups_grouping_created_handler($eventdata) {
    // id, courseid, name, timecreated, timemodified
    add_to_log(0, GLUELET_MOD, "event", '', 'GROUPS GROUPING CREATED event received');
    return true;
}


function groups_grouping_updated_handler($eventdata) {
    // id, courseid, name, timecreated, timemodified
    add_to_log(0, GLUELET_MOD, "event", '', 'GROUPS GROUPING UPDATED event received');
    return true;
}


function groups_grouping_deleted_handler($eventdata) {
    // id, courseid, name, timecreated, timemodified
    add_to_log(0, GLUELET_MOD, "event", '', 'GROUPS GROUPING DELETED event received');
    return true;
}


function groups_members_removed_handler($eventdata) {
	global $DB;
    // courseid, userid
    // user deleted from all groups in a course
    // record from 'role_assignents'; course context only
    add_to_log(0, GLUELET_MOD, "event", '', 'GROUPS MEMBERS REMOVED event received');

    //1. get the list of GLUElet activities in the course
    $activities = $DB->get_records(GLUELET_MOD, array('course' => $eventdata->courseid));
    if (is_array($activities)) {
        foreach ($activities as $activity) {
            // 2. for each grouped GLUElet, add a row to the table of pending changes
            /// davivel: it can't be done better; when this function is called, the table mdl_groups_members has been modified yet;
            ///          then, we can't select only GLUElets where groupid is equal to the groupid of some group containing $eventdata->userid as a member
            $instances = $DB->get_records_select(GLUELET_INS, 'glueletactivity='. $activity->id . ' AND groupid >= 0');
            if (is_array($instances)) {
                foreach ($instances as $instance) {
                    $dataobject = new StdClass;
                    $dataobject->glueletinstance = $instance->id;
                    $dataobject->userid = $eventdata->userid;
                    $dataobject->action = GLUELET_USERS_CHANGE_DEL;
                    $DB->insert_record(GLUELET_USERS_CHANGES, $dataobject);
                }
            }
        }
    }

    //debugging('GROUPS MEMBERS REMOVED event processed');

    return true;
}


function groups_groupings_groups_removed_handler($eventdata) {
    // courseid (as plain integer, not object)
    // remove all groups from all groupings in a course
    add_to_log(0, GLUELET_MOD, "event", '', 'GROUPS GROUPINGS GROUPS REMOVED event received');
    return true;
}


function groups_groupings_deleted_handler($eventdata) {
    // courseid (as plain integer, not object)
    // delete all groupings in a course
    add_to_log(0, GLUELET_MOD, "event", '', 'GROUPS GROUPINGS DELETED event received');
    return true;
}


?>

