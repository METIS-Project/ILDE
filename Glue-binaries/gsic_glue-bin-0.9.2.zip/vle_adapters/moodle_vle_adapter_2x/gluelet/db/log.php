<?php

/**
  This file is part of MoodleVLEAdapter.
  
  MoodleVLEAdapter is a property of the Intelligent & Cooperative Systems 
  Research Group (GSIC) from the University of Valladolid (UVA). 
  
  Copyright 2011 GSIC (UVA).

  MoodleVLEAdapter is licensed under the GNU General Public License (GPL) 
  EXCLUSIVELY FOR NON-COMMERCIAL USES. Please, note this is an additional 
  restriction to the terms of GPL that must be kept in any redistribution of
  the original code or any derivative work by third parties.

  If you intend to use MoodleVLEAdapter for any commercial purpose you can 
  contact to GSIC to obtain a commercial license at <glue@gsic.tel.uva.es>.

  If you have licensed this product under a commercial license from GSIC,
  please see the file LICENSE.txt included.

  The next copying permission statement (between square brackets []) is 
  applicable only when GPL is suitable, this is, when MoodleVLEAdapter is 
  used and/or distributed FOR NON COMMERCIAL USES.
  
  [ You can redistribute MoodleVLEAdapter and/or modify it under the 
    terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
  ]
*/


/**
 * Definition of log events
 *
 * NOTE: this is an example how to insert log event during installation/update.
 * It is not really essential to know about it, but these logs were created as example
 * in the previous 1.9 NEWMODULE.
 *
 * @author  Javier Hoyos Torio 
 * @version 2012053001
 * @package mod/gluelet
 * @todo    
 */

defined('MOODLE_INTERNAL') || die();

global $DB;

$logs = array(
    array('module'=>'gluelet', 'action'=>'add', 'mtable'=>'gluelet', 'field'=>'name'),
    array('module'=>'gluelet', 'action'=>'update', 'mtable'=>'gluelet', 'field'=>'name'),
    array('module'=>'gluelet', 'action'=>'view', 'mtable'=>'gluelet', 'field'=>'name')
);

?>