<?php

/**
  This file is part of MediaWikiVLEAdapter.
  
  MediaWikiVLEAdapter is a property of the Intelligent & Cooperative Systems 
  Research Group (GSIC) from the University of Valladolid (UVA). 
  
  Copyright 2011 GSIC (UVA).

  MediaWikiVLEAdapter is licensed under the GNU General Public License (GPL) 
  EXCLUSIVELY FOR NON-COMMERCIAL USES. Please, note this is an additional 
  restriction to the terms of GPL that must be kept in any redistribution of
  the original code or any derivative work by third parties.

  If you intend to use MediaWikiVLEAdapter for any commercial purpose you can 
  contact to GSIC to obtain a commercial license at <glue@gsic.tel.uva.es>.

  If you have licensed this product under a commercial license from GSIC,
  please see the file LICENSE.txt included.

  The next copying permission statement (between square brackets []) is 
  applicable only when GPL is suitable, this is, when MediaWikiVLEAdapter is 
  used and/or distributed FOR NON COMMERCIAL USES.
  
  [ You can redistribute MediaWikiVLEAdapter and/or modify it under the 
    terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
  ]
*/


 /** 
 * This class defines methods and properties to implements a simple REST client for GLUE arquitecture.
 *
 * This class allows you to do the following requests against the GLUE arquitecture's REST server:
 *		- Get an instance: 				HTTP GET request to instance/instance/id resourse.
 *		- Create an instance: 			HTTP POST request to glueletmanager/toolid resource.
 *		- Delete an instance:			HTTP DELETE request to glueletmanager/instance/id resource.
 *		- Get tool list:				HTTP GET request to glueletmanager/tools resource.
 *		- Get tool configuration form:	HTTP GET request to glueletmanager/toolid/configuration resource.
 *
 * For REST requests are used PHP's cURL libraries. That allows you to connect and communicate to many different types of 
 * servers with many different types of protocols. Libcurl also supports HTTPS GET, HTTP POST, HTTP PUT  and HTTP 
 * DELETE that are used in this class for REST requests.
 * 
 * Requeriments: This client won't work out correctly if PHP's cURL libraries are not found.
 * In order to use PHP's cURL functions you need to install the libcurl package (http://curl.haxx.se/). PHP requires that you use 
 * libcurl 7.0.2-beta or higher. In PHP 4.2.3, you will need libcurl version 7.9.0 or higher. From PHP 4.3.0, you will need a libcurl 
 * version that's 7.9.8 or higher. PHP 5.0.0 requires a libcurl version 7.10.5 or greater. 
 *
 * @access public 
 * @author Javier Aragon
 * @version 2011/05/31-0.1
 * @package php/classes/rest
 */  

require_once(dirname(__FILE__).'/formatted_feed.php');
require_once(dirname(__FILE__).'/formatted_entry.php');
require_once(dirname(__FILE__)."/GlueletManagerClientError.php");
 
class GlueletManagerRestClient {
	
	
	// --- ATTRIBUTES ---  
	var $user;
	var $userlist;
	var $glueletmanagerhost;

	
	 /** 
	 * GlueletManagerRestClient Constructor.
	 * 
	 * @access 	public 
	 * @author 	Javier Aragon, <jaragoncaz@gmail.com> 
	 * @param 	messages   	String		File path where is declared internationalized message matrix.
	 * @param 	lang   		String      User language selected.
	 * @return 	void 
	 **/
	public function __construct($user, $user_list, $gluelermanager_url_host){
		$this->user = $user;
		$this->userlist = $user_list;
		$this->glueletmanagerhost = $gluelermanager_url_host;
	}

	
	
	/**
	 * Call to GLUEletManager in order to get the list of availble tools for creating GLUElets.
	 *
	 * Method ::18:: at Informe_041b_01_02_09.pdf is called and its answer processed to extract the names and URIs of existing tools.
	 *
	 * @return array    Associative array with toolids as keys and toolnames as values, or null in case of fail.
	 */
	public function gluelet_get_tools_list() {
		
		// cURL handler creation
		$ch = curl_init();

		// HTTP method
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");

		// URL
		
		//curl_setopt($ch, CURLOPT_URL, 'http://157.88.130.174:8185/GLUEletManager/tools');
		//curl_setopt($ch, CURLOPT_URL, 'http://localhost:8185/GLUEletManager/tools');
		curl_setopt($ch, CURLOPT_URL, $this->glueletmanagerhost.'/tools');

		// set the handler for delivering answers in strings, instead of being directly printed on page
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

		// perform the HTTP request
		$out = curl_exec($ch);

		// get answer HTTP code
		$status = curl_getinfo($ch, CURLINFO_HTTP_CODE);

		// get cURL error code
		$curl_errno = curl_errno($ch);

		// extract tools list from Atom response
		$tools = null;
		if (!$curl_errno && $status == 200) {
			$nice_http_code = true;
			 
			$feed = new formatted_feed($out);		
			$entries = $feed->getFormattedEntries();
			$i = 0;

			foreach ($entries as $index => $entry) {
				$toolid = $entry->getAtomSimpleElement("id");
				$toolname = $entry->getAtomSimpleElement("title");
				$toolprovider = $entry->getExtendedSimpleElement("toolProvider");

				$tools[$toolid] = $toolname . " ( " . $toolprovider . " )";
			}
			
			if (is_array($tools) && count($tools) > 0){
				// the tool list is OK.
				$result[0] = true;
				$result[1] = $tools;
			} else {
				// the tool list is empty.
				$result[0] = false;
				$result[1] = new GlueletManagerClientError($curl_errno, $status, ($curl_errno ? curl_error($ch) : $out) , 'get_instance', true, 'emptytoollistmessage');
			}
		
		
		} else{
			// there is a cURL error or http request returned an error status.
			$result[0] = false;
			$result[1] = new GlueletManagerClientError($curl_errno, $status, ($curl_errno ? curl_error($ch) : $out) , 'get_instance', false, null);
		}
		
			
		
		// free resources
		curl_close($ch);

		return $result;
	}


	/**
	 * Call to GLUEletManager in order to get the configuration definition file needed to create GLUElet instacnes with a previously selected tool.
	 *
	 * Method ::25*:: at Informe_041b_01_02_09.pdf is called and its answer processed to extract the XForms configuration file.
	 *
	 * @param   string  $toolid     Final part of the URL to the tool resource whose configuration wants to be obtained
	 * @return  string              XML configuration form, or null in case of fail.
	 *
	 */
	public function gluelet_get_configuration_form($toolid) {
		
		// cURL handler creation
		$ch = curl_init();

		// HTTP method
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");

		// URL
		curl_setopt($ch, CURLOPT_URL, $toolid.'/configuration');
		
		  // set the timeout limit
		curl_setopt($ch, CURLOPT_TIMEOUT, '500');

		// set the handler for delivering answers in strings, instead of being directly printed on page
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

		// perform the HTTP request
		$out = curl_exec($ch);

		// get answer HTTP
		$status = curl_getinfo($ch, CURLINFO_HTTP_CODE);

		// get cURL error code
		$curl_errno = curl_errno($ch);

		// check status code and return appropiate result
		$result = array(0 => false, 1 => null);
		$nice_http_code = false;
		if (!$curl_errno && $status == 200) {
			$nice_http_code = true;
			$entry = new formatted_entry($out);
			$content =  $entry->getAtomStructuredElement("content");
			if ($content) {
				if (is_object($content->firstChild)) {
					// configuration form exists - extract from the entry
					$contentDOM = new DOMDocument();
					$contentDOM->appendChild($contentDOM->importNode($content->firstChild, true));  // importing before saving to avoid problems with namespace definitions (necessary!!)
					$result[1] = $contentDOM->saveXML($contentDOM->documentElement);
				} else{
					// configuration form is not needed; GET CONF results in OK, but the 'content' element is empty (empty string, not null)
					//$result[1] = $entry->getAtomSimpleElement("content");
					$result[1]="";
						
						$result[1]="<content type='xhtml'>
										<div xmlns='http://www.w3.org/1999/xhtml' xmlns:ev='http://www.w3.org/2001/xml-events' xmlns:ins='http://gsic.uva.es/glue/adaptors/implementation/gdata/1.0' xmlns:xf='http://www.w3.org/2002/xforms' xmlns:xs='http://www.w3.org/2001/XMLSchema' xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance'>    
											<xf:model> 
												<xf:instance id='input-file'>
													<ins:data>
													</ins:data>
												</xf:instance>
												<xf:submission action='http://localhost:8080/show_all.php' id='s' method='post'/>
											</xf:model>
											<xf:label><p>  Nothing to configure here!!! </p></xf:label>
											<xf:submit submission='s'></xf:submit>
										</div>
									</content>";
				}
					$result[0] = (is_string($result[1]));
			}
		}

		if (!$result[0]) // something failed
			$result[1] = new GlueletManagerClientError($curl_errno, $status, ($curl_errno ? curl_error($ch) : $out) , 'gluelet_get_configuration_form', false, null);

		// free resources
		curl_close($ch);

		return $result;



	  
	}


	/**
	 * Call to GLUEletManager in order to obtain the URL to an actual GLUElet instance, known the URL to the GLUElet resource.
	 *
	 * Method ::30:: at Informe_041b_01_02_09.pdf is called and its answer processed to extract the URI to the actual GLUElet instance.
	 *
	 * @param   string  $resourceURL    Final part of the URL to the gluelet resource at GLUEletManager
	 * @return  string                  URL to the actual gluelet instance.
	 */
	private function gluelet_get_instance($resourceURL) {

		// cURL handler creation
		$ch = curl_init();
		//$user = 'EsteUsuarioNoExiste';

		// append URL parameters
		//$resourceURL .= "?user=1";
		//. urlencode($USER->username);      // add username
			// append URL parameters
		$completeURL = $this->glueletmanagerhost .$resourceURL . "?callerUser=" . urlencode($this->user);      // add username as calleruser

		// HTTP method
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");

		// URL
		//curl_setopt($ch, CURLOPT_URL, $resourceURL);
		//curl_setopt($ch, CURLOPT_URL, 'http://localhost:8185/GLUEletManager' . $resourceURL);
		curl_setopt($ch, CURLOPT_URL, $completeURL);

		// set the timeout limit
		//curl_setopt($ch, CURLOPT_TIMEOUT, $CFG->{GLUELET_MOD . '_timeout'});

		// set the handler for delivering answers in strings, instead of being directly printed on page
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

		// perform the HTTP request
		$out = curl_exec($ch);

		// get the answer HTTP code
		$status = curl_getinfo($ch, CURLINFO_HTTP_CODE);

		// get cURL error code
		$curl_errno = curl_errno($ch);

		// extract URL from Atom response
		$result = array(0 => false, 1 => null, 2 => null);
		$nice_http_code = false;
		if (!$curl_errno && $status == 200) {
			$nice_http_code = true;
			$response =  new formatted_entry($out);
			//$targetURL = $response->getAtomAttribute("content", "src");
			$result[1] = $response->getAtomAttribute("link", "href");
			$result[0] = (is_string($result[1]) && strlen($result[1]) > 0);
			//$result[2] = $response->saveXML();
			$result[2] = $out;
		}
		
		if (!$result[0]) // something failed
			$result[1] = new GlueletManagerClientError($curl_errno, $status, ($curl_errno ? curl_error($ch) : $out), 'get_instance', $nice_http_code, null);
	   

		// free resources
		curl_close($ch);

		return $result;
	}


	
	/**
	 * Call to GLUEletManager in order to obtain the URL to an actual GLUElet instance, known the URL to the GLUElet resource.
	 * This function is called when a user who is editing an article try to view an instance.
	 *
	 * Method ::30:: at Informe_041b_01_02_09.pdf is called and its answer processed to extract the URI to the actual GLUElet instance.
	 *
	 * @param   string  $resourceURL    Final part of the URL to the gluelet resource at GLUEletManager
	 * @return  string                  URL to the actual gluelet instance.
	 */
	public function gluelet_get_instance_onedit($instanceID) {

		// extract URL from Atom response
		//$result = array(0 => false, 1 => null, 2 => null);
		$result = $this->gluelet_get_instance($instanceID);

		//if ($result[0] && !$curl_errno && $status == 200) {
		if ($result[0]){
			return $result;
		//} else if (!$result[0] && !$curl_errno && $status == 403){
		}else {
			// We Recived an error that can be caused cause the callerUSer is not registred like a user in the instance.
			// Resend the userlist with new's and old users from the wiki.
			// And re-try to obtain the instance
			
			// Gets the newer user list.
			$userlist_as_array = split(",",$this->userlist);
			
			if ($defaultWikiUser && $defaultWikiUser!=null && $defaultWikiUser!="" ){
				$cont = array_push($userlist_as_array, $defaultWikiUser);
			}
			
			// Add the new user list to instance
			$usersadded = gluelet_post_new_userlist($instanceID, $userlist_as_array);
			
			//Re-try to get the instance.
			if ($usersadded[0]){
				//return gluelet_get_instance($instanceid);
				return gluelet_get_instance($instanceID);
			} else {
				return $usersadded;
			}
		}/* else {
			return $result;
		}*/
	   

		// free resources
		//curl_close($ch);
	}








	/**
	 * Call to GLUEletManager in order to obtain the URL to an actual GLUElet instance, known the URL to the GLUElet resource.
	 * This function is called when the Glue extension try to parse a gluelettag into a iframe with the url to show the instantce.
	 *
	 * Method ::30:: at Informe_041b_01_02_09.pdf is called and its answer processed to extract the URI to the actual GLUElet instance.
	 *
	 * @param   string  $resourceURL    Final part of the URL to the gluelet resource at GLUEletManager
	 * @return  string                  URL to the actual gluelet instance.
	 */
	public function gluelet_get_instance_to_viewing($instanceid, $defaultWikiUser, $dbhost, $dbname, $dbuser, $dbpass, $dbprefix) {

		// cURL handler creation
		$ch = curl_init();
		//$user = 'EsteUsuarioNoExiste';

		// append URL parameters
		//$resourceURL .= "?user=1";
		//. urlencode($USER->username);      // add username
			// append URL parameters
		$getresourceURL = $this->glueletmanagerhost . $instanceid."?callerUser=" . urlencode($this->user);      // add username

		// HTTP method
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");

		// URL
		//curl_setopt($ch, CURLOPT_URL, $resourceURL);
		//curl_setopt($ch, CURLOPT_URL, 'http://localhost:8185/GLUEletManager' . $resourceURL);
		curl_setopt($ch, CURLOPT_URL, $getresourceURL);

		// set the timeout limit
		//curl_setopt($ch, CURLOPT_TIMEOUT, $CFG->{GLUELET_MOD . '_timeout'});

		// set the handler for delivering answers in strings, instead of being directly printed on page
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

		// perform the HTTP request
		$out = curl_exec($ch);

		// get the answer HTTP code
		$status = curl_getinfo($ch, CURLINFO_HTTP_CODE);

		// get cURL error code
		$curl_errno = curl_errno($ch);

		// extract URL from Atom response
		$result = array(0 => false, 1 => null, 2 => null);
		$nice_http_code = false;
		if (!$curl_errno && $status == 200) {
			$nice_http_code = true;
			$response =  new formatted_entry($out);
			//$targetURL = $response->getAtomAttribute("content", "src");
			$result[1] = $response->getAtomAttribute("link", "href");
			$result[0] = (is_string($result[1]) && strlen($result[1]) > 0);
			//$result[2] = $response->saveXML();
			$result[2] = $out;
			
		} else if ($status == 403){
			// We Recived an error that can be caused cause the callerUSer is not registred like a user in the instance.
			// Resend the userlist with new's and old users from the wiki.
			// And re-try to obtain the instance
			
			// Gets the newer user list.
			$newuserlist = get_mediawiki_users($dbname, $dbhost, $dbuser, $dbpass, $dbprefix);
			
			if ($defaultWikiUser && $defaultWikiUser!=null && $defaultWikiUser!="" ){
				$cont = array_push($newuserlist, $defaultWikiUser);
			}
			
			// Add the new user list to instance
			$usersadded = gluelet_post_new_userlist($instanceid, $newuserlist);
			
			//Re-try to get the instance.
			if ($usersadded[0]){
				return gluelet_get_instance($instanceid);
			} else {
				return $usersadded;
			}
			
		}
	   

		// free resources
		curl_close($ch);

		return $result;
	}




	/**
	 * Call to GLUEletManager in order to post a new user list to an instance.
	 *
	 *
	 * @param   String		$toolId     URL to the tool resource to be used for creation.
	 * @param   String      $users    	User list as a comma splitted string
	 * @return 	String		The created instance id as string.		
	 */
	public function gluelet_post_new_userlist($toolId, $users) {

		// cURL handler creation
		$ch = curl_init();
		
		// build Atom+GLUE formatted set of parameters
		$entry = new formatted_entry();
		//$entry->addExtendedStructuredList("students", "student", $students);
		$entry->addExtendedStructuredList("users", "user", $users);
		$entry->addExtendedSimpleElement("callerUser", urlencode($this->user));

		// HTTP header; PHP cURL documentation states that it overrides present header, so I call it before all the other curl_setopt
		$headers = array(
			"Content-type: application/xml",
			//"Pragma: no-cache",   // maybe convenient?
			"Content-length: ".strlen($entry->saveXML()),
		);
		
		// URL
		curl_setopt($ch, CURLOPT_URL, $this->glueletmanagerhost . $toolId);

		// set the timeout limit
		curl_setopt($ch, CURLOPT_TIMEOUT, 6000);

		// HTTP method
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");

		// set the handler for delivering answers in strings, instead of being directly printed on page
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

		// insert the XML as HTTP entity
		curl_setopt($ch, CURLOPT_POSTFIELDS, $entry->saveXML());

		// perform the HTTP request
		$out = curl_exec($ch);

		// get answer HTTP
		$status = curl_getinfo($ch, CURLINFO_HTTP_CODE);

		// get cURL error code
		$curl_errno = curl_errno($ch);

		// check status code and return proper result
		$result = array(0 => false, 1 => null);
		$nice_http_code = false;
		if (!$curl_errno && $status == GLUELET_HTTP_STATUS_OK) {
			$nice_http_code = true;
			$entry = new formatted_entry($out);
			$id =  $entry->getAtomSimpleElement("id");
			$id = substr($id, strlen('http://' . $CFG->{GLUELET_MOD . '_base_url'} . '/GLUEletManager'));
			$result[1] = $id;
			$result[0] = (is_string($result[1]) && strlen($result[1]) > 0);
		}
		if (!$result[0])
			$result[1] = new GlueletManagerClientError($curl_errno, $status, ($curl_errno ? curl_error($ch) : $out), 'post_users_list', $nice_http_code, null);

		// free resources
		curl_close($ch);

		return $result;

	}


	/**
	 * Call to GLUEletManager in order to create a new GLUElet instance, with a previously selected tool and full configuration data.
	 *
	 * Method ::25:: at Informe_041b_01_02_09.pdf is called and its answer processed to extract the URI to the new GLUElet resource.
	 *
	 * @param   String		$toolId     URL to the tool resource to be used for creation.
	 * @param   DOM         $xmlConf    DOM tree to send as XML with data for the creation of a new gluelet instance.
	 * @return 	String		The created instance id as string.		
	 */
	public function gluelet_post_new_instance($toolId, $xmlConf) {

		// cURL handler creation
		$ch = curl_init();

		// build Atom+GLUE formatted set of parameters
		$entry = new formatted_entry();
		$entry->addExtendedSimpleElement("tool", $toolId);
		if ($xmlConf)
			$entry->addExtendedStructuredElement("configuration", $xmlConf);
		else
			$entry->addExtendedSimpleElement("configuration", "");
		$entry->addExtendedStructuredList("users", "user", $this->userlist);
		$entry->addExtendedSimpleElement("callerUser", $this->user);

		// HTTP header; PHP cURL documentation states that it overrides present header, so I call it before all the other curl_setopt
		$headers = array(
			"Content-type: application/xml",
			//"Pragma: no-cache",   // maybe convenient?
			"Content-length: ".strlen($entry->saveXML()),
		);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

		// URL
		// $url =  'http://' . $CFG->{GLUELET_MOD . '_server_name'} . ':' . $CFG->{GLUELET_MOD . '_server_port'} . '/GLUEletManager/instance';
		// $url . '/instance';

		//$url .= "?tool=" . urlencode($toolId);      // add URL to tool resource as an URL-parameter
		curl_setopt($ch, CURLOPT_URL, $this->glueletmanagerhost . '/instance');

		// HTTP method
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");

		// set the handler for delivering answers in strings, instead of being directly printed on page
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

		// insert the XML as HTTP entity
		curl_setopt($ch, CURLOPT_POSTFIELDS, $entry->saveXML());

		// perform the HTTP request
		$out = curl_exec($ch);

		// get answer HTTP
		$status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		
		// get cURL error code
		$curl_errno = curl_errno($ch);

		// check status code and return appropiate result
		if (!$curl_errno && $status == 201) {
			$entry = new formatted_entry($out);
			$id =  $entry->getAtomSimpleElement("id");
			//$id = substr($id, strlen('http://157.88.130.174:8185/GLUEletManager'));   // save only the final part
			$id = substr($id, strlen($this->glueletmanagerhost));   // save only the final part
			if ($id && $id!=null && is_string($id) && strlen($id) > 0 ){
				$result[0] = true;
				$result[1] = $id;
			} else{
				// http request ok bu somthing happend: $id is not correct.
				$result[0] = false;
				$result[1] = new GlueletManagerClientError($curl_errno, $status, ($curl_errno ? curl_error($ch) : $out), 'gluelet_post_new_instance', $true, 'noidgetinstanceerrormessage');
			}
			
		} else{
			$result[0] = false;
			$result[1] = new GlueletManagerClientError($curl_errno, $status, ($curl_errno ? curl_error($ch) : $out), 'gluelet_post_new_instance', $false, null);
		}
		
		return $result;
		// free resources
		curl_close($ch);
		
	}







	/**
	 * Call to GLUEletManager in order to delete a actual GLUElet instance, known the URL to the GLUElet resource.
	 *
	 * Method ::32:: at Informe_041b_01_02_09.pdf is called.
	 *
	 * @param   String	$instandeID		Final part of the URL to the gluelet resource at GLUEletManager
	 * @return  Array                 	Success/Fail
	 */
	public function gluelet_delete_instance($instanceid) {

		// cURL handler creation
		$ch = curl_init();

		// HTTP method
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");

		// URL
		//curl_setopt($ch, CURLOPT_URL, $instanceid);
		curl_setopt($ch, CURLOPT_URL, $this->glueletmanagerhost . $instanceid);

		// set the timeout limit
		curl_setopt($ch, CURLOPT_TIMEOUT, 500);

		// set the handler for delivering answers in strings, instead of being directly printed on page
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

		// perform the HTTP request
		$out = curl_exec($ch);

		// get the answer HTTP code
		$status = curl_getinfo($ch, CURLINFO_HTTP_CODE);

		// get cURL error code
		$curl_errno = curl_errno($ch);

		// check and process request result
		$result = array(0 => true, 1 => null);
		if ($curl_errno || $status != 200) {    // something failed
			$result[0] = false;
			$result[1] = new GlueletManagerClientError($curl_errno, $status, ($curl_errno ? curl_error($ch) : $out) , 'delete_instance', false, null);
		}

		// free resources
		curl_close($ch);

		return $result;

	}

}

?>