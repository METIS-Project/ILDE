<!--
  This file is part of MediaWikiVLEAdapter.
  
  MediaWikiVLEAdapter is a property of the Intelligent & Cooperative Systems 
  Research Group (GSIC) from the University of Valladolid (UVA). 
  
  Copyright 2011 GSIC (UVA).

  MediaWikiVLEAdapter is licensed under the GNU General Public License (GPL) 
  EXCLUSIVELY FOR NON-COMMERCIAL USES. Please, note this is an additional 
  restriction to the terms of GPL that must be kept in any redistribution of
  the original code or any derivative work by third parties.

  If you intend to use MediaWikiVLEAdapter for any commercial purpose you can 
  contact to GSIC to obtain a commercial license at <glue@gsic.tel.uva.es>.

  If you have licensed this product under a commercial license from GSIC,
  please see the file LICENSE.txt included.

  The next copying permission statement (between square brackets []) is 
  applicable only when GPL is suitable, this is, when MediaWikiVLEAdapter is 
  used and/or distributed FOR NON COMMERCIAL USES.
  
  [ You can redistribute MediaWikiVLEAdapter and/or modify it under the 
    terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
  ]
-->

<!-- 
 @author Javier Aragon
-->
 

<script type='text/javascript' language='javascript'>

	function cargargluelet(){
		document.getElementById("loadingdiv").style.display='none';
		document.getElementById("allpagediv").style.display='';
	}
	function showit(){
		if (document.getElementById("instanceinfo").style.display==''){
			document.getElementById("instanceinfo").style.display='none';
			document.getElementById("imageshowinfo").innerHTML="<img src='./images/plus_add.png' onclick=showit()><u><b>  "+inflabel+"</img> </b></u></img>";
		}else if (document.getElementById("instanceinfo").style.display=='none'){
			document.getElementById("instanceinfo").style.display='';
			document.getElementById("imageshowinfo").innerHTML="<img src='./images/minus_remove.png' onclick=showit()><u><b>  "+inflabel+"</img> </b></u></img>";
			
		}
	}
</script>

<style>	
	.sangrar {
		padding-left: 50px;
	}
		
	.sangrar2 {
		padding-left: 15px;
	}
</style>
<?php
print("<html>");
print("<head>");
print("<title></title>");
print("</head>");

print("<body onload='cargargluelet()'>");

	require_once('../classes/rest/GlueletManagerRestClient.php');
	require_once('../classes/i18n/I18NGlueLibMessages.php');
	// ponemos idioma por defecto 'español'
	$lang = $_GET['lang'];
	// Si no se pasa por parametro el lenguaje se pone por defecto español.
	if (!$lang || $lang==null || $lang=="")
		$I18N = new I18NGlueLibMessages('en');
	else
		$I18N = new I18NGlueLibMessages($lang);

	echo "<head><title>".$I18N->getI18NMessage('showglueletpagetitle')."</title>";
	
	echo "<script type='text/javascript'>";
	echo " var inflabel = '". $I18N->getI18NMessage('infglueletlabel') ."';";
	echo "</script>";

	print("<div id=loadingdiv class=centerpagediv><center><p><img alt=' Cargando ... ' src='./images/iloader.gif' onclick=showit()></img></p></center></div>");

	$toolid = $_GET['toolid'];
	$user = $_GET['userid'];
	$userlist = $_GET['userlist'];
	$glueletmanager = $_GET['glueletmanager'];
	
	if (!$toolid || !$glueletmanager || !$user || !$userlist || $toolid=="" || $glueletmanager=="" || $user=="" || $userlist=="") {
		die($I18N->getI18NMessage('errorinparams'));
	}
 
	$rest_client = new GlueletManagerRestClient($user, $userlist, $glueletmanager);
	$result = $rest_client->gluelet_get_instance_withusers($toolid,$user, $userlist);
	if ($result && $result[1] && $result[1] !=""){
        $doc = new DOMDocument();
        $doc->loadXML($result[2]);
		$asDom = $doc;
		//$asDom = DOMDocument::loadXML( $result[2] );
		echo "<div id='allpagediv' style=display:none>";
		echo "<div id=imageshowinfo><img src='./images/plus_add.png' onclick=showit()><u><b>  ".$I18N->getI18NMessage('infglueletlabel')."</img> </b></u></div>";
		echo "<div id='instanceinfo' style='display:none' class='sangrar'><table>";
		echo "<tr><td><b>".$I18N->getI18NMessage('authorlabel')."</b></td><td><span class=sangrar2>" 	. $asDom->getElementsByTagName('author')->item(0)->textContent 			. '</span><br></td></tr>';
		echo "<tr><td><b>".$I18N->getI18NMessage('instanceidlabel')."</b></td><td><span class=sangrar2>" 		. $asDom->getElementsByTagName('id')->item(0)->textContent 				. '</span><br></td></tr>';
		echo "<tr><td><b>".$I18N->getI18NMessage('linklabel')."</b></td><td><span class=sangrar2>" 	. $asDom->getElementsByTagName('link')->item(0)->getAttribute('href') 	. '</span><br></td></tr>';
		echo "<tr><td><b>".$I18N->getI18NMessage('updateddatelabel')."</b></td><td><span class=sangrar2>" . $asDom->getElementsByTagName('updated')->item(0)->textContent 		. '</span><br></td></tr>';
		echo "</table></div>";
		echo "<p/><center><iframe src='". $result[1]."' align='center' FRAMEBORDER=1 width='90%' height='90%' id=tool> <p>".$I18N->getI18NMessage('iframerrormsg')."</p> </iframe></center>";
		echo "</div>";
	} else {
		echo "<p>- ".$I18N->getI18NMessage('nodisplayerrormsg')." --> ". $input ."</p>";
	}
	




print("</body>");
print("</html>");

?>