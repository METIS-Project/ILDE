<?php

/**
  This file is part of MediaWikiVLEAdapter.
  
  MediaWikiVLEAdapter is a property of the Intelligent & Cooperative Systems 
  Research Group (GSIC) from the University of Valladolid (UVA). 
  
  Copyright 2011 GSIC (UVA).

  MediaWikiVLEAdapter is licensed under the GNU General Public License (GPL) 
  EXCLUSIVELY FOR NON-COMMERCIAL USES. Please, note this is an additional 
  restriction to the terms of GPL that must be kept in any redistribution of
  the original code or any derivative work by third parties.

  If you intend to use MediaWikiVLEAdapter for any commercial purpose you can 
  contact to GSIC to obtain a commercial license at <glue@gsic.tel.uva.es>.

  If you have licensed this product under a commercial license from GSIC,
  please see the file LICENSE.txt included.

  The next copying permission statement (between square brackets []) is 
  applicable only when GPL is suitable, this is, when MediaWikiVLEAdapter is 
  used and/or distributed FOR NON COMMERCIAL USES.
  
  [ You can redistribute MediaWikiVLEAdapter and/or modify it under the 
    terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>
  ]
*/

/*
 * This page is used to configure a new instance. It is the second configuration step: show the instance configuration form.
 *
 * This page shows the GLUE instance configuration form. The page request to gluelet manager for an instance's configuration form
 * and print it. The configuration form is recived as a xforms element and the page translates it into html forms.
 *
 *
 * @access public 
 * @author Javier Aragon
 * @version 2011/05/31-0.1
 * @package php/conf
 */
?>
<script type="text/javascript" >
	/*
	* When the body is loaded/unloaded hide/how the 'loading image' and show the delete instance request.
	*
	*/
	var ErrorConf = false;
	function bodyload(){
		if (ErrorConf== null || !ErrorConf){
			window.top.document.getElementById('NewGlueletConfigurationform').style.display='';
			window.top.document.getElementById('NewGlueletConfigurationform').style.height='100%';
			window.top.document.getElementById('winCloseButtonGlue').style.display='none';
			window.top.document.getElementById('gluewindowinstance').style.display='none';
			document.configureinstance.backbutton.disabled=false;
		}
	}
	function bodyunload(){
		if (ErrorConf== null || !ErrorConf){
			if (window.top.document.getElementById('NewGlueletConfigurationform'))
				window.top.document.getElementById('NewGlueletConfigurationform').style.display='none';
			if (window.top.document.getElementById('gluewindowinstance'))
				window.top.document.getElementById('gluewindowinstance').style.display='';	

		}
	}
	
	function onsendconfbutton(){
		window.top.document.getElementById('NewGlueletConfigurationform').style.display='none';
		window.top.document.getElementById('gluewindowinstance').style.display='';		
		document.configureinstance.backbutton.disabled=true;
		
		return true;
	}
</script>
<?php
//print html tag.
print("<html>");

// print head tags.
print("<head>");
print("<title></title>");
print("</head>");

print("<body onunload='bodyunload()' onload='bodyload()'>");

	// GlueletManagerClient library required.
	require_once('../classes/rest/GlueletManagerRestClient.php');
	// xforms_to_form library required.
	require_once('../classes/xforms/xforms_to_form.php');
	// Internazionalitacion library required.
	require_once('../classes/i18n/I18NGlueLibMessages.php');
	// get the language user preference from $_GET parameteres.
	$lang = $_GET['lang'];
	if (!$lang || $lang==null || $lang=="")
		// if there is no language parameter then create an internationalization object and set defatul language to English.
		$I18N = new I18NGlueLibMessages('en');
	else
		// create the internationalization object.
		$I18N = new I18NGlueLibMessages($lang);
	
	// Get params:
	$user = $_GET['user'];
	// the mediawiki registerd users list.
	$userlist = $_GET['userlist'];
	// the selected tool id at configuration_1 form.
	$selectedtool = $_GET['selectedtool'];
	// the selected tool name
	$selectedtoolname = $_GET['toolname'];
	// the url where is the glueletmanager.
	$glueletmanager = $_GET['glueletmanager'];
	

	// if any error at parameters die and show error message.
	if (!$user || !$userlist || !$selectedtool ||!$glueletmanager || $user=="" || $userlist=="" || $selectedtool=="" || $glueletmanager=="")
		die($I18N->getI18NMessage('errorinparams'));
		
		
	// Create a GlueletManger client object.
	$rest_client = new GlueletManagerRestClient($user, $userlist, $glueletmanager);
	// get instace configuration form request.
	$result = $rest_client->gluelet_get_configuration_form($selectedtool);
	
	
	if ($result[0]){
		// if there is no error at get configuration request
		
		// Use cfg as a dom element.
		if ($result[1]){
			$doc = new DOMDocument();
        	$doc->loadXML($result[1]);
			$domconf = $doc;
			//$domconf = DOMDocument::loadXML($result[1]);
		}
	
		if ($domconf){
			// if $domconf is completed --> there is a configuration form. 
			// Get configuration form request is successful
			// print the form tag.
			
			if ($selectedtoolname && $selectedtoolname!=null && $selectedtoolname!=""){
				print "<p:0 align=left >".$I18N->getI18NMessage('conftoolnamelabel')."<font color=#0000FF><b>".$selectedtoolname."</b></font></p:1><br>";
			}

			print("<form name='configureinstance' id='configureinstance'  accept-charset='utf-8'  enctype='multipart/form-data' method='post' action='configuration_3.php'>");
					
				// Create a xforms_to_form object.
				$converter = new xforms_to_form($domconf);
				// Print xforms fields as html form fields.
				if (!$converter->printformfields()){
					// there is nothing to configure!!!!.
					print("<p align=left><b>". $I18N->getI18NMessage('noconfigurationmessage') ."</b></p>");
				}
					
					
				// print hidden fields for: user, users list, gluelet manager hos, selected tool id, selecetd
				// tool name and user language.
				print ("<input name='user' type='hidden' value='".$user."'  />");
				print ("<input name='userlist' type='hidden' value='".$userlist."'  />");
				print ("<input name='glueletmanager' type='hidden' value='".$glueletmanager."'  />");
				print ("<input name='selectedtool' type='hidden' value='".$selectedtool."'  />");
				print ("<input name='toolname' type='hidden' value='".$selectedtoolname."'  />");
				print ("<input name='lang' type='hidden' value='".$lang."'  />");
				// prepare the configuration form string to try send in an input 'hidden'.
				// replace single quotes (') for double quotes (").
				$str = str_replace("\"","'",$result[1]);
				$str = addslashes($str);
				// print the hidden imput for configuration form.
				print ("<input name='conf_xform' type='hidden' value=\"".$str."\"  />");

						
				// print form control buttons.
				print ("<center><p>");
					// print back button.
					print (" <input name='backbutton' type='button' value='".$I18N->getI18NMessage('backbuttonlabel')."'  onclick='history.go(-1)'/> ");
					// print send button.
					print (" <input name='sendconfbutton' type='submit' value='".$I18N->getI18NMessage('finishbuttonlabel')."' onclick='onsendconfbutton()' /> ");
				print ("</p></center>");
					
			// print end form tag.
			print("</form>");
			
		} else {
			// is there is any error in get configuration form request print an error message.
			echo $I18N->getI18NMessage('noconfigfromerror').$selectedtool;
		}
	} else{
		// an error has ocurred in get configuration form request.
		if ($result[1]){
			$result[1]->print_get_configuration_form_error_with_deatils($glueletmanager, $user, $selectedtool, $selectedtoolname, $lang);
		}
	}
	

	


//print end body tag.
print("</body>");
//print end html tag.
print("</html>");
?>